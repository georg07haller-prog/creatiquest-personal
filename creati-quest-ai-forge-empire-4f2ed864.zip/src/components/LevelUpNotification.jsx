import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Star, TrendingUp } from "lucide-react";

export default function LevelUpNotification({ level, onClose }) {
  const [confetti, setConfetti] = useState([]);

  useEffect(() => {
    // Generate confetti particles
    const particles = [];
    for (let i = 0; i < 50; i++) {
      particles.push({
        id: i,
        x: Math.random() * 100,
        y: -10,
        rotation: Math.random() * 360,
        color: ['#4CAF50', '#2196F3', '#FFD700', '#FF6B6B', '#9C27B0'][Math.floor(Math.random() * 5)],
        delay: Math.random() * 0.5
      });
    }
    setConfetti(particles);

    // Auto close after 4 seconds
    const timer = setTimeout(() => {
      onClose();
    }, 4000);

    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      >
        {/* Confetti */}
        {confetti.map((particle) => (
          <motion.div
            key={particle.id}
            initial={{ 
              x: `${particle.x}vw`, 
              y: `${particle.y}vh`,
              rotate: particle.rotation,
              opacity: 1
            }}
            animate={{ 
              y: '110vh',
              rotate: particle.rotation + 720,
              opacity: 0
            }}
            transition={{ 
              duration: 2 + Math.random() * 2,
              delay: particle.delay,
              ease: "easeIn"
            }}
            className="absolute w-3 h-3 rounded-sm"
            style={{ backgroundColor: particle.color }}
          />
        ))}

        {/* Main notification */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          exit={{ scale: 0, rotate: 180 }}
          transition={{ type: "spring", duration: 0.8 }}
          className="relative"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="bg-gradient-to-br from-yellow-500 via-orange-500 to-pink-500 p-1 rounded-2xl">
            <div className="bg-slate-900 rounded-2xl p-8 text-center min-w-[320px]">
              {/* Animated stars */}
              <motion.div
                animate={{ 
                  rotate: 360,
                  scale: [1, 1.2, 1]
                }}
                transition={{ 
                  rotate: { duration: 3, repeat: Infinity, ease: "linear" },
                  scale: { duration: 1.5, repeat: Infinity }
                }}
                className="mb-4"
              >
                <Star className="w-16 h-16 mx-auto text-yellow-400 fill-yellow-400" />
              </motion.div>

              <motion.h2
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="text-4xl font-bold mb-2 bg-gradient-to-r from-yellow-400 via-orange-400 to-pink-400 bg-clip-text text-transparent"
              >
                LEVEL UP!
              </motion.h2>

              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.5, type: "spring" }}
                className="text-6xl font-bold text-white mb-4"
              >
                {level}
              </motion.div>

              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 }}
                className="space-y-2"
              >
                <div className="flex items-center justify-center gap-2 text-green-400">
                  <Sparkles className="w-5 h-5" />
                  <span className="font-semibold">+50 Mana Bonus!</span>
                </div>
                <div className="flex items-center justify-center gap-2 text-blue-400">
                  <TrendingUp className="w-5 h-5" />
                  <span className="text-sm">New opportunities unlocked!</span>
                </div>
              </motion.div>

              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="text-gray-400 text-sm mt-4"
              >
                Keep creating to reach the next level!
              </motion.p>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}