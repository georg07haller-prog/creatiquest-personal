import React, { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Trophy, Target, Users, ArrowRight, X } from "lucide-react";
import { base44 } from "@/api/base44Client";

const tutorialSteps = [
  {
    title: "Welcome to CreatiQuest! 🎉",
    description: "Let's take a quick tour of how to create, compete, and earn!",
    icon: Sparkles,
    action: null
  },
  {
    title: "Create Content",
    description: "Go to Studio to generate AI-powered memes, videos, songs, or texts. Each creation costs mana!",
    icon: Sparkles,
    highlight: "Studio"
  },
  {
    title: "Join Contests",
    description: "Compete in daily/weekly contests. Get votes from the community to win prizes up to €10!",
    icon: Trophy,
    highlight: "Contests"
  },
  {
    title: "Complete Quests",
    description: "Choose a specialization path and complete sponsored quests for bigger rewards (€40-150)!",
    icon: Target,
    highlight: "Quests"
  },
  {
    title: "Engage with Community",
    description: "Like, rate, and comment on others' work to earn mana and karma. Share your favorites!",
    icon: Users,
    highlight: "Community"
  },
  {
    title: "Level Up & Earn!",
    description: "Gain XP from all activities, level up for bonuses, and track your progress. Ready to start?",
    icon: Sparkles,
    action: "Start Creating"
  }
];

export default function InteractiveTutorial({ onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [show, setShow] = useState(false);

  useEffect(() => {
    checkTutorial();
  }, []);

  const checkTutorial = async () => {
    try {
      const user = await base44.auth.me();
      if (!user.tutorial_completed) {
        setShow(true);
      }
    } catch (error) {
      console.error("Error checking tutorial:", error);
    }
  };

  const handleNext = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handleSkip = async () => {
    await base44.auth.updateMe({ tutorial_completed: true });
    setShow(false);
    if (onComplete) onComplete();
  };

  const handleComplete = async () => {
    await base44.auth.updateMe({ 
      tutorial_completed: true,
      mana: 120 // Bonus mana for completing tutorial
    });
    setShow(false);
    if (onComplete) onComplete();
  };

  const step = tutorialSteps[currentStep];
  const Icon = step.icon;

  return (
    <Dialog open={show} onOpenChange={setShow}>
      <DialogContent className="bg-gradient-to-br from-slate-800 to-slate-900 border-purple-500/30 max-w-2xl">
        <button
          onClick={handleSkip}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
        >
          <X size={20} />
        </button>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="text-center py-8"
          >
            <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
              <Icon size={48} className="text-white" />
            </div>

            <h2 className="text-3xl font-bold text-white mb-4">{step.title}</h2>
            <p className="text-gray-300 text-lg mb-8 max-w-lg mx-auto">{step.description}</p>

            {/* Progress Dots */}
            <div className="flex justify-center gap-2 mb-8">
              {tutorialSteps.map((_, idx) => (
                <div
                  key={idx}
                  className={`w-2 h-2 rounded-full transition-all ${
                    idx === currentStep ? 'bg-purple-500 w-8' : 'bg-gray-600'
                  }`}
                />
              ))}
            </div>

            <div className="flex justify-center gap-4">
              {currentStep === 0 && (
                <Button
                  onClick={handleSkip}
                  variant="outline"
                  className="border-gray-600 text-gray-300"
                >
                  Skip Tutorial
                </Button>
              )}
              <Button
                onClick={handleNext}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                {currentStep === tutorialSteps.length - 1 ? (
                  <>Get +20 Bonus Mana! 🎁</>
                ) : (
                  <>
                    Next <ArrowRight size={16} className="ml-2" />
                  </>
                )}
              </Button>
            </div>
          </motion.div>
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}