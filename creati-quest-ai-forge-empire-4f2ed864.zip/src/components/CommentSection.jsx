import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { MessageCircle, Heart, Send } from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

export default function CommentSection({ creationId }) {
  const [newComment, setNewComment] = useState('');
  const [replyTo, setReplyTo] = useState(null);
  const queryClient = useQueryClient();

  const { data: comments = [] } = useQuery({
    queryKey: ['comments', creationId],
    queryFn: () => base44.entities.Comment.filter({ creation_id: creationId }, '-created_date'),
    initialData: [],
  });

  const addCommentMutation = useMutation({
    mutationFn: async (content) => {
      const user = await base44.auth.me();
      await base44.entities.Comment.create({
        creation_id: creationId,
        content: content,
        parent_id: replyTo?.id || undefined
      });
      
      // Log activity
      await base44.entities.Activity.create({
        type: 'comment_received',
        title: 'New comment on your creation',
        description: content.substring(0, 100),
        icon: '💬'
      });

      await base44.auth.updateMe({ 
        karma: (user.karma || 0) + 1 
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['comments', creationId] });
      setNewComment('');
      setReplyTo(null);
      toast.success("+1 karma for commenting!");
    },
  });

  const handleSubmit = () => {
    if (newComment.trim().length < 3) {
      toast.error("Comment must be at least 3 characters");
      return;
    }
    addCommentMutation.mutate(newComment);
  };

  const topLevelComments = comments.filter(c => !c.parent_id);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <MessageCircle className="text-blue-400" size={20} />
        <h3 className="text-white font-semibold">Comments ({comments.length})</h3>
      </div>

      {/* Add Comment */}
      <div className="bg-slate-800/60 rounded-lg p-4 border border-slate-600">
        {replyTo && (
          <div className="mb-2 text-sm text-gray-400 flex items-center justify-between">
            <span>Replying to: {replyTo.created_by}</span>
            <Button size="sm" variant="ghost" onClick={() => setReplyTo(null)}>Cancel</Button>
          </div>
        )}
        <Textarea
          placeholder="Write a comment..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          className="bg-slate-700 border-slate-600 text-white mb-2"
          rows={3}
        />
        <Button
          onClick={handleSubmit}
          disabled={addCommentMutation.isPending || newComment.trim().length < 3}
          className="bg-blue-500 hover:bg-blue-600"
          size="sm"
        >
          <Send size={16} className="mr-2" />
          Post Comment
        </Button>
      </div>

      {/* Comments List */}
      <div className="space-y-3">
        {topLevelComments.map((comment) => (
          <div key={comment.id} className="bg-slate-800/40 rounded-lg p-4 border border-slate-700">
            <div className="flex items-start justify-between mb-2">
              <div>
                <span className="text-white font-semibold text-sm">{comment.created_by}</span>
                <span className="text-gray-500 text-xs ml-2">
                  {formatDistanceToNow(new Date(comment.created_date), { addSuffix: true })}
                </span>
              </div>
            </div>
            <p className="text-gray-300 text-sm mb-2">{comment.content}</p>
            <div className="flex items-center gap-3">
              <button className="text-gray-400 hover:text-pink-400 text-xs flex items-center gap-1">
                <Heart size={14} /> {comment.likes || 0}
              </button>
              <button 
                onClick={() => setReplyTo(comment)}
                className="text-gray-400 hover:text-blue-400 text-xs"
              >
                Reply
              </button>
            </div>

            {/* Replies */}
            {comments.filter(c => c.parent_id === comment.id).map((reply) => (
              <div key={reply.id} className="ml-6 mt-3 bg-slate-900/40 rounded-lg p-3 border-l-2 border-blue-500/30">
                <div className="flex items-start justify-between mb-2">
                  <span className="text-white font-semibold text-sm">{reply.created_by}</span>
                  <span className="text-gray-500 text-xs">
                    {formatDistanceToNow(new Date(reply.created_date), { addSuffix: true })}
                  </span>
                </div>
                <p className="text-gray-300 text-sm">{reply.content}</p>
              </div>
            ))}
          </div>
        ))}

        {comments.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <MessageCircle size={32} className="mx-auto mb-2 opacity-50" />
            <p>No comments yet. Be the first!</p>
          </div>
        )}
      </div>
    </div>
  );
}