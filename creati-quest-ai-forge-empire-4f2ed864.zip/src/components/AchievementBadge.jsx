import React from "react";
import { Badge } from "@/components/ui/badge";
import { Trophy, Lock } from "lucide-react";
import { motion } from "framer-motion";

export default function AchievementBadge({ achievement, userAchievement, size = "md" }) {
  const isUnlocked = !!userAchievement;
  const progress = userAchievement?.progress || 0;
  const required = achievement.requirement_value;
  const percentage = Math.min((progress / required) * 100, 100);

  const rarityColors = {
    common: "from-gray-500 to-gray-600",
    rare: "from-blue-500 to-blue-600",
    epic: "from-purple-500 to-purple-600",
    legendary: "from-yellow-500 to-orange-500"
  };

  const sizes = {
    sm: "w-16 h-16",
    md: "w-24 h-24",
    lg: "w-32 h-32"
  };

  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      className={`relative ${sizes[size]} cursor-pointer`}
    >
      <div className={`w-full h-full rounded-full bg-gradient-to-br ${rarityColors[achievement.rarity]} p-1 ${!isUnlocked && 'opacity-50'}`}>
        <div className="w-full h-full bg-slate-900 rounded-full flex flex-col items-center justify-center">
          {isUnlocked ? (
            <>
              <span className="text-2xl mb-1">{achievement.icon}</span>
              <span className="text-xs text-white font-bold text-center px-2">{achievement.title}</span>
            </>
          ) : (
            <>
              <Lock size={24} className="text-gray-500 mb-1" />
              <span className="text-xs text-gray-500 text-center px-2">Locked</span>
            </>
          )}
        </div>
      </div>
      {!isUnlocked && required > 0 && (
        <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-full px-2">
          <div className="bg-slate-800 rounded-full h-2 overflow-hidden border border-slate-600">
            <div 
              className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-300"
              style={{ width: `${percentage}%` }}
            />
          </div>
          <span className="text-xs text-gray-400 block text-center mt-1">{progress}/{required}</span>
        </div>
      )}
    </motion.div>
  );
}