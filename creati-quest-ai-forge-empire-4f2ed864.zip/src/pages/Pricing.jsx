import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Sparkles, Crown, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

export default function Pricing() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  const handleSubscribe = async () => {
    setLoading(true);
    try {
      const { data } = await base44.functions.invoke('createCheckout', {
        priceId: 'price_1STkMOQcoi11HipZVVBbsDpL', // €4.99/month
        mode: 'subscription'
      });

      if (data.url) {
        window.location.href = data.url;
      }
    } catch (error) {
      toast.error("Failed to create checkout session");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const tiers = [
    {
      name: "Base Tier",
      price: "Free",
      description: "Contest Arena - Perfect to start",
      features: [
        "Daily & weekly contests",
        "AI content generation (20 mana per use)",
        "Community voting & ratings",
        "Social media sharing",
        "Win up to €10 per contest",
        "Browse all creations"
      ],
      icon: "🎯",
      color: "from-blue-500 to-blue-600",
      current: user?.subscription_tier === 'free'
    },
    {
      name: "Premium Tier",
      price: "€4.99",
      period: "/month",
      description: "Quest Labyrinth - Unlock your potential",
      features: [
        "All Base features",
        "Choose specialization path (4 options)",
        "Access sponsored quest chains",
        "Path-specific perks & bonuses",
        "Community governance polls (+10 mana)",
        "Win €40-150 per quest chain",
        "Exclusive themed content"
      ],
      icon: "💎",
      color: "from-purple-500 to-pink-500",
      recommended: true,
      current: user?.subscription_tier === 'paid'
    },
    {
      name: "Elite Tier",
      price: "Coming Soon",
      description: "Strategy Forge - For the ambitious",
      features: [
        "All Premium features",
        "Long-term strategy building",
        "Advanced AI agents system",
        "Mana investments for upgrades",
        "ROI up to €200-500+",
        "Royalty shares from viral content",
        "Empire building journal"
      ],
      icon: "👑",
      color: "from-yellow-500 to-orange-500",
      comingSoon: true
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
          Choose Your Path
        </h1>
        <p className="text-blue-300 text-lg">Start free, upgrade when ready for more rewards</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {tiers.map((tier, index) => (
          <Card 
            key={index}
            className={`bg-slate-800/60 backdrop-blur border-2 transition-all ${
              tier.recommended 
                ? 'border-purple-500 scale-105' 
                : 'border-slate-600 hover:border-slate-500'
            }`}
          >
            <CardHeader>
              {tier.recommended && (
                <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 mb-2 w-fit">
                  Recommended
                </Badge>
              )}
              {tier.current && (
                <Badge className="bg-green-500/20 text-green-300 border-green-500/30 mb-2 w-fit">
                  Current Plan
                </Badge>
              )}
              <div className="text-4xl mb-3">{tier.icon}</div>
              <CardTitle className="text-white text-2xl mb-2">{tier.name}</CardTitle>
              <div className="text-3xl font-bold text-white mb-1">
                {tier.price}
                {tier.period && <span className="text-sm text-gray-400">{tier.period}</span>}
              </div>
              <p className="text-gray-400 text-sm">{tier.description}</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 mb-6">
                {tier.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-gray-300">
                    <Check size={16} className="text-green-400 flex-shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              {tier.current ? (
                <Button disabled className="w-full bg-slate-700 text-gray-400">
                  Current Plan
                </Button>
              ) : tier.comingSoon ? (
                <Button disabled className="w-full bg-slate-700 text-gray-400">
                  Coming Q2 2025
                </Button>
              ) : tier.name === "Base Tier" ? (
                <Button 
                  variant="outline" 
                  className="w-full border-blue-400 text-blue-300"
                  disabled
                >
                  Free Forever
                </Button>
              ) : (
                <Button
                  onClick={handleSubscribe}
                  disabled={loading}
                  className={`w-full bg-gradient-to-r ${tier.color} hover:opacity-90`}
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 animate-spin" size={16} />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2" size={16} />
                      Subscribe Now
                    </>
                  )}
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-12 max-w-4xl mx-auto">
        <Card className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 border-purple-500/30">
          <CardContent className="pt-6">
            <h3 className="text-white font-bold text-xl mb-4 text-center">Frequently Asked Questions</h3>
            <div className="space-y-4 text-sm">
              <div>
                <p className="text-white font-semibold mb-1">Can I cancel anytime?</p>
                <p className="text-gray-300">Yes! Cancel anytime and keep access until the end of your billing period.</p>
              </div>
              <div>
                <p className="text-white font-semibold mb-1">What happens to my progress if I cancel?</p>
                <p className="text-gray-300">Your level, XP, karma, and creations remain. You just lose access to quests and specialization paths.</p>
              </div>
              <div>
                <p className="text-white font-semibold mb-1">How do payouts work?</p>
                <p className="text-gray-300">Win contests and quests to earn tokens (€). Minimum withdrawal: €5. Payouts via Stripe to your bank account in 1-3 business days.</p>
              </div>
              <div>
                <p className="text-white font-semibold mb-1">Is there a free trial?</p>
                <p className="text-gray-300">Yes! New subscribers get 7 days free to try Premium tier with all features.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}