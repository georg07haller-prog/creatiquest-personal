import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, Trophy, Target, Zap, Users, TrendingUp, Euro, CheckCircle } from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: Sparkles,
      title: "AI Content Generation",
      description: "Create memes, videos, songs and texts with powerful AI in seconds",
      color: "from-green-400 to-blue-400"
    },
    {
      icon: Trophy,
      title: "Daily Contests",
      description: "Compete in daily and weekly eco-themed contests, win €1-10",
      color: "from-yellow-400 to-orange-400"
    },
    {
      icon: Target,
      title: "Sponsored Quests",
      description: "Complete quest chains from real brands, earn €40-150",
      color: "from-purple-400 to-pink-400"
    },
    {
      icon: TrendingUp,
      title: "Progression System",
      description: "Earn XP, level up, get bonuses. Each level-up = +50 mana!",
      color: "from-blue-400 to-cyan-400"
    },
    {
      icon: Users,
      title: "Active Community",
      description: "Like, rate, share creations. Earn mana and karma for activity",
      color: "from-pink-400 to-red-400"
    },
    {
      icon: Euro,
      title: "Real Prizes",
      description: "Payouts via Stripe to bank account. System launching Q1-Q2 2025",
      color: "from-green-400 to-teal-400"
    }
  ];

  const tiers = [
    {
      name: "Base Tier",
      price: "FREE",
      badge: "Start",
      features: [
        "Daily and weekly contests",
        "AI content generation (20 mana)",
        "Likes, ratings, comments",
        "XP and leveling system",
        "Social media shares (+10 mana)",
        "Prizes up to €10 per contest"
      ],
      color: "border-blue-500/30",
      bgColor: "from-blue-900/30 to-blue-800/30"
    },
    {
      name: "Premium Tier",
      price: "€4.99/mo",
      badge: "Popular",
      features: [
        "All Base features +",
        "Access to quests (€40-150)",
        "Specialization path selection",
        "Exclusive AI agents",
        "Path perks and bonuses",
        "Poll voting (+10 mana)"
      ],
      color: "border-purple-500/50",
      bgColor: "from-purple-900/40 to-purple-800/40",
      highlighted: true
    },
    {
      name: "Elite Tier",
      price: "Coming Soon",
      badge: "Pro",
      features: [
        "All Premium features +",
        "Long-term strategies",
        "Advanced AI agents",
        "Mana investments for upgrades",
        "ROI up to €200-500+",
        "Royalties from viral content"
      ],
      color: "border-yellow-500/30",
      bgColor: "from-yellow-900/30 to-yellow-800/30"
    }
  ];

  const demoCreations = [
    {
      title: "Future of Eco-Transport",
      type: "🎭 Meme",
      likes: 142,
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400"
    },
    {
      title: "Green City Dreams",
      type: "🎬 Video",
      likes: 89,
      rating: 4.6,
      image: "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=400"
    },
    {
      title: "Sustainability Anthem",
      type: "🎵 Song",
      likes: 203,
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=1920')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
        <div className="relative container mx-auto px-4 py-20 md:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <div className="mb-6">
              <span className="inline-block px-4 py-2 bg-green-500/20 border border-green-400/30 rounded-full text-green-300 text-sm font-semibold">
                🌱 Eco Content • AI Creativity • Real Prizes
              </span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-green-400 via-blue-400 to-purple-500 bg-clip-text text-transparent">
              CreatiQuest: AI Forge Empire
            </h1>
            <p className="text-xl md:text-2xl text-blue-200 mb-8">
              Create content with AI, compete in contests and quests, earn real money
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={createPageUrl("Dashboard")}>
                <Button className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white px-8 py-6 text-lg">
                  <Sparkles className="mr-2" />
                  Start Creating
                </Button>
              </Link>
              <Link to={createPageUrl("FAQ")}>
                <Button variant="outline" className="border-blue-400 text-blue-300 hover:bg-blue-500/20 px-8 py-6 text-lg">
                  Learn More
                </Button>
              </Link>
            </div>
            <p className="text-sm text-gray-400 mt-4">
              🎉 Free Registration • 🌍 Available for EU
            </p>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Why CreatiQuest?</h2>
          <p className="text-gray-400 text-lg">Gaming platform for creatives with real rewards</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <Card key={i} className="bg-slate-800/60 backdrop-blur border-blue-500/30 hover:border-blue-400 transition-all">
              <CardContent className="pt-6">
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4`}>
                  <feature.icon className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Pricing Tiers */}
      <div className="container mx-auto px-4 py-16 bg-slate-900/50">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Choose Your Path</h2>
          <p className="text-gray-400 text-lg">From free contests to elite strategies</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {tiers.map((tier, i) => (
            <Card 
              key={i} 
              className={`bg-gradient-to-br ${tier.bgColor} backdrop-blur ${tier.color} ${tier.highlighted ? 'ring-2 ring-purple-500 scale-105' : ''} transition-all`}
            >
              <CardContent className="pt-6">
                {tier.badge && (
                  <div className="mb-4">
                    <span className="inline-block px-3 py-1 bg-white/10 border border-white/20 rounded-full text-xs font-semibold text-white">
                      {tier.badge}
                    </span>
                  </div>
                )}
                <h3 className="text-2xl font-bold text-white mb-2">{tier.name}</h3>
                <p className="text-3xl font-bold text-blue-300 mb-6">{tier.price}</p>
                <ul className="space-y-3">
                  {tier.features.map((feature, j) => (
                    <li key={j} className="flex items-start gap-2 text-gray-300">
                      <CheckCircle className="text-green-400 flex-shrink-0 mt-0.5" size={18} />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link to={createPageUrl("Dashboard")}>
                  <Button 
                    className={`w-full mt-6 ${tier.highlighted ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600' : 'bg-slate-700 hover:bg-slate-600'}`}
                  >
                    {tier.price === "Coming Soon" ? "Soon" : tier.price === "FREE" ? "Get Started" : "Subscribe"}
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Demo Contest Preview */}
      <div className="container mx-auto px-4 py-16 bg-slate-900/50">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Try Demo Contest</h2>
          <p className="text-gray-400 text-lg">See how contests work — no registration needed!</p>
        </div>
        <div className="max-w-4xl mx-auto bg-gradient-to-br from-blue-900/40 to-purple-900/40 rounded-2xl p-8 border border-blue-500/30">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold text-white mb-2">🚴‍♂️ Future of Eco-Transport</h3>
            <p className="text-blue-200">6 entries • €50 prize pool • Voting active</p>
          </div>
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="aspect-square rounded-lg overflow-hidden">
              <img src="https://images.unsplash.com/photo-1571068316344-75bc76f77890?w=400" alt="Demo 1" className="w-full h-full object-cover" />
            </div>
            <div className="aspect-square rounded-lg overflow-hidden">
              <img src="https://images.unsplash.com/photo-1534351590666-13e3e96b5017?w=400" alt="Demo 2" className="w-full h-full object-cover" />
            </div>
            <div className="aspect-square rounded-lg overflow-hidden">
              <img src="https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=400" alt="Demo 3" className="w-full h-full object-cover" />
            </div>
          </div>
          <div className="text-center">
            <Link to={createPageUrl("Demo")}>
              <Button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 px-8 py-6 text-lg">
                <Trophy className="mr-2" />
                View Demo Contest
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Demo Creations */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Example Creations</h2>
          <p className="text-gray-400 text-lg">Get inspired by other players' work</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {demoCreations.map((creation, i) => (
            <Card key={i} className="bg-slate-800/60 backdrop-blur border-purple-500/30 hover:border-purple-400 transition-all overflow-hidden group">
              <div className="aspect-video relative overflow-hidden">
                <img 
                  src={creation.image} 
                  alt={creation.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <CardContent className="pt-4">
                <div className="mb-2">
                  <span className="text-xs text-purple-300">{creation.type}</span>
                </div>
                <h3 className="text-lg font-bold text-white mb-3">{creation.title}</h3>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-pink-400">❤️ {creation.likes}</span>
                  <span className="text-yellow-400">⭐ {creation.rating}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="text-center mt-8">
          <Link to={createPageUrl("Community")}>
            <Button variant="outline" className="border-purple-400 text-purple-300 hover:bg-purple-500/20">
              View Full Community →
            </Button>
          </Link>
        </div>
      </div>

      {/* CTA Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="bg-gradient-to-r from-green-900/40 to-blue-900/40 rounded-2xl p-8 md:p-12 border border-green-500/30 text-center">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
            Ready to Create and Earn?
          </h2>
          <p className="text-xl text-blue-200 mb-8">
            Join the creative community of Neo-Europe today
          </p>
          <Link to={createPageUrl("Dashboard")}>
            <Button className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white px-12 py-6 text-xl">
              <Sparkles className="mr-2" size={24} />
              Start Free
            </Button>
          </Link>
          <p className="text-sm text-gray-400 mt-4">
            30-second registration • No credit card required
          </p>
        </div>
      </div>

      {/* Footer Links */}
      <div className="container mx-auto px-4 py-8 border-t border-slate-700">
        <div className="flex flex-wrap justify-center gap-6 text-sm text-gray-400">
          <Link to={createPageUrl("FAQ")} className="hover:text-blue-400">FAQ</Link>
          <Link to={createPageUrl("Privacy")} className="hover:text-blue-400">Privacy</Link>
          <Link to={createPageUrl("Terms")} className="hover:text-blue-400">Terms</Link>
          <a href="mailto:support@creatiquest.app" className="hover:text-blue-400">Support</a>
        </div>
        <p className="text-center text-gray-500 text-xs mt-4">
          © 2025 CreatiQuest. GDPR & DSA compliant. Made with 💚 in Neo-Europe.
        </p>
      </div>
    </div>
  );
}