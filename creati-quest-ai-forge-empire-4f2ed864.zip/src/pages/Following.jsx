import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, UserMinus, Trophy } from "lucide-react";
import { toast } from "sonner";

export default function Following() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  const { data: following = [] } = useQuery({
    queryKey: ['following', user?.email],
    queryFn: () => user ? base44.entities.Follow.filter({ created_by: user.email }) : [],
    initialData: [],
    enabled: !!user
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['all-users-following'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const unfollowMutation = useMutation({
    mutationFn: (followId) => base44.entities.Follow.delete(followId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['following'] });
      toast.success("Unfollowed");
    },
  });

  const followedUsers = following
    .map(f => allUsers.find(u => u.email === f.following_email))
    .filter(Boolean);

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
          👥 Following
        </h1>
        <p className="text-blue-300">Creators you follow ({followedUsers.length})</p>
      </div>

      {followedUsers.length > 0 ? (
        <div className="space-y-4">
          {followedUsers.map((followedUser) => {
            const followRecord = following.find(f => f.following_email === followedUser.email);
            return (
              <Card key={followedUser.id} className="bg-slate-800/60 backdrop-blur border-purple-500/30">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                        <Users className="text-white" size={32} />
                      </div>
                      <div>
                        <h3 className="text-white font-bold text-lg">{followedUser.full_name || followedUser.email}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs border-blue-400/30 text-blue-300">
                            Level {followedUser.level || 1}
                          </Badge>
                          <Badge variant="outline" className="text-xs border-pink-400/30 text-pink-300">
                            {followedUser.karma || 0} karma
                          </Badge>
                          {followedUser.specialization_path && followedUser.specialization_path !== 'none' && (
                            <Badge variant="outline" className="text-xs border-purple-400/30 text-purple-300">
                              {followedUser.specialization_path}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => unfollowMutation.mutate(followRecord.id)}
                      className="border-red-400/30 text-red-300 hover:bg-red-500/20"
                    >
                      <UserMinus size={16} className="mr-2" />
                      Unfollow
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-12">
          <Users size={48} className="mx-auto mb-4 text-gray-600" />
          <p className="text-gray-400 text-lg mb-2">Not following anyone yet</p>
          <p className="text-gray-500 text-sm">Discover creators in the community!</p>
        </div>
      )}
    </div>
  );
}