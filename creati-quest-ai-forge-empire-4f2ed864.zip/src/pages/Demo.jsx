import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trophy, Heart, Star, Share2, Play, Music, Sparkles, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function Demo() {
  const [selectedCreation, setSelectedCreation] = useState(null);
  const [viewDialog, setViewDialog] = useState(false);

  const demoContest = {
    title: "Future of Eco-Transport",
    description: "Create creative content about sustainable transport in Neo-Europe",
    theme: "Sustainable Mobility",
    image_url: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800",
    end_date: "2025-01-25T23:59:59",
    prize_pool: 50,
    status: "voting",
    eco_badge: true
  };

  const demoCreations = [
    {
      id: "demo1",
      title: "Bike of the Future",
      type: "meme",
      content: "When your bike is smarter than your smartphone 🚴‍♂️⚡",
      image_url: "https://images.unsplash.com/photo-1571068316344-75bc76f77890?w=600",
      likes: 142,
      rating_avg: 4.8,
      rating_count: 23,
      shares: 45,
      viral_score: 87,
      tags: ["bike", "tech", "eco"],
      created_by: "alex@demo.com"
    },
    {
      id: "demo2",
      title: "Amsterdam Green Routes",
      type: "video",
      content: "Short film about how Amsterdam became the bicycle capital",
      image_url: "https://images.unsplash.com/photo-1534351590666-13e3e96b5017?w=600",
      likes: 203,
      rating_avg: 4.9,
      rating_count: 31,
      shares: 67,
      viral_score: 92,
      tags: ["amsterdam", "bikes", "city"],
      created_by: "maria@demo.com"
    },
    {
      id: "demo3",
      title: "Sustainability Anthem",
      type: "song",
      content: "🎵 Ride your bike, save the planet / Green wheels turning, hearts elating...",
      image_url: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=600",
      likes: 189,
      rating_avg: 4.7,
      rating_count: 28,
      shares: 52,
      viral_score: 85,
      tags: ["music", "sustainability", "anthem"],
      created_by: "john@demo.com"
    },
    {
      id: "demo4",
      title: "E-Scooter vs Car",
      type: "meme",
      content: "Traffic jam 2 hours VS arrived in 15 minutes and found parking 😎",
      image_url: "https://images.unsplash.com/photo-1598827013824-37fab5b33468?w=600",
      likes: 167,
      rating_avg: 4.6,
      rating_count: 25,
      shares: 38,
      viral_score: 81,
      tags: ["scooter", "traffic", "city"],
      created_by: "emma@demo.com"
    },
    {
      id: "demo5",
      title: "Prague Future Tram",
      type: "video",
      content: "How Prague is modernizing public transport",
      image_url: "https://images.unsplash.com/photo-1583422409516-2895a77efded?w=600",
      likes: 134,
      rating_avg: 4.5,
      rating_count: 19,
      shares: 29,
      viral_score: 76,
      tags: ["prague", "tram", "future"],
      created_by: "pavel@demo.com"
    },
    {
      id: "demo6",
      title: "Carsharing Saves the Planet",
      type: "text",
      content: "Why one car for 10 people is better than 10 cars for 10 people? Simple math...",
      image_url: "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=600",
      likes: 98,
      rating_avg: 4.4,
      rating_count: 15,
      shares: 21,
      viral_score: 72,
      tags: ["carsharing", "eco", "smart"],
      created_by: "sophie@demo.com"
    }
  ];

  const topCreations = demoCreations.sort((a, b) => b.likes - a.likes).slice(0, 3);

  const getTypeIcon = (type) => {
    if (type === 'video') return <Play size={24} className="text-white" />;
    if (type === 'song') return <Music size={24} className="text-white" />;
    if (type === 'meme') return <span className="text-2xl">🎭</span>;
    return <span className="text-2xl">📝</span>;
  };

  const handleView = (creation) => {
    setSelectedCreation(creation);
    setViewDialog(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      {/* Hero */}
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <Badge className="bg-green-500/20 text-green-300 border-green-400/30 mb-4">
            🌱 Demo Contest • No Registration
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
            {demoContest.title}
          </h1>
          <p className="text-xl text-blue-200 mb-6">{demoContest.description}</p>
          <div className="flex flex-wrap justify-center gap-4 mb-6">
            <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 px-4 py-2">
              <Trophy className="mr-2" size={16} />
              Prize Pool: €{demoContest.prize_pool}
            </Badge>
            <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 px-4 py-2">
              👥 {demoCreations.length} participants
            </Badge>
            <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 px-4 py-2">
              🗳️ Voting active
            </Badge>
          </div>
          <Link to={createPageUrl("Landing")}>
            <Button className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600">
              <Sparkles className="mr-2" />
              Join CreatiQuest
            </Button>
          </Link>
        </div>

        {/* Top 3 */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6 text-center">🏆 Top 3 Leaders</h2>
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {topCreations.map((creation, index) => (
              <Card 
                key={creation.id} 
                className={`bg-slate-800/60 backdrop-blur border-2 ${
                  index === 0 ? 'border-yellow-500/50' : 
                  index === 1 ? 'border-gray-400/50' : 
                  'border-orange-500/50'
                } hover:scale-105 transition-all`}
              >
                <div className="aspect-video relative overflow-hidden cursor-pointer" onClick={() => handleView(creation)}>
                  <img 
                    src={creation.image_url} 
                    alt={creation.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2">
                    <Badge className={
                      index === 0 ? 'bg-yellow-500 text-black' : 
                      index === 1 ? 'bg-gray-400 text-black' : 
                      'bg-orange-500 text-black'
                    }>
                      #{index + 1}
                    </Badge>
                  </div>
                  <div className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                    {getTypeIcon(creation.type)}
                  </div>
                </div>
                <CardContent className="pt-4">
                  <h3 className="text-lg font-bold text-white mb-2">{creation.title}</h3>
                  <div className="flex items-center justify-between text-sm mb-3">
                    <span className="text-pink-400 flex items-center gap-1">
                      <Heart size={16} fill="currentColor" /> {creation.likes}
                    </span>
                    <span className="text-yellow-400 flex items-center gap-1">
                      <Star size={16} fill="currentColor" /> {creation.rating_avg}
                    </span>
                    <span className="text-blue-400 flex items-center gap-1">
                      <Share2 size={16} /> {creation.shares}
                    </span>
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="w-full border-blue-400/30 text-blue-300"
                    onClick={() => handleView(creation)}
                  >
                    View
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* All Entries */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-6">All Contest Entries</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {demoCreations.map((creation) => (
              <Card key={creation.id} className="bg-slate-800/60 backdrop-blur border-purple-500/30 hover:border-purple-400 transition-all overflow-hidden group">
                <div 
                  className="aspect-video relative overflow-hidden cursor-pointer"
                  onClick={() => handleView(creation)}
                >
                  <img 
                    src={creation.image_url} 
                    alt={creation.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    {getTypeIcon(creation.type)}
                  </div>
                  {creation.viral_score > 80 && (
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                        🔥 Viral
                      </Badge>
                    </div>
                  )}
                </div>
                
                <CardContent className="p-4">
                  <h3 className="text-lg font-bold text-white mb-2 line-clamp-2">{creation.title}</h3>
                  
                  {creation.tags && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {creation.tags.slice(0, 3).map((tag, i) => (
                        <Badge key={i} variant="outline" className="text-xs border-blue-400/30 text-blue-300">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center justify-between mb-3 text-sm">
                    <span className="text-pink-400 flex items-center gap-1">
                      <Heart size={16} fill="currentColor" /> {creation.likes}
                    </span>
                    <span className="text-yellow-400 flex items-center gap-1">
                      <Star size={16} fill="currentColor" /> {creation.rating_avg} ({creation.rating_count})
                    </span>
                    <span className="text-blue-400 flex items-center gap-1">
                      <Share2 size={16} /> {creation.shares}
                    </span>
                  </div>

                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleView(creation)}
                    className="w-full border-purple-500/30 text-purple-300 hover:bg-purple-500/20"
                  >
                    View Entry
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="mt-16 bg-gradient-to-r from-green-900/40 to-blue-900/40 rounded-2xl p-8 md:p-12 border border-green-500/30 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Want to Participate?
          </h2>
          <p className="text-xl text-blue-200 mb-8">
            Create your content, win contests, earn real prizes!
          </p>
          <Link to={createPageUrl("Landing")}>
            <Button className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white px-12 py-6 text-xl">
              <Sparkles className="mr-2" size={24} />
              Start Free
            </Button>
          </Link>
          <p className="text-sm text-gray-400 mt-4">
            30-second registration • AI generation included
          </p>
        </div>
      </div>

      {/* View Dialog */}
      <Dialog open={viewDialog} onOpenChange={setViewDialog}>
        <DialogContent className="bg-slate-800 border-purple-500/30 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center justify-between">
              <span>{selectedCreation?.title}</span>
              <Badge className="bg-purple-500/80">
                {selectedCreation?.type}
              </Badge>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {selectedCreation?.image_url && (
              <div className="rounded-lg overflow-hidden">
                <img 
                  src={selectedCreation.image_url} 
                  alt={selectedCreation.title}
                  className="w-full h-auto max-h-[50vh] object-contain"
                />
              </div>
            )}

            {selectedCreation?.content && (
              <div className="bg-slate-700/50 rounded-lg p-4 max-h-48 overflow-y-auto">
                <p className="text-white whitespace-pre-wrap">{selectedCreation.content}</p>
              </div>
            )}

            {selectedCreation?.tags && (
              <div className="flex flex-wrap gap-2">
                {selectedCreation.tags.map((tag, i) => (
                  <Badge key={i} variant="outline" className="border-blue-400/30 text-blue-300">
                    #{tag}
                  </Badge>
                ))}
              </div>
            )}

            <div className="flex items-center justify-between text-sm bg-slate-700/50 rounded-lg p-4">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1 text-pink-400">
                  <Heart size={16} fill="currentColor" /> {selectedCreation?.likes} likes
                </span>
                <span className="flex items-center gap-1 text-yellow-400">
                  <Star size={16} fill="currentColor" /> {selectedCreation?.rating_avg} ({selectedCreation?.rating_count})
                </span>
                <span className="flex items-center gap-1 text-blue-400">
                  <Share2 size={16} /> {selectedCreation?.shares} shares
                </span>
              </div>
              {selectedCreation?.viral_score > 80 && (
                <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                  🔥 Viral Score: {selectedCreation?.viral_score}/100
                </Badge>
              )}
            </div>

            <div className="bg-yellow-900/30 rounded-lg p-4 border border-yellow-500/30 text-center">
              <p className="text-yellow-200 mb-3">
                💡 Want to create similar content and compete in contests?
              </p>
              <Link to={createPageUrl("Landing")}>
                <Button className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600">
                  Join CreatiQuest
                  <ChevronRight className="ml-2" size={16} />
                </Button>
              </Link>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}