import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Wallet, ArrowUpRight, Clock, CheckCircle2, Loader2, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { useSearchParams } from "react-router-dom";

export default function Payout() {
  const [user, setUser] = useState(null);
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [connectLoading, setConnectLoading] = useState(false);
  const [searchParams] = useSearchParams();

  useEffect(() => {
    loadUser();
    
    // Check if returning from Stripe Connect onboarding
    if (searchParams.get('success') === 'true') {
      toast.success("Bank account connected successfully!");
    }
  }, [searchParams]);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  const handleConnectBank = async () => {
    setConnectLoading(true);
    try {
      const { data } = await base44.functions.invoke('createConnectAccount', {});
      
      if (data.url) {
        window.location.href = data.url;
      }
    } catch (error) {
      toast.error("Failed to create connect account");
      console.error(error);
    } finally {
      setConnectLoading(false);
    }
  };

  const handlePayout = async () => {
    const payoutAmount = parseFloat(amount);

    if (!payoutAmount || payoutAmount < 5) {
      toast.error("Minimum payout is €5");
      return;
    }

    if (payoutAmount > (user.tokens || 0)) {
      toast.error("Insufficient balance");
      return;
    }

    setLoading(true);
    try {
      const { data } = await base44.functions.invoke('createPayout', {
        amount: payoutAmount
      });

      if (data.needsOnboarding) {
        toast.error("Please connect your bank account first");
        return;
      }

      if (data.success) {
        toast.success(`Payout of €${payoutAmount.toFixed(2)} initiated!`);
        setAmount('');
        await loadUser(); // Reload user data
      }
    } catch (error) {
      toast.error(error.message || "Payout failed");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const hasConnectedBank = user?.stripe_account_id;
  const availableBalance = user?.tokens || 0;

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
          💰 Payout Center
        </h1>
        <p className="text-blue-300">Withdraw your earnings to your bank account</p>
      </div>

      {/* Balance Card */}
      <Card className="bg-gradient-to-br from-green-900/30 to-blue-900/30 border-green-500/30 mb-6">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Wallet className="text-green-400" />
            Available Balance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-5xl font-bold text-green-400 mb-2">
            €{availableBalance.toFixed(2)}
          </div>
          <p className="text-gray-400 text-sm">
            Earn more by winning contests and completing quests
          </p>
        </CardContent>
      </Card>

      {/* Bank Connection Status */}
      {!hasConnectedBank ? (
        <Card className="bg-slate-800/60 backdrop-blur border-yellow-500/30 mb-6">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <AlertCircle className="text-yellow-400 flex-shrink-0 mt-1" size={24} />
              <div className="flex-1">
                <h3 className="text-white font-semibold mb-2">Connect Your Bank Account</h3>
                <p className="text-gray-300 text-sm mb-4">
                  To receive payouts, you need to connect your bank account via Stripe. 
                  This is a secure one-time setup.
                </p>
                <Button
                  onClick={handleConnectBank}
                  disabled={connectLoading}
                  className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                >
                  {connectLoading ? (
                    <>
                      <Loader2 className="mr-2 animate-spin" size={16} />
                      Processing...
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="mr-2" size={16} />
                      Connect Bank Account
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-slate-800/60 backdrop-blur border-green-500/30 mb-6">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-green-400 mb-2">
              <CheckCircle2 size={20} />
              <span className="font-semibold">Bank Account Connected</span>
            </div>
            <p className="text-gray-400 text-sm">
              Your payouts will be sent to your connected bank account
            </p>
          </CardContent>
        </Card>
      )}

      {/* Payout Form */}
      <Card className="bg-slate-800/60 backdrop-blur border-purple-500/30 mb-6">
        <CardHeader>
          <CardTitle className="text-white">Request Payout</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Amount (€)</label>
              <Input
                type="number"
                min="5"
                step="0.01"
                max={availableBalance}
                placeholder="Minimum €5.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white"
                disabled={!hasConnectedBank}
              />
              <p className="text-xs text-gray-400 mt-1">
                Available: €{availableBalance.toFixed(2)} • Minimum: €5.00
              </p>
            </div>

            <Button
              onClick={handlePayout}
              disabled={loading || !hasConnectedBank || !amount || parseFloat(amount) < 5}
              className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 animate-spin" size={16} />
                  Processing...
                </>
              ) : (
                <>
                  <ArrowUpRight className="mr-2" size={16} />
                  Request Payout
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Info Card */}
      <Card className="bg-slate-800/60 backdrop-blur border-slate-600">
        <CardHeader>
          <CardTitle className="text-white text-lg">Payout Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex items-start gap-2">
            <Clock size={16} className="text-blue-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-white font-semibold">Processing Time</p>
              <p className="text-gray-400">1-3 business days after request</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Wallet size={16} className="text-green-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-white font-semibold">Minimum Amount</p>
              <p className="text-gray-400">€5.00 per payout</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 size={16} className="text-purple-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-white font-semibold">Supported Countries</p>
              <p className="text-gray-400">EU countries via SEPA transfer</p>
            </div>
          </div>
          <div className="bg-blue-900/30 rounded-lg p-3 border border-blue-500/30 mt-4">
            <p className="text-blue-200 text-xs">
              <strong>Tax Notice:</strong> You are responsible for reporting income from CreatiQuest 
              winnings to your local tax authority. We recommend consulting with a tax professional.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}