import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HelpCircle, ChevronDown, ChevronUp, Sparkles, Trophy, Target, Zap, Euro } from "lucide-react";
import { Button } from "@/components/ui/button";

const FAQItem = ({ question, answer, icon: Icon }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Card className="bg-slate-800/60 backdrop-blur border-blue-500/30 hover:border-blue-400 transition-all">
      <CardHeader>
        <Button
          variant="ghost"
          onClick={() => setIsOpen(!isOpen)}
          className="w-full justify-between text-left p-0 h-auto hover:bg-transparent"
        >
          <div className="flex items-center gap-3">
            {Icon && <Icon className="text-blue-400" size={20} />}
            <CardTitle className="text-white text-lg">{question}</CardTitle>
          </div>
          {isOpen ? <ChevronUp className="text-gray-400" /> : <ChevronDown className="text-gray-400" />}
        </Button>
      </CardHeader>
      {isOpen && (
        <CardContent className="text-gray-300 pt-0">
          {answer}
        </CardContent>
      )}
    </Card>
  );
};

export default function FAQ() {
  const faqs = [
    {
      question: "What is CreatiQuest?",
      answer: (
        <div className="space-y-2">
          <p>CreatiQuest is a gaming platform for creating content with AI. You create memes, videos, songs and texts, compete in contests and quests, earn real money.</p>
          <p><strong>3 game tiers:</strong></p>
          <ul className="list-disc ml-6">
            <li>🏆 Base (free) - Contests</li>
            <li>🎯 Premium (€4.99/mo) - Quests + specialization paths</li>
            <li>⚡ Elite (coming soon) - Strategies with ROI up to €500+</li>
          </ul>
        </div>
      ),
      icon: HelpCircle
    },
    {
      question: "How does the XP and level system work?",
      answer: (
        <div className="space-y-2">
          <p><strong>Earning XP:</strong></p>
          <ul className="list-disc ml-6 space-y-1">
            <li>+5 XP - like or share content</li>
            <li>+10 XP - rate creation (comment required)</li>
            <li>+15 XP - vote in polls</li>
            <li>+50 XP - publish creation</li>
            <li>+100-500 XP - win contest (top 10)</li>
            <li>+200-1000 XP - complete quest</li>
          </ul>
          <p className="mt-3"><strong>Levels:</strong> Level 1→2 needs 1000 XP, 2→3 needs 2000 XP, etc.</p>
          <p><strong>Bonus:</strong> +50 mana for every level up! 🎉</p>
        </div>
      ),
      icon: Zap
    },
    {
      question: "How to earn mana?",
      answer: (
        <div className="space-y-2">
          <p>Mana is energy for content creation and upgrades.</p>
          <ul className="list-disc ml-6 space-y-1">
            <li>+1 mana - like someone's creation</li>
            <li>+2 mana - rate creation (1-5 stars + comment)</li>
            <li>+5 mana - someone likes your creation</li>
            <li>+10 mana - vote in polls</li>
            <li>+10 mana - share creation on social media</li>
            <li>+20 mana - complete quest step</li>
            <li>+50 mana - level up bonus</li>
          </ul>
          <p className="mt-3"><strong>Cost:</strong> 20 mana for AI meme generation, 30-40 for video/songs.</p>
        </div>
      ),
      icon: Sparkles
    },
    {
      question: "How to participate in contests?",
      answer: (
        <div className="space-y-2">
          <p><strong>Steps:</strong></p>
          <ol className="list-decimal ml-6 space-y-1">
            <li>Open Studio → Choose content type</li>
            <li>When creating, select active contest (or skip)</li>
            <li>Write prompt or upload file</li>
            <li>Generate AI content (costs 20 mana)</li>
            <li>Publish your creation</li>
          </ol>
          <p className="mt-3"><strong>Voting:</strong> Other players like and rate. Top 10 by votes win prizes (€1-10).</p>
        </div>
      ),
      icon: Trophy
    },
    {
      question: "What are specialization paths?",
      answer: (
        <div className="space-y-2">
          <p>Available on Paid subscription (€4.99/mo). Choose one of 4 paths:</p>
          <ul className="list-disc ml-6 space-y-1">
            <li>🎭 <strong>Meme Path</strong> - Memes, viral content</li>
            <li>🎬 <strong>Reel Rush</strong> - Short videos, stories</li>
            <li>🎵 <strong>Melody Maze</strong> - Music, songs, sounds</li>
            <li>⚡ <strong>Combo Chaos</strong> - Mix formats, higher prizes</li>
          </ul>
          <p className="mt-3"><strong>Bonuses:</strong> Exclusive quests, special agents, enhanced perks (extra votes, view boosts).</p>
          <p><strong>Change path:</strong> 50 mana per respec.</p>
        </div>
      ),
      icon: Target
    },
    {
      question: "When will prize payouts be available?",
      answer: (
        <div className="space-y-2">
          <p><strong>Status:</strong> Payout system in development, launching Q1-Q2 2025.</p>
          <p><strong>How it works:</strong></p>
          <ul className="list-disc ml-6">
            <li>Accumulate tokens from wins</li>
            <li>Minimum withdrawal: €5</li>
            <li>Method: Stripe → bank account</li>
            <li>Processing: 1-3 business days</li>
          </ul>
          <p className="mt-3 text-yellow-300">Tokens accumulate in your profile - once we launch payouts, you can withdraw everything!</p>
        </div>
      ),
      icon: Euro
    },
    {
      question: "Can I delete my content?",
      answer: (
        <div className="space-y-2">
          <p><strong>Yes!</strong> You can delete your creations anytime through your profile.</p>
          <p><strong>Exception:</strong> Can't delete creations participating in active contests until completion (for voting fairness).</p>
          <p className="mt-3 text-sm text-gray-400">After account deletion, all your data is removed within 30 days (GDPR).</p>
        </div>
      ),
      icon: HelpCircle
    },
    {
      question: "What if AI doesn't generate content?",
      answer: (
        <div className="space-y-2">
          <p><strong>Reasons:</strong></p>
          <ul className="list-disc ml-6">
            <li>Not enough mana (need 20+)</li>
            <li>AI server overload (try again in 1-2 minutes)</li>
            <li>Prompt violates rules (NSFW, hate speech)</li>
          </ul>
          <p className="mt-3"><strong>Solution:</strong> System automatically retries 3 times. If it doesn't help - contact support@creatiquest.app.</p>
          <p className="text-blue-300">Mana is not deducted on error!</p>
        </div>
      ),
      icon: Sparkles
    },
    {
      question: "How does the referral program work?",
      answer: (
        <div className="space-y-2">
          <p><strong>Coming Soon!</strong> Soon you'll be able to invite friends and get bonuses:</p>
          <ul className="list-disc ml-6">
            <li>Unique referral link in profile</li>
            <li>+50 mana for you per friend</li>
            <li>+50 mana for friend on registration</li>
            <li>Additional rewards when friend subscribes</li>
          </ul>
          <p className="mt-3 text-purple-300">Stay tuned for updates!</p>
        </div>
      ),
      icon: HelpCircle
    },
    {
      question: "Is my data safe?",
      answer: (
        <div className="space-y-2">
          <p><strong>Yes!</strong> We comply with GDPR and DSA (EU):</p>
          <ul className="list-disc ml-6">
            <li>SSL/TLS encryption</li>
            <li>Servers in EU region</li>
            <li>Don't sell data to third parties</li>
            <li>Can request deletion of all data</li>
          </ul>
          <p className="mt-3">
            <a href="/privacy" className="text-blue-400 underline">Read full Privacy Policy →</a>
          </p>
        </div>
      ),
      icon: HelpCircle
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent flex items-center justify-center gap-3">
          <HelpCircle className="text-purple-400" size={40} />
          Frequently Asked Questions (FAQ)
        </h1>
        <p className="text-gray-400">Answers to the most popular questions about CreatiQuest</p>
      </div>

      <div className="space-y-4">
        {faqs.map((faq, index) => (
          <FAQItem key={index} {...faq} />
        ))}
      </div>

      <div className="mt-8 bg-gradient-to-r from-blue-900/30 to-purple-900/30 rounded-lg p-6 border border-blue-500/30 text-center">
        <p className="text-white font-semibold mb-2">Didn't find an answer to your question?</p>
        <p className="text-gray-300 mb-4">Contact us and we'll help!</p>
        <a href="mailto:support@creatiquest.app">
          <Button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600">
            Contact Support
          </Button>
        </a>
      </div>
    </div>
  );
}