import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Studio from "./Studio";

import Community from "./Community";

import Contests from "./Contests";

import Quests from "./Quests";

import SpecializationSelect from "./SpecializationSelect";

import Polls from "./Polls";

import Profile from "./Profile";

import Privacy from "./Privacy";

import Terms from "./Terms";

import FAQ from "./FAQ";

import Landing from "./Landing";

import Demo from "./Demo";

import Leaderboard from "./Leaderboard";

import Calendar from "./Calendar";

import ActivityFeed from "./ActivityFeed";

import Achievements from "./Achievements";

import Favorites from "./Favorites";

import Following from "./Following";

import Pricing from "./Pricing";

import SubscriptionSuccess from "./SubscriptionSuccess";

import Payout from "./Payout";

import Subscription from "./Subscription";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Studio: Studio,
    
    Community: Community,
    
    Contests: Contests,
    
    Quests: Quests,
    
    SpecializationSelect: SpecializationSelect,
    
    Polls: Polls,
    
    Profile: Profile,
    
    Privacy: Privacy,
    
    Terms: Terms,
    
    FAQ: FAQ,
    
    Landing: Landing,
    
    Demo: Demo,
    
    Leaderboard: Leaderboard,
    
    Calendar: Calendar,
    
    ActivityFeed: ActivityFeed,
    
    Achievements: Achievements,
    
    Favorites: Favorites,
    
    Following: Following,
    
    Pricing: Pricing,
    
    SubscriptionSuccess: SubscriptionSuccess,
    
    Payout: Payout,
    
    Subscription: Subscription,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Studio" element={<Studio />} />
                
                <Route path="/Community" element={<Community />} />
                
                <Route path="/Contests" element={<Contests />} />
                
                <Route path="/Quests" element={<Quests />} />
                
                <Route path="/SpecializationSelect" element={<SpecializationSelect />} />
                
                <Route path="/Polls" element={<Polls />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/Privacy" element={<Privacy />} />
                
                <Route path="/Terms" element={<Terms />} />
                
                <Route path="/FAQ" element={<FAQ />} />
                
                <Route path="/Landing" element={<Landing />} />
                
                <Route path="/Demo" element={<Demo />} />
                
                <Route path="/Leaderboard" element={<Leaderboard />} />
                
                <Route path="/Calendar" element={<Calendar />} />
                
                <Route path="/ActivityFeed" element={<ActivityFeed />} />
                
                <Route path="/Achievements" element={<Achievements />} />
                
                <Route path="/Favorites" element={<Favorites />} />
                
                <Route path="/Following" element={<Following />} />
                
                <Route path="/Pricing" element={<Pricing />} />
                
                <Route path="/SubscriptionSuccess" element={<SubscriptionSuccess />} />
                
                <Route path="/Payout" element={<Payout />} />
                
                <Route path="/Subscription" element={<Subscription />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}