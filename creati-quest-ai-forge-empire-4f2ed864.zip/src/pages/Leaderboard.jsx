import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, TrendingUp, Heart, Zap, Star, Crown } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Leaderboard() {
  const { data: allUsers = [] } = useQuery({
    queryKey: ['all-users'],
    queryFn: () => base44.entities.User.list('-level', 100),
    initialData: [],
  });

  const topByLevel = [...allUsers].sort((a, b) => (b.level || 0) - (a.level || 0)).slice(0, 10);
  const topByKarma = [...allUsers].sort((a, b) => (b.karma || 0) - (a.karma || 0)).slice(0, 10);
  const topByTokens = [...allUsers].sort((a, b) => (b.tokens || 0) - (a.tokens || 0)).slice(0, 10);

  const getRankIcon = (index) => {
    if (index === 0) return <Crown className="text-yellow-400" size={24} />;
    if (index === 1) return <Trophy className="text-gray-400" size={20} />;
    if (index === 2) return <Trophy className="text-orange-400" size={18} />;
    return <span className="text-gray-500 font-bold">{index + 1}</span>;
  };

  const LeaderboardList = ({ users, statKey, icon: Icon, label }) => (
    <div className="space-y-3">
      {users.map((user, index) => (
        <Card key={user.id} className={`bg-slate-800/60 backdrop-blur border-purple-500/30 ${index < 3 ? 'border-2' : ''}`}>
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className="w-12 flex items-center justify-center">
                {getRankIcon(index)}
              </div>
              <div className="flex-1">
                <h3 className="text-white font-semibold">{user.full_name || user.email}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline" className="text-xs border-blue-400/30 text-blue-300">
                    Level {user.level || 1}
                  </Badge>
                  {user.specialization_path && user.specialization_path !== 'none' && (
                    <span className="text-xs text-purple-300">{user.specialization_path}</span>
                  )}
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-2 text-xl font-bold text-purple-400">
                  <Icon size={20} />
                  {statKey === 'tokens' ? `€${user[statKey]?.toFixed(2) || '0.00'}` : user[statKey] || 0}
                </div>
                <span className="text-xs text-gray-400">{label}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
          🏆 Leaderboards
        </h1>
        <p className="text-blue-300">Top creators of CreatiQuest</p>
      </div>

      <Tabs defaultValue="level" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-slate-800 mb-6">
          <TabsTrigger value="level">
            <Zap size={16} className="mr-2" />
            Level
          </TabsTrigger>
          <TabsTrigger value="karma">
            <Heart size={16} className="mr-2" />
            Karma
          </TabsTrigger>
          <TabsTrigger value="tokens">
            <Trophy size={16} className="mr-2" />
            Earnings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="level">
          <LeaderboardList 
            users={topByLevel} 
            statKey="level" 
            icon={Zap}
            label="Level"
          />
        </TabsContent>

        <TabsContent value="karma">
          <LeaderboardList 
            users={topByKarma} 
            statKey="karma" 
            icon={Heart}
            label="Karma"
          />
        </TabsContent>

        <TabsContent value="tokens">
          <LeaderboardList 
            users={topByTokens} 
            statKey="tokens" 
            icon={Trophy}
            label="Earned"
          />
        </TabsContent>
      </Tabs>

      <div className="mt-8 bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-lg p-6 border border-purple-500/30 text-center">
        <TrendingUp className="mx-auto mb-3 text-purple-400" size={32} />
        <p className="text-white font-semibold mb-2">Want to climb the rankings?</p>
        <p className="text-gray-300 text-sm">
          Create quality content, engage with community, and complete quests!
        </p>
      </div>
    </div>
  );
}