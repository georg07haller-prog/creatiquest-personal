import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Heart, Star, Share2, MessageCircle, Filter, Search, X, Play, Music, Sparkles, Loader2, Download, Copy, Mail, TrendingUp, Bookmark } from "lucide-react";
import CommentSection from "../components/CommentSection";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// LevelUpNotification Component
function LevelUpNotification({ level, onClose }) {
  useEffect(() => {
    // Optionally close after a few seconds
    const timer = setTimeout(() => {
      onClose();
    }, 5000); // Close after 5 seconds
    return () => clearTimeout(timer);
  }, [level, onClose]);

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-gradient-to-br from-purple-700 to-pink-700 border-purple-500/50 text-white max-w-sm rounded-lg shadow-lg">
        <DialogHeader>
          <DialogTitle className="text-3xl font-extrabold text-center flex items-center justify-center gap-2">
            <Sparkles size={32} className="text-yellow-300" />
            LEVEL UP!
            <Sparkles size={32} className="text-yellow-300" />
          </DialogTitle>
          <DialogDescription className="text-xl text-center text-gray-200 mt-2">
            You reached Level {level}!
          </DialogDescription>
        </DialogHeader>
        <div className="text-center space-y-4">
          <p className="text-lg text-gray-100">
            Congratulations, fellow eco-warrior! You've gained new insights and power.
          </p>
          <div className="flex items-center justify-center gap-2 text-yellow-300 font-bold text-lg">
            <TrendingUp size={24} /> +50 Mana Bonus!
          </div>
          <Button
            onClick={onClose}
            className="w-full bg-yellow-400 text-purple-900 font-bold hover:bg-yellow-300 transition-colors"
          >
            Awesome!
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function Community() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [selectedCreation, setSelectedCreation] = useState(null);
  const [ratingDialog, setRatingDialog] = useState(false);
  const [viewDialog, setViewDialog] = useState(false);
  const [shareDialog, setShareDialog] = useState(false);
  const [suggestionDialog, setSuggestionDialog] = useState(false);
  const [emailDialog, setEmailDialog] = useState(false);
  const [emailTo, setEmailTo] = useState('');
  const [commentsDialog, setCommentsDialog] = useState(false);
  const [suggestion, setSuggestion] = useState({
    type: 'contest',
    title: '',
    description: ''
  });
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [levelUpNotification, setLevelUpNotification] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const checkAndHandleLevelUp = async (newXP, currentLevel) => {
    // XP needed for the next level (e.g., Level 1 needs 1000 XP for Level 2)
    const xpNeededForNextLevel = currentLevel * 1000;
    
    if (newXP >= xpNeededForNextLevel) {
      const newLevel = currentLevel + 1;
      const updatedUser = await base44.auth.updateMe({
        level: newLevel,
        experience_points: newXP, // Update XP to the new total
        mana: (user.mana || 0) + 50 // Level up bonus
      });
      
      setLevelUpNotification(newLevel); // Trigger notification
      
      return updatedUser; // Return the updated user object
    }
    return null; // No level up
  };

  const { data: creations = [] } = useQuery({
    queryKey: ['community-creations'],
    queryFn: () => base44.entities.Creation.filter({ status: 'published' }, '-created_date', 50),
    initialData: [],
  });

  const addToFavoritesMutation = useMutation({
    mutationFn: async (creation) => {
      await base44.entities.Favorite.create({
        creation_id: creation.id
      });
    },
    onSuccess: () => {
      toast.success("Added to favorites! ❤️");
    },
  });

  const likeMutation = useMutation({
    mutationFn: async (creation) => {
      await base44.entities.Rating.create({
        creation_id: creation.id,
        is_like: true
      });
      await base44.entities.Creation.update(creation.id, {
        likes: creation.likes + 1
      });
      
      if (user) {
        const newXP = (user.experience_points || 0) + 5; // +5 XP for liking
        const updatedUser = await base44.auth.updateMe({ 
          mana: (user.mana || 0) + 1,
          experience_points: newXP
        });
        
        // Check for level up after updating XP
        const potentiallyLeveledUpUser = await checkAndHandleLevelUp(newXP, user.level || 1);
        
        return potentiallyLeveledUpUser || updatedUser; // Return the most updated user object
      }
      return null;
    },
    onSuccess: (updatedUser) => {
      queryClient.invalidateQueries({ queryKey: ['community-creations'] });
      if (updatedUser) {
        setUser(updatedUser);
        window.dispatchEvent(new Event('userUpdated')); // Inform other components about user update
      }
      toast.success("+5 mana to creator, +1 mana & +5 XP to you!"); // Updated toast message
    },
  });

  const rateMutation = useMutation({
    mutationFn: async ({ creation, rating, comment }) => {
      await base44.entities.Rating.create({
        creation_id: creation.id,
        rating: rating,
        comment: comment
      });
      
      const newAvg = ((creation.rating_avg * creation.rating_count) + rating) / (creation.rating_count + 1);
      await base44.entities.Creation.update(creation.id, {
        rating_avg: newAvg,
        rating_count: creation.rating_count + 1
      });

      if (user) {
        const newXP = (user.experience_points || 0) + 10; // +10 XP for rating
        const updatedUser = await base44.auth.updateMe({ 
          mana: (user.mana || 0) + 2,
          karma: (user.karma || 0) + 2,
          experience_points: newXP
        });
        
        // Check for level up after updating XP
        const potentiallyLeveledUpUser = await checkAndHandleLevelUp(newXP, user.level || 1);
        
        return potentiallyLeveledUpUser || updatedUser; // Return the most updated user object
      }
      return null;
    },
    onSuccess: (updatedUser) => {
      queryClient.invalidateQueries({ queryKey: ['community-creations'] });
      setRatingDialog(false);
      setComment('');
      setRating(5);
      if (updatedUser) {
        setUser(updatedUser);
        window.dispatchEvent(new Event('userUpdated')); // Inform other components about user update
      }
      toast.success("+2 mana, +2 karma, and +10 XP for rating!"); // Updated toast message
    },
  });

  const emailMutation = useMutation({
    mutationFn: async ({ email, creation }) => {
      const htmlBody = `
        <h2>Check out this creation from CreatiQuest!</h2>
        <h3>${creation.title}</h3>
        ${creation.image_url ? `<img src="${creation.image_url}" alt="${creation.title}" style="max-width: 600px; border-radius: 8px;" />` : ''}
        <p>${creation.content || ''}</p>
        <p><strong>Created by:</strong> Level ${user?.level || 1} player</p>
        <p><strong>Stats:</strong> ❤️ ${creation.likes || 0} likes | ⭐ ${(creation.rating_avg || 0).toFixed(1)} rating</p>
        <br/>
        <p><a href="${window.location.origin}/share?id=${creation.id}" style="background: #8b5cf6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block;">View in CreatiQuest</a></p>
        <br/>
        <p style="color: #666; font-size: 12px;">#CreatiQuest #AIArt #EcoMeme</p>
      `;
      
      await base44.integrations.Core.SendEmail({
        to: email,
        subject: `CreatiQuest: ${creation.title}`,
        body: htmlBody
      });
    },
    onSuccess: () => {
      setEmailDialog(false);
      setEmailTo('');
      toast.success("Email sent! 📧");
    },
    onError: () => {
      toast.error("Failed to send email");
    }
  });

  const suggestionMutation = useMutation({
    mutationFn: async (data) => {
      await base44.integrations.Core.SendEmail({
        to: 'support@creatiquest.app',
        subject: `New ${data.type} suggestion from ${user?.email || 'anonymous'}`,
        body: `
Type: ${data.type}
Title: ${data.title}
Description: ${data.description}

From: ${user?.email || 'anonymous'}
Level: ${user?.level || 1}
        `
      });
    },
    onSuccess: () => {
      setSuggestionDialog(false);
      setSuggestion({ type: 'contest', title: '', description: '' });
      toast.success("Suggestion sent! Thank you! 🎉");
    },
  });

  const handleSuggestion = () => {
    if (!suggestion.title || !suggestion.description) {
      toast.error("Fill in title and description");
      return;
    }
    if (suggestion.description.length < 20) {
      toast.error("Description must be at least 20 characters");
      return;
    }
    suggestionMutation.mutate(suggestion);
  };

  const handleSendEmail = () => {
    if (!emailTo || !emailTo.includes('@')) {
      toast.error("Enter valid email address");
      return;
    }
    emailMutation.mutate({ email: emailTo, creation: selectedCreation });
  };

  const handleLike = (creation) => {
    likeMutation.mutate(creation);
  };

  const handleRate = () => {
    if (comment.length < 10) {
      toast.error("Comment must be at least 10 characters");
      return;
    }
    rateMutation.mutate({ creation: selectedCreation, rating, comment });
  };

  const handleShare = async (creation) => {
    const shareText = `Forged in CreatiQuest Level ${user?.level || 1}: ${creation.title}\n\n#CreatiQuest #AIArt #EcoMeme`;
    const shareUrl = window.location.origin + '/share?id=' + creation.id;
    
    try {
      await base44.entities.Creation.update(creation.id, {
        shares: (creation.shares || 0) + 1
      });
      
      if (user) {
        const newXP = (user.experience_points || 0) + 5; // +5 XP for sharing
        const updatedUserAfterXP = await base44.auth.updateMe({ 
          mana: (user.mana || 0) + 10,
          experience_points: newXP
        });
        
        const potentiallyLeveledUpUser = await checkAndHandleLevelUp(newXP, user.level || 1);
        
        setUser(potentiallyLeveledUpUser || updatedUserAfterXP); // Update local user state with the latest version
        window.dispatchEvent(new Event('userUpdated')); // Inform other components
      }
      
      queryClient.invalidateQueries({ queryKey: ['community-creations'] });

      if (navigator.share && navigator.canShare && navigator.canShare({ url: shareUrl })) {
        try {
          await navigator.share({
            title: creation.title,
            text: shareText,
            url: shareUrl
          });
          toast.success("+10 mana & +5 XP for sharing!"); // Updated toast message
          return;
        } catch (shareError) {
          if (shareError.name !== 'AbortError') {
            console.log("Native share not available, showing dialog");
          } else {
            return;
          }
        }
      }
      
      setSelectedCreation(creation);
      setShareDialog(true);
      toast.success("+10 mana & +5 XP! Choose how to share:"); // Updated toast message
      
    } catch (error) {
      console.error('Share failed:', error);
      toast.error("Couldn't update share count");
    }
  };

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard!");
    } catch (error) {
      const textArea = document.createElement("textarea");
      textArea.value = text;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      toast.success("Copied to clipboard!");
    }
  };

  const downloadImage = async (imageUrl, filename) => {
    try {
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename || 'creation.jpg';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast.success("Image downloaded! 📥");
    } catch (error) {
      toast.error("Couldn't download image");
      console.error(error);
    }
  };

  const shareToTwitter = (creation) => {
    const text = `Forged in CreatiQuest Level ${user?.level || 1}: ${creation.title}\n\n#CreatiQuest #AIArt #EcoMeme`;
    const url = `${window.location.origin}/share?id=${creation.id}`;
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
    window.open(twitterUrl, '_blank', 'width=550,height=420');
  };

  const shareToFacebook = (creation) => {
    const url = `${window.location.origin}/share?id=${creation.id}`;
    const fbUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
    window.open(fbUrl, '_blank', 'width=550,height=420');
  };

  const shareToTelegram = (creation) => {
    const text = `Forged in CreatiQuest Level ${user?.level || 1}: ${creation.title}\n\n#CreatiQuest #AIArt #EcoMeme`;
    const url = `${window.location.origin}/share?id=${creation.id}`;
    const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
    window.open(telegramUrl, '_blank');
  };

  const shareToWhatsApp = (creation) => {
    const text = `Forged in CreatiQuest Level ${user?.level || 1}: ${creation.title}\n\n#CreatiQuest #AIArt #EcoMeme\n\n${window.location.origin}/share?id=${creation.id}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleView = (creation) => {
    setSelectedCreation(creation);
    setViewDialog(true);
  };

  const filteredCreations = creations.filter(c => {
    const matchesSearch = c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         c.content?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || c.type === filterType;
    return matchesSearch && matchesType;
  });

  const contentTypes = [
    { value: 'all', label: 'All', icon: '🎨' },
    { value: 'meme', label: 'Memes', icon: '🎭' },
    { value: 'song', label: 'Songs', icon: '🎵' },
    { value: 'video', label: 'Videos', icon: '🎬' },
    { value: 'text', label: 'Texts', icon: '📝' }
  ];

  const getTypeIcon = (type) => {
    if (type === 'video') return <Play size={24} className="text-white" />;
    if (type === 'song') return <Music size={24} className="text-white" />;
    return null;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Level Up Notification */}
      {levelUpNotification && (
        <LevelUpNotification 
          level={levelUpNotification} 
          onClose={() => setLevelUpNotification(null)} 
        />
      )}

      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Community
            </h1>
            <p className="text-blue-300">Rate other's work and earn karma!</p>
          </div>
          <Button
            onClick={() => setSuggestionDialog(true)}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            <Sparkles className="mr-2" size={16} />
            Suggest Theme
          </Button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="mb-6 space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <Input
            placeholder="Search creations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-slate-800/60 border-slate-600 text-white"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2">
          {contentTypes.map(type => (
            <Button
              key={type.value}
              variant={filterType === type.value ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType(type.value)}
              className={filterType === type.value ? 
                "bg-gradient-to-r from-purple-500 to-pink-500" : 
                "border-slate-600 text-gray-300"
              }
            >
              <span className="mr-1">{type.icon}</span>
              {type.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Creations Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCreations.map((creation) => (
          <Card key={creation.id} className="bg-slate-800/60 backdrop-blur border-purple-500/30 hover:border-purple-400 transition-all overflow-hidden group">
            {creation.image_url && (
              <div 
                className="aspect-video relative overflow-hidden cursor-pointer"
                onClick={() => handleView(creation)}
              >
                <img 
                  src={creation.image_url} 
                  alt={creation.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  {getTypeIcon(creation.type)}
                </div>
                <div className="absolute top-2 right-2">
                  <Badge className="bg-purple-500/80 backdrop-blur">
                    {contentTypes.find(t => t.value === creation.type)?.icon} {creation.type}
                  </Badge>
                </div>
              </div>
            )}
            
            <CardContent className="p-4">
              <h3 
                className="text-lg font-bold text-white mb-2 line-clamp-2 cursor-pointer hover:text-purple-300 transition-colors"
                onClick={() => handleView(creation)}
              >
                {creation.title}
              </h3>
              {creation.content && (
                <p className="text-sm text-gray-400 mb-4 line-clamp-3">{creation.content}</p>
              )}

              {creation.tags && creation.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-4">
                  {creation.tags.slice(0, 3).map((tag, i) => (
                    <Badge key={i} variant="outline" className="text-xs border-blue-400/30 text-blue-300">
                      #{tag}
                    </Badge>
                  ))}
                </div>
              )}

              <div className="flex items-center justify-between mb-4 text-sm">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1 text-pink-400">
                    <Heart size={16} fill="currentColor" /> {creation.likes || 0}
                  </span>
                  <span className="flex items-center gap-1 text-yellow-400">
                    <Star size={16} fill="currentColor" /> {(creation.rating_avg || 0).toFixed(1)} ({creation.rating_count || 0})
                  </span>
                  <span className="flex items-center gap-1 text-blue-400">
                    <Share2 size={16} /> {creation.shares || 0}
                  </span>
                </div>
                {(creation.viral_score || 0) > 70 && (
                  <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                    🔥 Viral
                  </Badge>
                )}
              </div>

              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleLike(creation)}
                  className="flex-1 border-pink-500/30 text-pink-300 hover:bg-pink-500/20"
                >
                  <Heart size={16} className="mr-1" />
                  Like
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setSelectedCreation(creation);
                    setRatingDialog(true);
                  }}
                  className="flex-1 border-yellow-500/30 text-yellow-300 hover:bg-yellow-500/20"
                >
                  <Star size={16} className="mr-1" />
                  Rate
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleShare(creation)}
                  className="border-blue-500/30 text-blue-300 hover:bg-blue-500/20"
                >
                  <Share2 size={16} />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredCreations.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-400 text-lg">No creations found</p>
        </div>
      )}

      {/* Share Dialog */}
      <Dialog open={shareDialog} onOpenChange={setShareDialog}>
        <DialogContent className="bg-slate-800 border-blue-500/30 max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Share2 className="text-blue-400" />
              Share Creation
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {selectedCreation && (
              <>
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <h3 className="text-white font-bold mb-2">{selectedCreation.title}</h3>
                  {selectedCreation.image_url && (
                    <img 
                      src={selectedCreation.image_url} 
                      alt={selectedCreation.title}
                      className="w-full h-48 object-cover rounded-lg mb-3"
                    />
                  )}
                  <p className="text-gray-400 text-sm">
                    Forged in CreatiQuest Level {user?.level || 1}
                  </p>
                </div>

                {/* Quick Actions */}
                <div className="grid grid-cols-2 gap-3">
                  {/* Download Image */}
                  {selectedCreation.image_url && (
                    <Button
                      onClick={() => downloadImage(selectedCreation.image_url, `${selectedCreation.title.replace(/\s+/g, '_')}.jpg`)}
                      className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
                    >
                      <Download className="mr-2" size={18} />
                      Download
                    </Button>
                  )}
                  
                  {/* Send Email */}
                  <Button
                    onClick={() => {
                      setShareDialog(false);
                      setEmailDialog(true);
                    }}
                    className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
                  >
                    <Mail className="mr-2" size={18} />
                    Email
                  </Button>
                </div>

                {/* Social Media Share */}
                <div>
                  <label className="text-sm text-gray-300 mb-2 block font-semibold">Share to Social Media:</label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      onClick={() => shareToTwitter(selectedCreation)}
                      className="bg-black hover:bg-gray-900 text-white"
                    >
                      𝕏 Twitter
                    </Button>
                    <Button
                      onClick={() => shareToFacebook(selectedCreation)}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      📘 Facebook
                    </Button>
                    <Button
                      onClick={() => shareToTelegram(selectedCreation)}
                      className="bg-sky-500 hover:bg-sky-600 text-white"
                    >
                      ✈️ Telegram
                    </Button>
                    <Button
                      onClick={() => shareToWhatsApp(selectedCreation)}
                      className="bg-green-600 hover:bg-green-700 text-white"
                    >
                      💬 WhatsApp
                    </Button>
                  </div>
                </div>

                {/* Copy Text */}
                <div>
                  <label className="text-sm text-gray-300 mb-2 block font-semibold">Copy Text:</label>
                  <Button
                    onClick={() => {
                      const fullText = `Forged in CreatiQuest Level ${user?.level || 1}: ${selectedCreation.title}\n\n#CreatiQuest #AIArt #EcoMeme\n\n${window.location.origin}/share?id=${selectedCreation.id}`;
                      copyToClipboard(fullText);
                    }}
                    variant="outline"
                    className="w-full border-purple-400 text-purple-300"
                  >
                    <Copy className="mr-2" size={18} />
                    Copy Text + Link
                  </Button>
                </div>

                {/* Copy Link Only */}
                <div className="pt-2 border-t border-slate-600">
                  <label className="text-sm text-gray-400 mb-2 block">Or copy link only:</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      readOnly
                      value={`${window.location.origin}/share?id=${selectedCreation.id}`}
                      className="flex-1 bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
                    />
                    <Button
                      onClick={() => copyToClipboard(`${window.location.origin}/share?id=${selectedCreation.id}`)}
                      variant="outline"
                      className="border-blue-400 text-blue-300"
                    >
                      Copy
                    </Button>
                  </div>
                </div>

                <div className="bg-green-900/30 border border-green-500/30 rounded-lg p-3 text-center">
                  <p className="text-green-300 font-semibold">
                    ✨ You earned +10 mana for sharing!
                  </p>
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Email Dialog */}
      <Dialog open={emailDialog} onOpenChange={setEmailDialog}>
        <DialogContent className="bg-slate-800 border-orange-500/30 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Mail className="text-orange-400" />
              Send via Email
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {selectedCreation && (
              <>
                <div className="bg-slate-700/50 rounded-lg p-3">
                  <p className="text-white font-semibold mb-1">{selectedCreation.title}</p>
                  <p className="text-gray-400 text-sm">Will be sent with image and link</p>
                </div>

                <div>
                  <label className="text-sm text-gray-300 mb-2 block">Recipient Email *</label>
                  <Input
                    type="email"
                    placeholder="friend@example.com"
                    value={emailTo}
                    onChange={(e) => setEmailTo(e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>

                <Button
                  onClick={handleSendEmail}
                  disabled={emailMutation.isPending}
                  className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
                >
                  {emailMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 animate-spin" size={16} />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Mail className="mr-2" size={16} />
                      Send Email
                    </>
                  )}
                </Button>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* View Content Dialog */}
      <Dialog open={viewDialog} onOpenChange={setViewDialog}>
        <DialogContent className="bg-slate-800 border-purple-500/30 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center justify-between">
              <span>{selectedCreation?.title}</span>
              <Badge className="bg-purple-500/80">
                {contentTypes.find(t => t.value === selectedCreation?.type)?.icon} {selectedCreation?.type}
              </Badge>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {selectedCreation?.image_url && (
              <div className="rounded-lg overflow-hidden">
                {selectedCreation.type === 'video' ? (
                  <div className="relative aspect-video bg-black">
                    <img 
                      src={selectedCreation.image_url} 
                      alt={selectedCreation.title}
                      className="w-full h-full object-contain"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="bg-purple-500/80 backdrop-blur rounded-full p-6">
                        <Play size={48} className="text-white" />
                      </div>
                    </div>
                    <p className="absolute bottom-4 left-4 right-4 text-center text-white bg-black/60 rounded p-2 text-sm">
                      Video preview - full playback coming soon!
                    </p>
                  </div>
                ) : selectedCreation.type === 'song' ? (
                  <div className="relative aspect-video bg-gradient-to-br from-purple-900 to-blue-900">
                    <img 
                      src={selectedCreation.image_url} 
                      alt={selectedCreation.title}
                      className="w-full h-full object-cover opacity-40"
                    />
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-8">
                      <Music size={64} className="text-purple-300 mb-4" />
                      <h3 className="text-2xl font-bold text-white mb-4">{selectedCreation.title}</h3>
                      <div className="bg-slate-800/80 backdrop-blur rounded-lg p-4 max-w-lg max-h-64 overflow-y-auto">
                        <p className="text-white whitespace-pre-wrap text-center">{selectedCreation.content}</p>
                      </div>
                      <p className="mt-4 text-gray-300 text-sm">Audio playback coming soon!</p>
                    </div>
                  </div>
                ) : (
                  <img 
                    src={selectedCreation.image_url} 
                    alt={selectedCreation.title}
                    className="w-full h-auto max-h-[50vh] object-contain"
                  />
                )}
              </div>
            )}

            {selectedCreation?.content && selectedCreation?.type !== 'song' && (
              <div className="bg-slate-700/50 rounded-lg p-4 max-h-48 overflow-y-auto">
                <p className="text-white whitespace-pre-wrap">{selectedCreation.content}</p>
              </div>
            )}

            {selectedCreation?.tags && selectedCreation.tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {selectedCreation.tags.map((tag, i) => (
                  <Badge key={i} variant="outline" className="border-blue-400/30 text-blue-300">
                    #{tag}
                  </Badge>
                ))}
              </div>
            )}

            <div className="flex items-center justify-between text-sm bg-slate-700/50 rounded-lg p-4">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1 text-pink-400">
                  <Heart size={16} fill="currentColor" /> {selectedCreation?.likes || 0} likes
                </span>
                <span className="flex items-center gap-1 text-yellow-400">
                  <Star size={16} fill="currentColor" /> {(selectedCreation?.rating_avg || 0).toFixed(1)} ({selectedCreation?.rating_count || 0})
                </span>
                <span className="flex items-center gap-1 text-blue-400">
                  <Share2 size={16} /> {selectedCreation?.shares || 0} shares
                </span>
              </div>
              {(selectedCreation?.viral_score || 0) > 70 && (
                <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                  🔥 Viral Score: {selectedCreation?.viral_score}/100
                </Badge>
              )}
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  handleLike(selectedCreation);
                }}
                className="flex-1 border-pink-500/30 text-pink-300 hover:bg-pink-500/20"
              >
                <Heart size={16} className="mr-2" />
                Like
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setViewDialog(false);
                  setRatingDialog(true);
                }}
                className="flex-1 border-yellow-500/30 text-yellow-300 hover:bg-yellow-500/20"
              >
                <Star size={16} className="mr-2" />
                Rate
              </Button>
              <Button
                variant="outline"
                onClick={() => handleShare(selectedCreation)}
                className="flex-1 border-blue-500/30 text-blue-300 hover:bg-blue-500/20"
              >
                <Share2 size={16} className="mr-2" />
                Share
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Rating Dialog */}
      <Dialog open={ratingDialog} onOpenChange={setRatingDialog}>
        <DialogContent className="bg-slate-800 border-purple-500/30 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">Rate Creation</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {selectedCreation && (
              <div>
                <h3 className="text-white font-semibold mb-2">{selectedCreation.title}</h3>
                {selectedCreation.content && (
                  <p className="text-gray-400 text-sm line-clamp-3">{selectedCreation.content}</p>
                )}
              </div>
            )}

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Rating</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setRating(star)}
                    className="transition-transform hover:scale-110"
                  >
                    <Star
                      size={32}
                      className={star <= rating ? "text-yellow-400 fill-yellow-400" : "text-gray-600"}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Comment (min. 10 characters)</label>
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Write what you liked or what could be improved..."
                className="bg-slate-700 border-slate-600 text-white min-h-24"
              />
              <p className="text-xs text-gray-400 mt-1">{comment.length} characters</p>
            </div>

            <Button
              onClick={handleRate}
              disabled={comment.length < 10 || rateMutation.isPending}
              className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
            >
              Submit Rating (+2 points)
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Suggestion Dialog */}
      <Dialog open={suggestionDialog} onOpenChange={setSuggestionDialog}>
        <DialogContent className="bg-slate-800 border-purple-500/30 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Sparkles className="text-purple-400" />
              Suggest New Theme
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-gray-300 text-sm">
              Share your ideas for new contests, quests, or strategies! 
              The best suggestions will be implemented in the game.
            </p>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Type</label>
              <Select value={suggestion.type} onValueChange={(v) => setSuggestion(prev => ({ ...prev, type: v }))}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="contest">🏆 Contest Theme</SelectItem>
                  <SelectItem value="quest">🎯 Quest Idea</SelectItem>
                  <SelectItem value="strategy">⚡ Strategy Concept</SelectItem>
                  <SelectItem value="feature">✨ New Feature</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Title *</label>
              <Input
                placeholder="E.g: Eco-Transport Challenge"
                value={suggestion.title}
                onChange={(e) => setSuggestion(prev => ({ ...prev, title: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-white"
              />
            </div>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Description * (min 20 chars)</label>
              <Textarea
                placeholder="Describe your idea in detail..."
                value={suggestion.description}
                onChange={(e) => setSuggestion(prev => ({ ...prev, description: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-white min-h-32"
              />
              <p className="text-xs text-gray-400 mt-1">{suggestion.description.length} characters</p>
            </div>

            <div className="bg-blue-900/30 rounded-lg p-3 border border-blue-500/30">
              <p className="text-blue-200 text-sm">
                💡 <strong>Tip:</strong> Be specific! Include theme details, prize suggestions, eco-angle, target audience.
              </p>
            </div>

            <Button
              onClick={handleSuggestion}
              disabled={!suggestion.title || suggestion.description.length < 20 || suggestionMutation.isPending}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            >
              {suggestionMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 animate-spin" size={16} />
                  Sending...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2" size={16} />
                  Send Suggestion
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}