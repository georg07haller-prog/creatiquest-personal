import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trophy, Clock, Euro, Users, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, differenceInHours } from "date-fns";

export default function Contests() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: contests = [] } = useQuery({
    queryKey: ['all-contests'],
    queryFn: () => base44.entities.Contest.list('-created_date'),
    initialData: [],
  });

  const { data: creations = [] } = useQuery({
    queryKey: ['contest-creations'],
    queryFn: () => base44.entities.Creation.filter({ status: 'published' }, '-likes', 100),
    initialData: [],
  });

  const getContestCreations = (contestId) => {
    return creations.filter(c => c.contest_id === contestId);
  };

  const getTimeRemaining = (endDate) => {
    const hours = differenceInHours(new Date(endDate), new Date());
    if (hours < 0) return 'Ended';
    if (hours < 24) return `${hours}h`;
    const days = Math.floor(hours / 24);
    return `${days}d`;
  };

  const getStatusBadge = (status) => {
    const badges = {
      upcoming: { label: 'Soon', color: 'bg-blue-500' },
      active: { label: 'Active', color: 'bg-green-500' },
      voting: { label: 'Voting', color: 'bg-yellow-500' },
      completed: { label: 'Ended', color: 'bg-gray-500' }
    };
    return badges[status] || badges.active;
  };

  const activeContests = contests.filter(c => c.status === 'active');
  const votingContests = contests.filter(c => c.status === 'voting');
  const upcomingContests = contests.filter(c => c.status === 'upcoming');

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
          Contest Arena
        </h1>
        <p className="text-blue-300">Compete and win prizes!</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card className="bg-gradient-to-br from-green-900/30 to-green-800/30 border-green-500/30">
          <CardContent className="pt-6 text-center">
            <div className="text-2xl font-bold text-green-400">{activeContests.length}</div>
            <div className="text-sm text-gray-400">Active</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-yellow-900/30 to-yellow-800/30 border-yellow-500/30">
          <CardContent className="pt-6 text-center">
            <div className="text-2xl font-bold text-yellow-400">{votingContests.length}</div>
            <div className="text-sm text-gray-400">Voting</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-blue-900/30 to-blue-800/30 border-blue-500/30">
          <CardContent className="pt-6 text-center">
            <div className="text-2xl font-bold text-blue-400">{upcomingContests.length}</div>
            <div className="text-sm text-gray-400">Upcoming</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-purple-900/30 to-purple-800/30 border-purple-500/30">
          <CardContent className="pt-6 text-center">
            <div className="text-2xl font-bold text-purple-400">
              €{contests.reduce((sum, c) => sum + (c.prize_pool || 0), 0)}
            </div>
            <div className="text-sm text-gray-400">Prize Pool</div>
          </CardContent>
        </Card>
      </div>

      {/* Active Contests */}
      {activeContests.length > 0 && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
            <Trophy className="text-yellow-400" />
            Active Contests
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {activeContests.map((contest) => {
              const contestCreations = getContestCreations(contest.id);
              return (
                <Card key={contest.id} className="bg-slate-800/60 backdrop-blur border-yellow-500/30 hover:border-yellow-400 transition-all overflow-hidden">
                  {contest.image_url && (
                    <div className="aspect-video relative overflow-hidden">
                      <img 
                        src={contest.image_url} 
                        alt={contest.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-3 right-3 flex gap-2">
                        <Badge className={`${getStatusBadge(contest.status).color} text-white`}>
                          {getStatusBadge(contest.status).label}
                        </Badge>
                        {contest.eco_badge && (
                          <Badge className="bg-green-500/80 text-white">
                            🌱 Eco
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                  
                  <CardHeader>
                    <CardTitle className="text-white text-xl">{contest.title}</CardTitle>
                    <p className="text-gray-400 text-sm">{contest.description}</p>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <div className="bg-gradient-to-r from-yellow-900/30 to-orange-900/30 rounded-lg p-4 border border-yellow-500/30">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-400">Prize Pool</span>
                        <span className="text-xl font-bold text-yellow-400 flex items-center gap-1">
                          <Euro size={20} />
                          {contest.prize_pool || 0}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Participants</span>
                        <span className="text-white font-semibold flex items-center gap-1">
                          <Users size={16} />
                          {contestCreations.length}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400 flex items-center gap-1">
                        <Clock size={16} />
                        Remaining: {getTimeRemaining(contest.end_date)}
                      </span>
                      {(contest.entry_fee || 0) > 0 && (
                        <Badge variant="outline" className="border-orange-500/30 text-orange-300">
                          Fee: €{contest.entry_fee}
                        </Badge>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Link to={createPageUrl("Studio")}>
                        <Button className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                          <Sparkles className="mr-2" />
                          Create Entry
                        </Button>
                      </Link>
                      {contestCreations.length > 0 && (
                        <Link to={createPageUrl("Community")}>
                          <Button variant="outline" className="w-full border-blue-400 text-blue-300 hover:bg-blue-500/20">
                            View Entries ({contestCreations.length})
                          </Button>
                        </Link>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Voting Contests */}
      {votingContests.length > 0 && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
            <Users className="text-blue-400" />
            Voting Now
          </h2>
          <div className="grid md:grid-cols-3 gap-4">
            {votingContests.map((contest) => {
              const contestCreations = getContestCreations(contest.id).sort((a, b) => (b.likes || 0) - (a.likes || 0));
              return (
                <Card key={contest.id} className="bg-slate-800/60 backdrop-blur border-blue-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">{contest.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm text-gray-400">
                      Top 3 Leaders:
                    </div>
                    {contestCreations.slice(0, 3).map((creation, idx) => (
                      <div key={creation.id} className="flex items-center gap-3 bg-slate-700/50 rounded-lg p-2">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                          idx === 0 ? 'bg-yellow-500 text-white' :
                          idx === 1 ? 'bg-gray-400 text-white' :
                          'bg-orange-500 text-white'
                        }`}>
                          {idx + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-white text-sm font-semibold truncate">{creation.title}</p>
                          <p className="text-gray-400 text-xs">❤️ {creation.likes || 0} likes</p>
                        </div>
                      </div>
                    ))}
                    <Link to={createPageUrl("Community")}>
                      <Button variant="outline" className="w-full border-blue-400 text-blue-300 mt-2">
                        Vote Now
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Upcoming Contests */}
      {upcomingContests.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
            <Clock className="text-purple-400" />
            Coming Soon
          </h2>
          <div className="grid md:grid-cols-3 gap-4">
            {upcomingContests.map((contest) => (
              <Card key={contest.id} className="bg-slate-800/60 backdrop-blur border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-white text-lg">{contest.title}</CardTitle>
                  <p className="text-gray-400 text-sm">{contest.theme}</p>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Starts:</span>
                    <span className="text-white">
                      {format(new Date(contest.start_date), 'MMM dd, HH:mm')}
                    </span>
                  </div>
                  <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                    Prize: €{contest.prize_pool}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {contests.length === 0 && (
        <div className="text-center py-12">
          <Trophy className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 text-lg">No contests yet</p>
          <p className="text-gray-500 text-sm mt-2">New contests coming soon!</p>
        </div>
      )}
    </div>
  );
}