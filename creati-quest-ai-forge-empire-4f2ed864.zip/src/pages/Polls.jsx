
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Vote, TrendingUp, CheckCircle, Clock, Zap, Award } from "lucide-react";
import { toast } from "sonner";
import { format, differenceInHours } from "date-fns";

// Basic placeholder LevelUpNotification component to ensure file functionality.
// In a real application, this would be a more sophisticated component.
const LevelUpNotification = ({ level, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 5000); // Notification disappears after 5 seconds
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed top-20 right-4 z-50 p-4 bg-gradient-to-br from-purple-700 to-pink-500 text-white rounded-lg shadow-lg flex items-center space-x-3 animate-fade-in-down">
      <Award size={32} className="flex-shrink-0" />
      <div>
        <p className="font-bold text-lg">Level Up! 🎉</p>
        <p>You reached level {level}!</p>
        <p className="text-sm">Bonus: +50 Mana!</p>
      </div>
      <button onClick={onClose} className="text-white opacity-70 hover:opacity-100 transition-opacity">
        &times;
      </button>
    </div>
  );
};


export default function Polls() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [levelUpNotification, setLevelUpNotification] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const checkAndHandleLevelUp = async (newXP, currentLevel) => {
    const xpNeededForNextLevel = currentLevel * 1000;
    const totalXP = newXP;
    
    if (totalXP >= xpNeededForNextLevel) {
      const newLevel = currentLevel + 1;
      // Note: `base44.auth.updateMe` needs to be able to update 'mana' and 'experience_points'
      // The current `user` object passed to `updateMe` might not have the latest mana/xp
      // from the current transaction, but base44.auth.updateMe handles the state on the server.
      // We pass the new level and XP to the update function.
      const updatedUser = await base44.auth.updateMe({
        level: newLevel,
        experience_points: totalXP, // Store accumulated XP
        mana: (user.mana || 0) + 50 // Level up bonus
      });
      
      // Update local user state and trigger notification
      setUser(updatedUser);
      setLevelUpNotification(newLevel);
      window.dispatchEvent(new Event('userUpdated')); // To update header/layout
      
      return updatedUser;
    }
    return null;
  };

  const { data: polls = [] } = useQuery({
    queryKey: ['polls'],
    queryFn: () => base44.entities.Poll.filter({ status: 'active' }, '-created_date'),
    initialData: [],
  });

  const { data: myVotes = [] } = useQuery({
    queryKey: ['my-votes', user?.email],
    queryFn: () => user ? base44.entities.PollVote.filter({ created_by: user.email }) : [],
    initialData: [],
    enabled: !!user
  });

  const voteMutation = useMutation({
    mutationFn: async ({ poll, optionId }) => {
      await base44.entities.PollVote.create({
        poll_id: poll.id,
        option_id: optionId,
        mana_earned: poll.reward_mana
      });

      const updatedOptions = poll.options.map(opt =>
        opt.id === optionId ? { ...opt, votes: opt.votes + 1 } : opt
      );

      await base44.entities.Poll.update(poll.id, {
        options: updatedOptions
      });

      // Calculate new XP
      const newXP = (user.experience_points || 0) + 15;

      const updatedUser = await base44.auth.updateMe({
        mana: (user.mana || 0) + poll.reward_mana,
        karma: (user.karma || 0) + 1,
        experience_points: newXP // Update experience points
      });

      // Check for level up after updating user
      // Pass the potentially updated user's level from the `updatedUser` object
      // or fall back to 1 if it's not set (new user)
      await checkAndHandleLevelUp(newXP, updatedUser.level || 1); 
      
      return { updatedUser, poll };
    },
    onSuccess: ({ updatedUser, poll }) => {
      queryClient.invalidateQueries({ queryKey: ['polls'] });
      queryClient.invalidateQueries({ queryKey: ['my-votes'] });
      setUser(updatedUser);
      
      // Force reload to update Layout header (already present)
      window.dispatchEvent(new Event('userUpdated'));
      
      toast.success(`+${poll.reward_mana} mana, +1 karma, and +15 XP for voting! 🎉`);
    },
  });

  const handleVote = (poll, optionId) => {
    if (!user) {
      toast.error("Login to vote!");
      return;
    }

    const alreadyVoted = myVotes.some(v => v.poll_id === poll.id);
    if (alreadyVoted) {
      toast.error("You already voted in this poll!");
      return;
    }

    voteMutation.mutate({ poll, optionId });
  };

  const getTimeRemaining = (deadline) => {
    const hours = differenceInHours(new Date(deadline), new Date());
    if (hours < 0) return 'Ended';
    if (hours < 24) return `${hours}h`;
    const days = Math.floor(hours / 24);
    return `${days}d`;
  };

  const getPathColor = (path) => {
    const colors = {
      meme_path: 'from-green-500 to-emerald-500',
      reel_rush: 'from-blue-500 to-cyan-500',
      melody_maze: 'from-purple-500 to-pink-500',
      combo_chaos: 'from-pink-500 to-orange-500',
      all: 'from-yellow-500 to-orange-500'
    };
    return colors[path] || colors.all;
  };

  const getPathName = (path) => {
    const names = {
      meme_path: '🎭 Meme Path',
      reel_rush: '🎬 Reel Rush',
      melody_maze: '🎵 Melody Maze',
      combo_chaos: '⚡ Combo Chaos',
      all: '🌟 All Paths'
    };
    return names[path] || names.all;
  };

  const hasVoted = (pollId) => myVotes.some(v => v.poll_id === pollId);

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Level Up Notification */}
      {levelUpNotification && (
        <LevelUpNotification 
          level={levelUpNotification} 
          onClose={() => setLevelUpNotification(null)} 
        />
      )}

      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
          Community Polls
        </h1>
        <p className="text-blue-300">Vote for next quests and earn mana & karma!</p>
      </div>

      {polls.length === 0 ? (
        <div className="text-center py-12">
          <Vote className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 text-lg">No active polls</p>
          <p className="text-gray-500 text-sm mt-2">Complete quests to unlock community polls!</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-6">
          {polls.map((poll) => {
            const voted = hasVoted(poll.id);
            const totalVotes = poll.options.reduce((sum, opt) => sum + opt.votes, 0);
            
            return (
              <Card key={poll.id} className="bg-slate-800/60 backdrop-blur border-yellow-500/30 hover:border-yellow-400 transition-all">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <Badge className={`bg-gradient-to-r ${getPathColor(poll.specialization_path)} text-white`}>
                      {getPathName(poll.specialization_path)}
                    </Badge>
                    <Badge variant="outline" className="border-blue-400/30 text-blue-300">
                      <Clock size={14} className="mr-1" />
                      {getTimeRemaining(poll.deadline)}
                    </Badge>
                  </div>
                  <CardTitle className="text-white text-xl">{poll.title}</CardTitle>
                  {poll.description && (
                    <p className="text-gray-400 text-sm mt-2">{poll.description}</p>
                  )}
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="bg-gradient-to-r from-yellow-900/30 to-orange-900/30 rounded-lg p-3 border border-yellow-500/30">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-300">Reward for voting:</span>
                      <span className="text-yellow-400 font-bold flex items-center gap-1">
                        <Zap size={16} />
                        +{poll.reward_mana} mana
                      </span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {poll.options.map((option) => {
                      const percentage = totalVotes > 0 ? (option.votes / totalVotes * 100).toFixed(1) : 0;
                      
                      return (
                        <div key={option.id} className="relative">
                          <Button
                            onClick={() => handleVote(poll, option.id)}
                            disabled={voted || voteMutation.isPending}
                            variant="outline"
                            className={`w-full text-left justify-start relative overflow-hidden border-2 transition-all ${
                              voted 
                                ? 'border-gray-600 text-gray-400 cursor-not-allowed' 
                                : 'border-purple-500/30 text-white hover:border-purple-400 hover:bg-purple-500/10'
                            }`}
                          >
                            {/* Vote percentage background */}
                            {voted && (
                              <div 
                                className="absolute inset-0 bg-purple-500/20 transition-all"
                                style={{ width: `${percentage}%` }}
                              />
                            )}
                            
                            <div className="relative z-10 w-full">
                              <div className="flex items-center justify-between">
                                <div className="flex-1">
                                  <p className="font-semibold">{option.title}</p>
                                  {option.description && (
                                    <p className="text-xs text-gray-400 mt-1">{option.description}</p>
                                  )}
                                </div>
                                {voted && (
                                  <div className="ml-4 flex items-center gap-2">
                                    <span className="text-sm font-bold text-purple-300">{percentage}%</span>
                                    <TrendingUp size={16} className="text-purple-400" />
                                  </div>
                                )}
                              </div>
                            </div>
                          </Button>

                          {voted && (
                            <div className="absolute top-2 right-2 z-20">
                              <CheckCircle className="text-green-400" size={20} />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {voted ? (
                    <div className="bg-green-900/30 border border-green-500/30 rounded-lg p-3 text-center">
                      <p className="text-green-300 font-semibold flex items-center justify-center gap-2">
                        <CheckCircle size={18} />
                        You voted in this poll!
                      </p>
                      <p className="text-xs text-gray-400 mt-1">
                        Total votes: {totalVotes}
                      </p>
                    </div>
                  ) : (
                    <p className="text-center text-sm text-gray-400">
                      Click an option to vote and earn {poll.reward_mana} mana
                    </p>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
