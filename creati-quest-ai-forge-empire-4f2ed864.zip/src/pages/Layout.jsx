
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Home, Trophy, Target, Sparkles, Users, Menu, X, Vote, HelpCircle, Book, Info, TrendingUp, Heart, Calendar as CalendarIcon, Activity } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [guideDialog, setGuideDialog] = useState(false);
  const [resourceDialog, setResourceDialog] = useState(false);

  useEffect(() => {
    loadUser();
    
    // Listen for user updates from other components
    const handleUserUpdate = () => {
      loadUser();
    };
    
    window.addEventListener('userUpdated', handleUserUpdate);
    
    return () => {
      window.removeEventListener('userUpdated', handleUserUpdate);
    };
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const navItems = [
    { title: "Home", url: createPageUrl("Dashboard"), icon: Home },
    { title: "Contests", url: createPageUrl("Contests"), icon: Trophy },
    { title: "Quests", url: createPageUrl("Quests"), icon: Target },
    { title: "Studio", url: createPageUrl("Studio"), icon: Sparkles },
    { title: "Community", url: createPageUrl("Community"), icon: Users },
  ];

  const getLevelProgress = () => {
    if (!user) return 0;
    const xpForNextLevel = (user.level || 1) * 1000;
    const currentXP = (user.experience_points || 0) % xpForNextLevel;
    return (currentXP / xpForNextLevel) * 100;
  };

  const getPathIcon = (path) => {
    const icons = {
      meme_path: '🎭',
      reel_rush: '🎬',
      melody_maze: '🎵',
      combo_chaos: '⚡',
      none: ''
    };
    return icons[path] || '';
  };

  const getPathName = (path) => {
    const names = {
      meme_path: 'Meme Path',
      reel_rush: 'Reel Rush',
      melody_maze: 'Melody Maze',
      combo_chaos: 'Combo Chaos',
      none: 'No Path'
    };
    return names[path] || 'No Path';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <style>{`
        :root {
          --primary-green: #4CAF50;
          --primary-blue: #2196F3;
        }
        
        .mana-glow {
          box-shadow: 0 0 20px rgba(76, 175, 80, 0.5);
        }
        
        .parallax-bg {
          background-image: url('https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=1920');
          background-attachment: fixed;
          background-size: cover;
          background-position: center;
        }
      `}</style>

      {/* Top Bar */}
      <header className="bg-slate-900/80 backdrop-blur-md border-b border-blue-500/30 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <Link to={createPageUrl("Dashboard")} className="flex items-center gap-2">
              <div className="w-9 h-9 md:w-10 md:h-10 bg-gradient-to-br from-green-400 to-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-xl md:text-2xl">⚒️</span>
              </div>
              <div className="hidden sm:block">
                <h1 className="font-bold text-white text-base md:text-lg whitespace-nowrap">CreatiQuest</h1>
                <p className="text-xs text-blue-300 whitespace-nowrap">AI Forge Empire</p>
              </div>
            </Link>

            {user && (
              <div className="flex items-center gap-1 md:gap-3">
                {/* Help & Legal Links */}
                <Link to={createPageUrl("FAQ")}>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-300 hover:text-white hover:bg-slate-700 hidden lg:flex"
                  >
                    FAQ
                  </Button>
                </Link>

                <Link to={createPageUrl("Privacy")}>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-300 hover:text-white hover:bg-slate-700 hidden lg:flex"
                  >
                    Privacy
                  </Button>
                </Link>

                <Link to={createPageUrl("Terms")}>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-300 hover:text-white hover:bg-slate-700 hidden lg:flex"
                  >
                    Terms
                  </Button>
                </Link>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setResourceDialog(true)}
                  className="text-blue-300 hover:text-blue-200 hover:bg-blue-500/20 hidden md:flex"
                  title="How to earn resources"
                >
                  <Info size={16} className="md:mr-1" />
                  <span className="hidden lg:inline">Resources</span>
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setGuideDialog(true)}
                  className="text-purple-300 hover:text-purple-200 hover:bg-purple-500/20 hidden sm:flex"
                  title="User Guide"
                >
                  <Book size={16} />
                </Button>

                {/* Additional Links */}
                <Link to={createPageUrl("Leaderboard")}>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-300 hover:text-white hover:bg-slate-700 hidden lg:flex"
                    title="Leaderboard"
                  >
                    <Trophy size={16} />
                  </Button>
                </Link>

                <Link to={createPageUrl("Achievements")}>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-300 hover:text-white hover:bg-slate-700 hidden lg:flex"
                    title="Achievements"
                  >
                    🏆
                  </Button>
                </Link>

                <Link to={createPageUrl("Favorites")}>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-300 hover:text-white hover:bg-slate-700 hidden sm:flex"
                    title="Favorites"
                  >
                    <Heart size={16} />
                  </Button>
                </Link>

                {/* Profile Link */}
                <Link to={createPageUrl("Profile")}>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-300 hover:text-white hover:bg-slate-700 hidden sm:flex"
                    title="Profile"
                  >
                    <Users size={16} />
                  </Button>
                </Link>

                {/* Specialization Path */}
                {user.specialization_path && user.specialization_path !== 'none' && (
                  <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-purple-500/20 rounded-lg border border-purple-400/30">
                    <span className="text-lg">{getPathIcon(user.specialization_path)}</span>
                    <span className="text-xs text-purple-300">{getPathName(user.specialization_path)}</span>
                  </div>
                )}

                {/* Level Progress */}
                <div className="hidden sm:flex flex-col">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs text-blue-300">Level {user.level || 1}</span>
                    <span className="text-xs text-gray-400">{(user.experience_points || 0) % ((user.level || 1) * 1000)}/{((user.level || 1) * 1000)}</span>
                  </div>
                  <div className="w-32 h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-green-400 to-blue-500 transition-all duration-500"
                      style={{ width: `${getLevelProgress()}%` }}
                    />
                  </div>
                </div>

                {/* Mana */}
                <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-green-500/20 rounded-lg border border-green-400/30 mana-glow">
                  <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" />
                  <span className="text-sm font-semibold text-green-300">{user.mana || 0}</span>
                </div>

                {/* Karma */}
                <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-pink-500/20 rounded-lg border border-pink-400/30">
                  <span className="text-sm">❤️</span>
                  <span className="text-sm font-semibold text-pink-300">{user.karma || 0}</span>
                </div>

                {/* Tokens */}
                <div className="flex items-center gap-1 px-2 py-1.5 md:px-3 bg-yellow-500/20 rounded-lg border border-yellow-400/30 flex-shrink-0">
                  <span className="text-xs md:text-sm">💰</span>
                  <span className="text-xs md:text-sm font-semibold text-yellow-300">{(user.tokens || 0).toFixed(2)}€</span>
                </div>

                {/* Mobile Menu Toggle */}
                <button
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="md:hidden text-white p-1.5 flex-shrink-0"
                >
                  {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-slate-800 border-t border-blue-500/30">
            <div className="container mx-auto px-4 py-4">
              {user && (
                <div className="grid grid-cols-2 gap-3 mb-4">
                  {user.specialization_path && user.specialization_path !== 'none' && (
                    <div className="col-span-2 bg-purple-500/20 rounded-lg p-3 border border-purple-400/30">
                      <div className="text-xs text-gray-400 mb-1">Path</div>
                      <div className="text-lg font-bold text-purple-300 flex items-center gap-2">
                        <span>{getPathIcon(user.specialization_path)}</span>
                        {getPathName(user.specialization_path)}
                      </div>
                    </div>
                  )}
                  <div className="bg-slate-700/50 rounded-lg p-3">
                    <div className="text-xs text-gray-400 mb-1">Level</div>
                    <div className="text-lg font-bold text-white">{user.level || 1}</div>
                  </div>
                  <div className="bg-green-500/20 rounded-lg p-3 border border-green-400/30">
                    <div className="text-xs text-gray-400 mb-1">Mana</div>
                    <div className="text-lg font-bold text-green-300">{user.mana || 0}</div>
                  </div>
                  <div className="col-span-2 flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setResourceDialog(true);
                        setMobileMenuOpen(false);
                      }}
                      className="flex-1 border-blue-400/30 text-blue-300"
                    >
                      <Info size={16} className="mr-1" />
                      How to Earn
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setGuideDialog(true);
                        setMobileMenuOpen(false);
                      }}
                      className="flex-1 border-purple-400/30 text-purple-300"
                    >
                      <Book size={16} className="mr-1" />
                      Guide
                    </Button>
                  </div>
                  <div className="col-span-2 grid grid-cols-3 gap-2">
                    <Link to={createPageUrl("FAQ")} onClick={() => setMobileMenuOpen(false)}>
                      <Button size="sm" variant="outline" className="w-full border-gray-400/30 text-gray-300">
                        FAQ
                      </Button>
                    </Link>
                    <Link to={createPageUrl("Privacy")} onClick={() => setMobileMenuOpen(false)}>
                      <Button size="sm" variant="outline" className="w-full border-gray-400/30 text-gray-300 text-xs">
                        Privacy
                      </Button>
                    </Link>
                    <Link to={createPageUrl("Terms")} onClick={() => setMobileMenuOpen(false)}>
                      <Button size="sm" variant="outline" className="w-full border-gray-400/30 text-gray-300 text-xs">
                        Terms
                      </Button>
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Resource Guide Dialog */}
      <Dialog open={resourceDialog} onOpenChange={setResourceDialog}>
        <DialogContent className="bg-slate-800 border-blue-500/30 max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Info className="text-blue-400" />
              How to Earn Resources
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            {/* XP & Level System */}
            <div className="bg-gradient-to-br from-blue-900/30 to-blue-800/30 rounded-lg p-4 border border-blue-500/30">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <TrendingUp className="text-blue-400" size={18} />
                </div>
                <h3 className="text-xl font-bold text-blue-300">XP & Levels</h3>
              </div>
              <p className="text-gray-300 mb-3">Gain experience to level up and unlock features.</p>
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <span className="text-blue-400 mt-0.5">+5 XP</span>
                  <span className="text-gray-300">Like someone's creation or share content</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-blue-400 mt-0.5">+10 XP</span>
                  <span className="text-gray-300">Rate a creation (1-5 stars + comment)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-blue-400 mt-0.5">+15 XP</span>
                  <span className="text-gray-300">Vote in community polls</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-blue-400 mt-0.5">+50 XP</span>
                  <span className="text-gray-300">Publish new creation</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-blue-400 mt-0.5">+100-500 XP</span>
                  <span className="text-gray-300">Win contests (top 10 placement)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-blue-400 mt-0.5">+200-1000 XP</span>
                  <span className="text-gray-300">Complete quest chains</span>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-blue-500/30">
                <p className="text-sm text-gray-400">
                  <strong>Level Up:</strong> Level 1→2 needs 1000 XP, Level 2→3 needs 2000 XP, etc.<br/>
                  <strong>Rewards:</strong> +50 mana bonus per level up! 🎉
                </p>
              </div>
            </div>

            {/* Mana */}
            <div className="bg-gradient-to-br from-green-900/30 to-green-800/30 rounded-lg p-4 border border-green-500/30">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" />
                </div>
                <h3 className="text-xl font-bold text-green-300">Mana (Energy)</h3>
              </div>
              <p className="text-gray-300 mb-3">Virtual energy for content creation and upgrades.</p>
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <span className="text-green-400 mt-0.5">+1</span>
                  <span className="text-gray-300">Give a like to someone's creation</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 mt-0.5">+2</span>
                  <span className="text-gray-300">Rate a creation (1-5 stars + comment)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 mt-0.5">+5</span>
                  <span className="text-gray-300">Someone likes your creation</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 mt-0.5">+10</span>
                  <span className="text-gray-300">Vote in community polls</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 mt-0.5">+10</span>
                  <span className="text-gray-300">Share creation on social media</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-green-400 mt-0.5">+20</span>
                  <span className="text-gray-300">Complete quest steps</span>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-green-500/30">
                <p className="text-sm text-gray-400"><strong>Uses:</strong> 20 mana for AI content generation, 50+ mana for upgrades (coming soon)</p>
              </div>
            </div>

            {/* Karma */}
            <div className="bg-gradient-to-br from-pink-900/30 to-pink-800/30 rounded-lg p-4 border border-pink-500/30">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 bg-pink-500/20 rounded-lg flex items-center justify-center">
                  <span className="text-lg">❤️</span>
                </div>
                <h3 className="text-xl font-bold text-pink-300">Karma (Reputation)</h3>
              </div>
              <p className="text-gray-300 mb-3">Social reputation for community contributions.</p>
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <span className="text-pink-400 mt-0.5">+1</span>
                  <span className="text-gray-300">Vote in polls</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-pink-400 mt-0.5">+2</span>
                  <span className="text-gray-300">Write quality reviews (rating + comment)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-pink-400 mt-0.5">+5</span>
                  <span className="text-gray-300">Collaborate on content (coming soon)</span>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-pink-500/30">
                <p className="text-sm text-gray-400"><strong>Future uses:</strong> Extra contest entries, custom skins, exclusive perks</p>
              </div>
            </div>

            {/* Tokens */}
            <div className="bg-gradient-to-br from-yellow-900/30 to-yellow-800/30 rounded-lg p-4 border border-yellow-500/30">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                  <span className="text-lg">💰</span>
                </div>
                <h3 className="text-xl font-bold text-yellow-300">Money (Tokens)</h3>
              </div>
              <p className="text-gray-300 mb-3">Earn tokens through wins - real money payouts coming soon!</p>
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <span className="text-yellow-400 mt-0.5">€1-10</span>
                  <span className="text-gray-300">Win contests (top 10 rankings)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-yellow-400 mt-0.5">€40-80</span>
                  <span className="text-gray-300">Complete quest chains (by path)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-yellow-400 mt-0.5">€80-150</span>
                  <span className="text-gray-300">Combo Chaos path quests</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-yellow-400 mt-0.5">€200+</span>
                  <span className="text-gray-300">Elite tier strategies (coming soon)</span>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-yellow-500/30">
                <p className="text-sm text-gray-400"><strong>Coming soon:</strong> Withdraw to bank via Stripe (min €5, 1-3 days)</p>
              </div>
            </div>

            <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-500/30 text-center">
              <p className="text-blue-200">💡 <strong>Tip:</strong> Share your creations often to maximize mana! Focus on community engagement.</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Full User Guide Dialog */}
      <Dialog open={guideDialog} onOpenChange={setGuideDialog}>
        <DialogContent className="bg-slate-800 border-purple-500/30 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Book className="text-purple-400" />
              CreatiQuest User Guide
            </DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="intro" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-slate-700">
              <TabsTrigger value="intro">Intro</TabsTrigger>
              <TabsTrigger value="gameplay">Gameplay</TabsTrigger>
              <TabsTrigger value="tiers">Tiers</TabsTrigger>
              <TabsTrigger value="rules">Rules</TabsTrigger>
            </TabsList>

            <TabsContent value="intro" className="space-y-4 mt-4">
              <div className="prose prose-invert max-w-none">
                <h3 className="text-xl font-bold text-white mb-3">Welcome to CreatiQuest!</h3>
                <p className="text-gray-300">
                  CreatiQuest: AI Forge Empire combines creative content generation, AI, and strategy. 
                  Create memes, videos, songs, and texts using AI, compete in contests and quests, 
                  build your empire, and earn real money.
                </p>
                <h4 className="text-lg font-bold text-white mt-4 mb-2">Getting Started</h4>
                <ul className="space-y-2 text-gray-300">
                  <li>✅ Visit creatiquest.app</li>
                  <li>✅ Register with email, Google, or Apple ID</li>
                  <li>✅ You start at Level 1 with 100 mana</li>
                  <li>✅ Explore the dashboard tabs (Home, Contests, Quests, Polls, Studio, Community)</li>
                  <li>✅ Create your first content in Studio</li>
                </ul>
                <h4 className="text-lg font-bold text-white mt-4 mb-2">Progression System</h4>
                <div className="space-y-2 text-gray-300">
                  <p><strong className="text-blue-300">Experience Points (XP):</strong> Earned from all actions - creating, voting, rating, sharing. Accumulate XP to level up!</p>
                  <p><strong className="text-purple-300">Levels:</strong> Automatically advance when you earn enough XP. Each level needs more XP than the last (Level 1→2: 1000 XP, Level 2→3: 2000 XP).</p>
                  <p><strong className="text-yellow-300">Level Up Rewards:</strong> Get +50 mana bonus every time you level up! Higher levels unlock better quest opportunities.</p>
                </div>
                <h4 className="text-lg font-bold text-white mt-4 mb-2">Game Resources</h4>
                <div className="space-y-2 text-gray-300">
                  <p><strong className="text-green-300">Mana:</strong> Energy for creating content (20 per generation). Earned from likes, shares, ratings, polls.</p>
                  <p><strong className="text-pink-300">Karma:</strong> Social reputation from community engagement. Track your contributions!</p>
                  <p><strong className="text-yellow-300">Tokens:</strong> Virtual currency earned from wins. Real money payouts coming soon via Stripe.</p>
                </div>
                <h4 className="text-lg font-bold text-white mt-4 mb-2">Game Setting</h4>
                <p className="text-gray-300">
                  The game takes place in <strong className="text-purple-300">Neo-Europe</strong>, 
                  a stylized virtual city inspired by Amsterdam, Berlin, Prague, and other European cities, 
                  with a strong focus on <strong className="text-green-300">sustainability</strong> and eco-themes.
                </p>
              </div>
            </TabsContent>

            <TabsContent value="gameplay" className="space-y-4 mt-4">
              <div className="space-y-4">
                <div className="bg-yellow-900/30 rounded-lg p-4 border border-yellow-500/30">
                  <h4 className="text-lg font-bold text-yellow-300 mb-2">🏆 Contests (Base Tier - FREE)</h4>
                  <ul className="space-y-1 text-gray-300 text-sm">
                    <li>• Daily/weekly challenges with eco-themes</li>
                    <li>• Create content: Use AI (costs 20 mana) or upload your own</li>
                    <li>• Choose contest when publishing in Studio</li>
                    <li>• Vote for others: Like (+1 mana to you, +5 to creator), Rate (+2 mana)</li>
                    <li>• Filter community by content type (memes, videos, songs)</li>
                    <li>• Top 10 by votes win tokens (1st place: up to €10)</li>
                    <li>• Share on social media for +10 mana</li>
                  </ul>
                </div>

                <div className="bg-green-900/30 rounded-lg p-4 border border-green-500/30">
                  <h4 className="text-lg font-bold text-green-300 mb-2">🎯 Quests (Premium Tier - €4.99/month)</h4>
                  <ul className="space-y-1 text-gray-300 text-sm">
                    <li>• Choose specialization path: Meme Path 🎭, Reel Rush 🎬, Melody Maze 🎵, or Combo Chaos ⚡</li>
                    <li>• Access sponsored quest chains with real prizes (€40-150)</li>
                    <li>• Each quest has steps with hints and deadlines</li>
                    <li>• Community polls decide next quests (+10 mana for voting)</li>
                    <li>• Path perks: Extra votes, view boosts, special agents</li>
                    <li>• Respec path: Costs 50 mana per change</li>
                  </ul>
                  <p className="text-xs text-gray-400 mt-2">⚠️ Path selection unlocks with paid subscription</p>
                </div>

                <div className="bg-purple-900/30 rounded-lg p-4 border border-purple-500/30">
                  <h4 className="text-lg font-bold text-purple-300 mb-2">⚡ Strategies (Elite Tier - Coming Soon)</h4>
                  <ul className="space-y-1 text-gray-300 text-sm">
                    <li>• Requires subscription + 1000 experience points</li>
                    <li>• Long-term empire building with AI agents</li>
                    <li>• Invest mana for upgrades and viral simulations</li>
                    <li>• Community governance through polls</li>
                    <li>• Potential ROI: €200-500+ with royalty shares</li>
                  </ul>
                  <p className="text-xs text-purple-300 mt-2">🚀 Under development - Stay tuned!</p>
                </div>

                <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-500/30">
                  <h4 className="text-lg font-bold text-blue-300 mb-2">👥 Community</h4>
                  <ul className="space-y-1 text-gray-300 text-sm">
                    <li>• Browse all published creations</li>
                    <li>• Filter by content type: memes, videos, songs, texts</li>
                    <li>• Search by title or tags</li>
                    <li>• Like: +5 mana to creator, +1 to you</li>
                    <li>• Rate 1-5 stars + write review (min 10 chars): +2 mana</li>
                    <li>• Share to X, Facebook, WhatsApp: +10 mana</li>
                    <li>• View full content with images and descriptions</li>
                  </ul>
                  <p className="text-xs text-gray-400 mt-2">💡 More features coming: Collaborations, chat rooms, advanced filters</p>
                </div>

                <div className="bg-slate-700/50 rounded-lg p-4 border border-slate-500/30">
                  <h4 className="text-lg font-bold text-white mb-2">🎨 Studio</h4>
                  <ul className="space-y-1 text-gray-300 text-sm">
                    <li>• 3-step creation process: Setup → Generate → Publish</li>
                    <li>• Choose content type: Meme (20 mana), Song (30 mana), Video (40 mana), Text (15 mana)</li>
                    <li>• Write detailed AI prompt for best results</li>
                    <li>• AI generates both text content and image automatically</li>
                    <li>• Or upload your own files instead</li>
                    <li>• Select contest to participate (optional)</li>
                    <li>• Add title, tags, and publish to community</li>
                  </ul>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="tiers" className="space-y-4 mt-4">
              <div className="space-y-4">
                <div className="bg-gradient-to-br from-blue-900/30 to-blue-800/30 rounded-lg p-4 border border-blue-500/30">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                      <Trophy className="text-blue-400" size={20} />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-blue-300">Base Tier: Contest Arena</h4>
                      <p className="text-xs text-gray-400">FREE - Available immediately</p>
                    </div>
                  </div>
                  <ul className="space-y-1 text-gray-300 text-sm">
                    <li>✅ Daily and weekly contests</li>
                    <li>✅ AI content generation (20 mana per use)</li>
                    <li>✅ Community voting and ratings</li>
                    <li>✅ Social media sharing</li>
                    <li>✅ Browse all community creations</li>
                    <li>✅ Win up to €10 per contest</li>
                  </ul>
                  <p className="text-xs text-blue-300 mt-3"><strong>Upgrade:</strong> €4.99/month for Premium features</p>
                </div>

                <div className="bg-gradient-to-br from-green-900/30 to-green-800/30 rounded-lg p-4 border border-green-500/30">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                      <Target className="text-green-400" size={20} />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-green-300">Premium Tier: Quest Labyrinth</h4>
                      <p className="text-xs text-gray-400">€4.99/month subscription</p>
                    </div>
                  </div>
                  <ul className="space-y-1 text-gray-300 text-sm">
                    <li>✅ All Base features +</li>
                    <li>✅ Choose specialization path (4 options)</li>
                    <li>✅ Access to sponsored quest chains</li>
                    <li>✅ Path-specific perks and bonuses</li>
                    <li>✅ Community governance polls (+10 mana per vote)</li>
                    <li>✅ Win €40-150 per quest chain</li>
                    <li>✅ Exclusive path-themed content</li>
                  </ul>
                  <p className="text-xs text-green-300 mt-3"><strong>Subscribe</strong> to unlock quest system and path selection</p>
                </div>

                <div className="bg-gradient-to-br from-purple-900/30 to-purple-800/30 rounded-lg p-4 border border-purple-500/30">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
                      <Sparkles className="text-purple-400" size={20} />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-purple-300">Elite Tier: Strategy Forge</h4>
                      <p className="text-xs text-gray-400">Coming Soon - Requires subscription + 1000 XP</p>
                    </div>
                  </div>
                  <ul className="space-y-1 text-gray-300 text-sm">
                    <li>🚀 All Premium features +</li>
                    <li>🚀 Long-term strategy building</li>
                    <li>🚀 Advanced AI agents system</li>
                    <li>🚀 Mana investments for upgrades</li>
                    <li>🚀 ROI up to €200-500+</li>
                    <li>🚀 Royalty shares from viral content</li>
                    <li>🚀 Empire building narrative journal</li>
                  </ul>
                  <p className="text-xs text-purple-300 mt-3">⏳ <strong>Under development</strong> - Launching Q2 2025</p>
                </div>

                <div className="bg-yellow-900/30 rounded-lg p-4 border border-yellow-500/30 text-center">
                  <p className="text-yellow-200"><strong>💡 Start with Base tier</strong> to learn mechanics, then upgrade when ready!</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="rules" className="space-y-4 mt-4">
              <div className="prose prose-invert max-w-none text-sm">
                <h4 className="text-lg font-bold text-white mb-2">📜 Game Rules</h4>
                
                <div className="bg-slate-700/50 rounded-lg p-3 mb-3">
                  <h5 className="text-white font-semibold mb-2">Eligibility</h5>
                  <p className="text-gray-300">Players must be 18+ years old. GDPR and DSA compliant. EU residents only for real money features.</p>
                </div>

                <div className="bg-slate-700/50 rounded-lg p-3 mb-3">
                  <h5 className="text-white font-semibold mb-2">Content Guidelines</h5>
                  <ul className="text-gray-300 space-y-1">
                    <li>✅ Original or AI-assisted content only</li>
                    <li>✅ Eco and sustainability themes encouraged</li>
                    <li>❌ No hate speech, discrimination, or harassment</li>
                    <li>❌ No NSFW or inappropriate content</li>
                    <li>❌ No spam or vote manipulation</li>
                    <li>⚠️ AI moderation with warnings before bans</li>
                  </ul>
                </div>

                <div className="bg-slate-700/50 rounded-lg p-3 mb-3">
                  <h5 className="text-white font-semibold mb-2">Prize Distribution (When Available)</h5>
                  <p className="text-gray-300 mb-2">Prizes funded by: Contest entries, sponsorships, and subscriptions (70% to winners)</p>
                  <p className="text-gray-300 mb-2"><strong>Fallback rules if contest is underfunded:</strong></p>
                  <ul className="text-gray-300 space-y-1">
                    <li>1. Prize rolls over to next similar event (notification sent)</li>
                    <li>2. If no similar event: Donation to EU green charity (e.g., WWF)</li>
                    <li>3. Players receive eco-impact badge as recognition</li>
                    <li>4. Entry fee refunds if applicable</li>
                  </ul>
                </div>

                <div className="bg-slate-700/50 rounded-lg p-3 mb-3">
                  <h5 className="text-white font-semibold mb-2">Voting & Fair Play</h5>
                  <ul className="text-gray-300 space-y-1">
                    <li>• All votes are recorded by user ID</li>
                    <li>• Each creation can be liked/rated once per user</li>
                    <li>• Rating requires minimum 10 characters comment</li>
                    <li>• Vote manipulation detected by AI → account warning/ban</li>
                    <li>• Multiple accounts from same user prohibited</li>
                  </ul>
                </div>

                <div className="bg-slate-700/50 rounded-lg p-3 mb-3">
                  <h5 className="text-white font-semibold mb-2">Payouts (Coming Soon)</h5>
                  <ul className="text-gray-300 space-y-1">
                    <li>• Minimum withdrawal: €5 in tokens</li>
                    <li>• Processing time: 1-3 business days</li>
                    <li>• Payment via Stripe to bank account</li>
                    <li>• EU VAT compliance for all transactions</li>
                    <li>• Players responsible for income tax reporting</li>
                  </ul>
                  <p className="text-xs text-yellow-300 mt-2">⏳ Payout system launching Q1-Q2 2025</p>
                </div>

                <div className="bg-slate-700/50 rounded-lg p-3 mb-3">
                  <h5 className="text-white font-semibold mb-2">Subscription</h5>
                  <ul className="text-gray-300 space-y-1">
                    <li>• Premium tier: €4.99/month</li>
                    <li>• Auto-renewal (can cancel anytime)</li>
                    <li>• 7-day free trial for first-time subscribers</li>
                    <li>• Unlocks: Quest system, path selection, higher prizes</li>
                    <li>• Cancellation: Access until end of billing period</li>
                  </ul>
                </div>

                <div className="bg-red-900/30 rounded-lg p-3 border border-red-500/30">
                  <h5 className="text-red-300 font-semibold mb-2">⚠️ Important</h5>
                  <p className="text-gray-300">Rules may be updated. Email notifications sent for major changes. Continued use implies acceptance of updated terms.</p>
                </div>

                <div className="text-center mt-4">
                  <p className="text-gray-400">📧 Support: <a href="mailto:support@creatiquest.app" className="text-blue-400 hover:underline">support@creatiquest.app</a></p>
                  <p className="text-gray-400 text-xs mt-2">Last updated: January 2025</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Main Content */}
      <main className="pb-20 md:pb-32">
        {children}
      </main>

      {/* Footer with Links */}
      <footer className="bg-slate-900/90 border-t border-slate-700 py-6 pb-20 md:pb-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-6 text-sm text-gray-400 mb-3">
            <Link to={createPageUrl("FAQ")} className="hover:text-blue-400 transition-colors">FAQ</Link>
            <Link to={createPageUrl("Privacy")} className="hover:text-blue-400 transition-colors">Privacy Policy</Link>
            <Link to={createPageUrl("Terms")} className="hover:text-blue-400 transition-colors">Terms of Service</Link>
            <a href="mailto:support@creatiquest.app" className="hover:text-blue-400 transition-colors">Support</a>
          </div>
          <p className="text-center text-gray-500 text-xs">
            © 2025 CreatiQuest. GDPR & DSA compliant. Made with 💚 in Neo-Europe.
          </p>
        </div>
      </footer>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-md border-t border-blue-500/30 z-50">
        <div className="container mx-auto px-2">
          <div className="flex items-center justify-around py-2">
            {navItems.map((item) => {
              const isActive = location.pathname === item.url;
              const Icon = item.icon;
              return (
                <Link
                  key={item.title}
                  to={item.url}
                  className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all ${
                    isActive
                      ? "text-blue-400 bg-blue-500/20"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  <Icon size={20} />
                  <span className="text-xs font-medium">{item.title}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </nav>
    </div>
  );
}
