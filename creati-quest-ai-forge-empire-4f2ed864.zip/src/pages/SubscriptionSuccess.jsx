import React, { useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Sparkles } from "lucide-react";

export default function SubscriptionSuccess() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('session_id');

  useEffect(() => {
    // Reload user data to get updated subscription status
    setTimeout(() => {
      window.location.href = createPageUrl("SpecializationSelect");
    }, 3000);
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-500/30 max-w-2xl w-full">
        <CardContent className="pt-12 pb-12 text-center">
          <div className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6 border-4 border-green-500">
            <CheckCircle2 size={48} className="text-green-400" />
          </div>

          <h1 className="text-4xl font-bold text-white mb-4">
            Welcome to Premium! 🎉
          </h1>
          
          <p className="text-gray-300 text-lg mb-8">
            Your subscription is now active. You've unlocked:
          </p>

          <div className="bg-slate-800/60 rounded-lg p-6 mb-8 text-left max-w-lg mx-auto">
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-green-300">
                <Sparkles size={16} />
                <span>Specialization path selection</span>
              </li>
              <li className="flex items-center gap-2 text-green-300">
                <Sparkles size={16} />
                <span>Access to sponsored quest chains</span>
              </li>
              <li className="flex items-center gap-2 text-green-300">
                <Sparkles size={16} />
                <span>Path-specific perks and bonuses</span>
              </li>
              <li className="flex items-center gap-2 text-green-300">
                <Sparkles size={16} />
                <span>Higher prize pools (€40-150 per quest)</span>
              </li>
              <li className="flex items-center gap-2 text-green-300">
                <Sparkles size={16} />
                <span>Community governance polls</span>
              </li>
            </ul>
          </div>

          <p className="text-gray-400 mb-6">
            Redirecting to choose your specialization path...
          </p>

          <Button
            onClick={() => navigate(createPageUrl("SpecializationSelect"))}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            Choose Your Path Now
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}