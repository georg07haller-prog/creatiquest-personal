import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Trophy, Target, Sparkles, TrendingUp, Users, Zap, Lock, ArrowRight, Calendar as CalendarIcon, Heart, Activity } from "lucide-react";
import InteractiveTutorial from "../components/InteractiveTutorial";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Dashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      // Send welcome email on first login (if not sent before)
      if (currentUser && !currentUser.welcome_email_sent) {
        try {
          await base44.integrations.Core.SendEmail({
            to: currentUser.email,
            subject: "🎉 Welcome to CreatiQuest!",
            body: `
              <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); color: white; padding: 40px 20px; border-radius: 16px;">
                <div style="text-align: center; margin-bottom: 30px;">
                  <h1 style="font-size: 36px; margin: 0; background: linear-gradient(to right, #4ade80, #3b82f6); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                    CreatiQuest: AI Forge Empire
                  </h1>
                  <p style="color: #94a3b8; margin-top: 10px;">Your journey begins!</p>
                </div>

                <div style="background: rgba(255,255,255,0.05); border-radius: 12px; padding: 24px; margin-bottom: 20px;">
                  <h2 style="color: #4ade80; margin-top: 0;">🎮 What awaits you?</h2>
                  <ul style="color: #e2e8f0; line-height: 1.8;">
                    <li><strong>🎭 AI Generation:</strong> Create memes, videos, songs in seconds</li>
                    <li><strong>🏆 Contests:</strong> Compete in daily challenges, win up to €10</li>
                    <li><strong>🎯 Quests:</strong> Complete sponsored missions, earn €40-150</li>
                    <li><strong>⚡ Progress System:</strong> Gain XP, level up, get bonuses</li>
                  </ul>
                </div>

                <div style="background: rgba(34, 197, 94, 0.1); border: 1px solid rgba(34, 197, 94, 0.3); border-radius: 12px; padding: 20px; margin-bottom: 20px;">
                  <h3 style="color: #4ade80; margin-top: 0;">🎁 Starter Pack:</h3>
                  <p style="color: #e2e8f0; font-size: 18px; margin: 10px 0;">
                    ✨ <strong>100 mana</strong> to create content<br/>
                    🎖️ <strong>Level 1</strong> — your adventure starts!<br/>
                    🆓 <strong>Free access</strong> to contests
                  </p>
                </div>

                <div style="background: rgba(59, 130, 246, 0.1); border: 1px solid rgba(59, 130, 246, 0.3); border-radius: 12px; padding: 20px; margin-bottom: 20px;">
                  <h3 style="color: #3b82f6; margin-top: 0;">📚 Quick Start:</h3>
                  <ol style="color: #e2e8f0; line-height: 1.8;">
                    <li>Open <strong>Studio</strong> → Choose content type</li>
                    <li>Write AI prompt or upload file</li>
                    <li>Publish your work and join contest</li>
                    <li>Get likes and ratings → earn mana and XP</li>
                  </ol>
                </div>

                <div style="text-align: center; margin-top: 30px;">
                  <a href="${process.env.FRONTEND_URL || 'https://creatiquest.app'}/dashboard" style="display: inline-block; background: linear-gradient(to right, #4ade80, #3b82f6); color: white; padding: 16px 32px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 18px;">
                    🚀 Start Creating
                  </a>
                </div>

                <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1); text-align: center;">
                  <p style="color: #64748b; font-size: 14px; margin: 5px 0;">
                    Questions? <a href="mailto:support@creatiquest.app" style="color: #3b82f6;">support@creatiquest.app</a>
                  </p>
                  <p style="color: #64748b; font-size: 12px; margin: 5px 0;">
                    © 2025 CreatiQuest • GDPR Compliant • Made in Neo-Europe
                  </p>
                </div>
              </div>
            `
          });
          
          // Mark as sent
          await base44.auth.updateMe({ welcome_email_sent: true });
        } catch (emailError) {
          console.error("Failed to send welcome email:", emailError);
        }
      }
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: contests = [] } = useQuery({
    queryKey: ['contests'],
    queryFn: () => base44.entities.Contest.filter({ status: 'active' }, '-created_date', 5),
    initialData: [],
  });

  const { data: quests = [] } = useQuery({
    queryKey: ['quests'],
    queryFn: () => base44.entities.Quest.filter({ status: 'active' }, '-created_date', 3),
    initialData: [],
  });

  const { data: recentCreations = [] } = useQuery({
    queryKey: ['recent-creations'],
    queryFn: () => base44.entities.Creation.filter({ status: 'published' }, '-created_date', 10),
    initialData: [],
  });

  const { data: allCreations = [] } = useQuery({
    queryKey: ['all-creations-count'],
    queryFn: () => base44.entities.Creation.filter({ status: 'published' }),
    initialData: [],
  });

  const getContestParticipants = (contestId) => {
    return allCreations.filter(c => c.contest_id === contestId).length;
  };

  const getQuestParticipants = (questId) => {
    return allCreations.filter(c => c.quest_id === questId).length;
  };

  const getTierBadge = (tier) => {
    const badges = {
      free: { label: 'Free', color: 'bg-gray-500' },
      paid: { label: 'Paid', color: 'bg-blue-500' },
      elite: { label: 'Elite', color: 'bg-yellow-500' }
    };
    return badges[tier] || badges.free;
  };

  const needsPathSelection = user?.subscription_tier !== 'free' && 
                            (!user?.specialization_path || user?.specialization_path === 'none');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <InteractiveTutorial />
      
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=1920')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
        <div className="relative container mx-auto px-4 py-12">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-3xl sm:text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-green-400 via-blue-400 to-purple-500 bg-clip-text text-transparent">
              Welcome to CreatiQuest
            </h1>
            <p className="text-base sm:text-xl text-blue-200 mb-8">
              Create, compete and earn with AI-powered content
            </p>
            
            {user && (
              <div className="flex flex-wrap justify-center gap-2 sm:gap-4 mb-8">
                <Badge className={`${getTierBadge(user.subscription_tier).color} text-white px-3 py-1.5 sm:px-4 sm:py-2 text-sm sm:text-base`}>
                  {getTierBadge(user.subscription_tier).label} Tier
                </Badge>
                <div className="flex items-center gap-2 px-3 py-1.5 sm:px-4 sm:py-2 bg-slate-800/60 backdrop-blur rounded-full">
                  <Zap className="text-yellow-400" size={18} />
                  <span className="text-white font-semibold text-sm sm:text-base">Level {user.level || 1}</span>
                </div>
              </div>
            )}

            {/* Path Selection Alert */}
            {needsPathSelection && (
              <Alert className="mb-6 bg-gradient-to-r from-purple-900/30 to-pink-900/30 border-purple-500/30 max-w-2xl mx-auto">
                <Sparkles className="h-4 w-4 text-purple-400" />
                <AlertDescription className="text-white">
                  <div className="flex items-center justify-between">
                    <div className="text-left">
                      <strong>Choose Your Specialization Path!</strong>
                      <p className="text-sm text-gray-400 mt-1">Unlock unique quests and agents tailored to your style</p>
                    </div>
                    <Link to={createPageUrl("SpecializationSelect")}>
                      <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                        Choose Path
                        <ArrowRight className="ml-2" size={16} />
                      </Button>
                    </Link>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            <div className="flex flex-col sm:flex-row flex-wrap justify-center gap-3 sm:gap-4 px-4">
              <Link to={createPageUrl("Studio")} className="w-full sm:w-auto">
                <Button className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white px-6 py-5 sm:px-8 sm:py-6 text-base sm:text-lg">
                  <Sparkles className="mr-2" size={20} />
                  Create Content
                </Button>
              </Link>
              <Link to={createPageUrl("Contests")} className="w-full sm:w-auto">
                <Button variant="outline" className="w-full border-blue-400 text-blue-300 hover:bg-blue-500/20 px-6 py-5 sm:px-8 sm:py-6 text-base sm:text-lg">
                  <Trophy className="mr-2" size={20} />
                  Contests
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 mb-8">
          <Card className="bg-slate-800/60 backdrop-blur border-green-500/30">
            <CardContent className="pt-4 sm:pt-6">
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-green-400">{contests.length}</div>
                <div className="text-xs sm:text-sm text-gray-400 mt-1">Active Contests</div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-slate-800/60 backdrop-blur border-blue-500/30">
            <CardContent className="pt-4 sm:pt-6">
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-blue-400">{quests.length}</div>
                <div className="text-xs sm:text-sm text-gray-400 mt-1">Available Quests</div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-slate-800/60 backdrop-blur border-purple-500/30">
            <CardContent className="pt-4 sm:pt-6">
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-purple-400">{recentCreations.length}</div>
                <div className="text-xs sm:text-sm text-gray-400 mt-1">New Creations</div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-slate-800/60 backdrop-blur border-pink-500/30">
            <CardContent className="pt-4 sm:pt-6">
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-pink-400">{user?.karma || 0}</div>
                <div className="text-xs sm:text-sm text-gray-400 mt-1">Your Karma</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Active Contests */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
              <Trophy className="text-yellow-400" size={24} />
              <span className="hidden sm:inline">Active Contests</span>
              <span className="sm:hidden">Contests</span>
            </h2>
            <Link to={createPageUrl("Contests")}>
              <Button variant="ghost" className="text-blue-400 text-sm sm:text-base">
                All →
              </Button>
            </Link>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {contests.slice(0, 3).map((contest) => {
              const participants = getContestParticipants(contest.id);
              return (
                <Card key={contest.id} className="bg-slate-800/60 backdrop-blur border-blue-500/30 hover:border-blue-400 transition-all">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center justify-between">
                      <span className="text-lg">{contest.title}</span>
                      {contest.eco_badge && <span className="text-green-400">🌱</span>}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-400 text-sm mb-4">{contest.theme}</p>
                    <div className="flex items-center justify-between mb-3">
                      <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                        €{contest.prize_pool || 0} prize
                      </Badge>
                      <Badge variant="outline" className="border-blue-400/30 text-blue-300">
                        <Users size={14} className="mr-1" />
                        {participants}
                      </Badge>
                    </div>
                    <Link to={createPageUrl("Contests")}>
                      <Button size="sm" className="w-full bg-blue-500 hover:bg-blue-600">
                        Join Contest
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Featured Quests */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
              <Target className="text-green-400" size={24} />
              <span className="hidden sm:inline">Featured Quests</span>
              <span className="sm:hidden">Quests</span>
            </h2>
            <Link to={createPageUrl("Quests")}>
              <Button variant="ghost" className="text-blue-400 text-sm sm:text-base">
                All →
              </Button>
            </Link>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            {quests.slice(0, 3).map((quest) => {
              const participants = getQuestParticipants(quest.id);
              return (
                <Card key={quest.id} className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur border-green-500/30 hover:border-green-400 transition-all">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">{quest.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-400 text-sm mb-4">{quest.description}</p>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Reward:</span>
                        <span className="text-green-400 font-semibold">€{quest.prize_min || 0}-{quest.prize_max || 0}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Participants:</span>
                        <Badge variant="outline" className="border-green-400/30 text-green-300">
                          <Users size={14} className="mr-1" />
                          {participants}
                        </Badge>
                      </div>
                      <Link to={createPageUrl("Quests")}>
                        <Button size="sm" className="w-full bg-green-500 hover:bg-green-600">
                          Start Quest
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Trending Creations */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
              <TrendingUp className="text-purple-400" size={24} />
              <span className="hidden sm:inline">Trending Creations</span>
              <span className="sm:hidden">Trending</span>
            </h2>
            <Link to={createPageUrl("Community")}>
              <Button variant="ghost" className="text-blue-400 text-sm sm:text-base">
                All →
              </Button>
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {recentCreations.slice(0, 5).map((creation) => (
              <Card key={creation.id} className="bg-slate-800/60 backdrop-blur border-purple-500/30 hover:border-purple-400 transition-all overflow-hidden group cursor-pointer">
                <div className="aspect-square relative overflow-hidden">
                  {creation.image_url ? (
                    <img 
                      src={creation.image_url} 
                      alt={creation.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center">
                      <Sparkles className="text-white" size={48} />
                    </div>
                  )}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
                    <div className="flex items-center gap-2 text-white text-xs">
                      <span>❤️ {creation.likes || 0}</span>
                      <span>⭐ {(creation.rating_avg || 0).toFixed(1)}</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}