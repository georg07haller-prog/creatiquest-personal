import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Lock } from "lucide-react";
import AchievementBadge from "../components/AchievementBadge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";

export default function Achievements() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  const { data: achievements = [] } = useQuery({
    queryKey: ['achievements'],
    queryFn: () => base44.entities.Achievement.list(),
    initialData: [],
  });

  const { data: userAchievements = [] } = useQuery({
    queryKey: ['user-achievements', user?.email],
    queryFn: () => user ? base44.entities.UserAchievement.filter({ created_by: user.email }) : [],
    initialData: [],
    enabled: !!user
  });

  const getUserAchievement = (achievementId) => {
    return userAchievements.find(ua => ua.achievement_id === achievementId);
  };

  const unlockedCount = userAchievements.filter(ua => ua.unlocked_at).length;
  const totalCount = achievements.length;

  const byCategory = (category) => achievements.filter(a => a.category === category);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
          🏆 Achievements
        </h1>
        <p className="text-blue-300">Unlock badges and earn rewards!</p>
      </div>

      {/* Progress Card */}
      <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-500/30 mb-8">
        <CardContent className="pt-6">
          <div className="text-center">
            <div className="text-6xl font-bold text-white mb-2">
              {unlockedCount}/{totalCount}
            </div>
            <p className="text-gray-300 mb-4">Achievements Unlocked</p>
            <div className="w-full bg-slate-700 rounded-full h-4 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-500"
                style={{ width: `${(unlockedCount / totalCount) * 100}%` }}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Achievement Categories */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-6 bg-slate-800 mb-6">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="creation">Create</TabsTrigger>
          <TabsTrigger value="social">Social</TabsTrigger>
          <TabsTrigger value="contest">Contest</TabsTrigger>
          <TabsTrigger value="quest">Quest</TabsTrigger>
          <TabsTrigger value="level">Level</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {achievements.map((achievement) => (
              <motion.div
                key={achievement.id}
                whileHover={{ scale: 1.05 }}
                className="flex flex-col items-center"
              >
                <AchievementBadge 
                  achievement={achievement}
                  userAchievement={getUserAchievement(achievement.id)}
                />
                <div className="text-center mt-4">
                  <p className="text-white text-sm font-semibold">{achievement.title}</p>
                  <p className="text-gray-400 text-xs mt-1">{achievement.description}</p>
                  {achievement.reward_mana > 0 && (
                    <p className="text-green-400 text-xs mt-2">+{achievement.reward_mana} mana</p>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {['creation', 'social', 'contest', 'quest', 'level'].map(category => (
          <TabsContent key={category} value={category}>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
              {byCategory(category).map((achievement) => (
                <motion.div
                  key={achievement.id}
                  whileHover={{ scale: 1.05 }}
                  className="flex flex-col items-center"
                >
                  <AchievementBadge 
                    achievement={achievement}
                    userAchievement={getUserAchievement(achievement.id)}
                  />
                  <div className="text-center mt-4">
                    <p className="text-white text-sm font-semibold">{achievement.title}</p>
                    <p className="text-gray-400 text-xs mt-1">{achievement.description}</p>
                    {achievement.reward_mana > 0 && (
                      <p className="text-green-400 text-xs mt-2">+{achievement.reward_mana} mana</p>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}