import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Mail } from "lucide-react";

export default function Privacy() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent flex items-center gap-3">
          <Shield className="text-blue-400" size={40} />
          Privacy Policy
        </h1>
        <p className="text-gray-400">Last updated: January 15, 2025</p>
      </div>

      <div className="space-y-6">
        <Card className="bg-slate-800/60 backdrop-blur border-blue-500/30">
          <CardHeader>
            <CardTitle className="text-white">1. Data Collection</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <p>CreatiQuest collects the following data:</p>
            <ul className="list-disc ml-6 space-y-2">
              <li><strong>Personal data:</strong> Email, name, registration date</li>
              <li><strong>Game data:</strong> Level, experience, mana, karma, tokens</li>
              <li><strong>Content:</strong> Created works, prompts, ratings, comments</li>
              <li><strong>Activity:</strong> Contest participation, quests, voting</li>
              <li><strong>Technical data:</strong> IP address, browser, device (for security)</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-green-500/30">
          <CardHeader>
            <CardTitle className="text-white">2. Data Usage</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <p>We use your data to:</p>
            <ul className="list-disc ml-6 space-y-2">
              <li>Provide game features and personalize experience</li>
              <li>Process payments and prize payouts</li>
              <li>Send important notifications (contest results, new quests)</li>
              <li>Improve service and AI algorithms</li>
              <li>Comply with GDPR and DSA (EU) requirements</li>
              <li>Prevent fraud and vote manipulation</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-white">3. Storage and Protection</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <ul className="list-disc ml-6 space-y-2">
              <li><strong>Encryption:</strong> SSL/TLS for all data</li>
              <li><strong>Servers:</strong> EU region (GDPR compliant)</li>
              <li><strong>Retention period:</strong> Until account deletion + 30 days</li>
              <li><strong>Backups:</strong> Automatic backups every 24h</li>
              <li><strong>Access:</strong> Only authorized personnel</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-yellow-500/30">
          <CardHeader>
            <CardTitle className="text-white">4. Your Rights (GDPR)</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <p>You have the right to:</p>
            <ul className="list-disc ml-6 space-y-2">
              <li><strong>Access:</strong> Request a copy of all your data</li>
              <li><strong>Correction:</strong> Change inaccurate data in profile</li>
              <li><strong>Deletion:</strong> Delete account and all data (Right to be Forgotten)</li>
              <li><strong>Restriction:</strong> Prohibit processing for marketing</li>
              <li><strong>Portability:</strong> Get data in machine-readable format</li>
              <li><strong>Objection:</strong> Opt out of automated processing</li>
            </ul>
            <p className="text-sm text-blue-300 mt-4">
              For requests: <a href="mailto:privacy@creatiquest.app" className="underline">privacy@creatiquest.app</a>
            </p>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-pink-500/30">
          <CardHeader>
            <CardTitle className="text-white">5. Cookies and Analytics</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <ul className="list-disc ml-6 space-y-2">
              <li><strong>Necessary cookies:</strong> Authentication, security (required)</li>
              <li><strong>Analytics cookies:</strong> Google Analytics (anonymous data) - can be disabled</li>
              <li><strong>No advertising cookies</strong> - we don't sell your data to third parties</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-red-500/30">
          <CardHeader>
            <CardTitle className="text-white">6. AI and Content</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <ul className="list-disc ml-6 space-y-2">
              <li>Your prompts are used only for content generation</li>
              <li>AI providers (OpenAI) process data according to their policy</li>
              <li>Created content belongs to you, but by publishing you grant us a license to distribute</li>
              <li>Content moderation happens automatically + manually</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-gray-500/30">
          <CardHeader>
            <CardTitle className="text-white">7. Policy Changes</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <p>
              We may update this policy. You will be notified by email 30 days before significant changes take effect.
            </p>
            <p className="text-sm text-gray-400">
              By continuing to use the service, you agree to the current version of the policy.
            </p>
          </CardContent>
        </Card>

        <div className="bg-blue-900/30 rounded-lg p-6 border border-blue-500/30 text-center">
          <Mail className="mx-auto mb-3 text-blue-400" size={32} />
          <p className="text-white font-semibold mb-2">Questions about privacy?</p>
          <p className="text-gray-300 text-sm">
            Contact us: <a href="mailto:privacy@creatiquest.app" className="text-blue-400 underline">privacy@creatiquest.app</a>
          </p>
        </div>
      </div>
    </div>
  );
}