import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Target, Lock, CheckCircle, Clock, Euro, Zap, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, differenceInHours } from "date-fns";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Quests() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: quests = [] } = useQuery({
    queryKey: ['all-quests'],
    queryFn: () => base44.entities.Quest.list('-created_date'),
    initialData: [],
  });

  const getTimeRemaining = (deadline) => {
    const hours = differenceInHours(new Date(deadline), new Date());
    if (hours < 0) return 'Expired';
    if (hours < 24) return `${hours} hours`;
    const days = Math.floor(hours / 24);
    return `${days} days`;
  };

  const getDifficultyColor = (difficulty) => {
    const colors = {
      beginner: 'bg-green-500/20 text-green-300 border-green-500/30',
      intermediate: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
      advanced: 'bg-red-500/20 text-red-300 border-red-500/30'
    };
    return colors[difficulty] || colors.beginner;
  };

  const getDifficultyLabel = (difficulty) => {
    const labels = {
      beginner: '🌱 Beginner',
      intermediate: '⚡ Intermediate',
      advanced: '🔥 Advanced'
    };
    return labels[difficulty] || labels.beginner;
  };

  const canAccessQuest = (quest) => {
    if (!user) return false;
    if (quest.required_level > user.level) return false;
    if (user.subscription_tier === 'free') return false;
    return true;
  };

  const activeQuests = quests.filter(q => q.status === 'active');
  const needsUpgrade = user?.subscription_tier === 'free';

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
          Quest Labyrinth
        </h1>
        <p className="text-blue-300">Complete sponsored missions and earn rewards</p>
      </div>

      {/* Subscription Alert */}
      {needsUpgrade && (
        <Alert className="mb-6 bg-gradient-to-r from-blue-900/30 to-purple-900/30 border-blue-500/30">
          <Lock className="h-4 w-4 text-blue-400" />
          <AlertDescription className="text-white">
            <div className="flex items-center justify-between">
              <div>
                <strong>Quests available in Paid subscription</strong>
                <p className="text-sm text-gray-400 mt-1">Get access to sponsored quests and earn up to €200</p>
              </div>
              <Button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600">
                Subscribe €4.99/month
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card className="bg-gradient-to-br from-green-900/30 to-green-800/30 border-green-500/30">
          <CardContent className="pt-6 text-center">
            <div className="text-2xl font-bold text-green-400">{activeQuests.length}</div>
            <div className="text-sm text-gray-400">Active Quests</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-purple-900/30 to-purple-800/30 border-purple-500/30">
          <CardContent className="pt-6 text-center">
            <div className="text-2xl font-bold text-purple-400">
              €{quests.reduce((sum, q) => sum + (q.prize_max || 0), 0)}
            </div>
            <div className="text-sm text-gray-400">Total Prizes</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-yellow-900/30 to-yellow-800/30 border-yellow-500/30">
          <CardContent className="pt-6 text-center">
            <div className="text-2xl font-bold text-yellow-400">{user?.level || 1}</div>
            <div className="text-sm text-gray-400">Your Level</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-blue-900/30 to-blue-800/30 border-blue-500/30">
          <CardContent className="pt-6 text-center">
            <div className="text-2xl font-bold text-blue-400">{user?.mana || 0}</div>
            <div className="text-sm text-gray-400">Your Mana</div>
          </CardContent>
        </Card>
      </div>

      {/* Active Quests */}
      <div className="grid md:grid-cols-2 gap-6">
        {activeQuests.map((quest) => {
          const isLocked = !canAccessQuest(quest);
          const hasEnoughMana = user && user.mana >= (quest.mana_cost || 0);
          
          return (
            <Card 
              key={quest.id} 
              className={`bg-slate-800/60 backdrop-blur border-green-500/30 hover:border-green-400 transition-all overflow-hidden ${
                isLocked ? 'opacity-60' : ''
              }`}
            >
              {quest.sponsor_logo && (
                <div className="bg-gradient-to-r from-slate-700 to-slate-800 p-4 border-b border-green-500/30">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img 
                        src={quest.sponsor_logo} 
                        alt={quest.sponsor}
                        className="w-12 h-12 rounded-lg bg-white p-1"
                      />
                      <div>
                        <p className="text-xs text-gray-400">Sponsor</p>
                        <p className="text-white font-semibold">{quest.sponsor}</p>
                      </div>
                    </div>
                    <Badge className={getDifficultyColor(quest.difficulty)}>
                      {getDifficultyLabel(quest.difficulty)}
                    </Badge>
                  </div>
                </div>
              )}
              
              <CardHeader>
                <CardTitle className="text-white text-xl flex items-center gap-2">
                  {isLocked && <Lock size={20} className="text-gray-500" />}
                  {quest.title}
                </CardTitle>
                <p className="text-gray-400 text-sm">{quest.description}</p>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Steps Preview */}
                {quest.steps && quest.steps.length > 0 && (
                  <div className="bg-slate-700/50 rounded-lg p-4">
                    <p className="text-xs text-gray-400 mb-2">Quest Steps:</p>
                    <div className="space-y-2">
                      {quest.steps.slice(0, 3).map((step, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-sm">
                          <span className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center text-xs text-green-400 flex-shrink-0">
                            {idx + 1}
                          </span>
                          <span className="text-gray-300">{step.title}</span>
                        </div>
                      ))}
                      {quest.steps.length > 3 && (
                        <p className="text-xs text-gray-500 ml-7">+{quest.steps.length - 3} more steps</p>
                      )}
                    </div>
                  </div>
                )}

                {/* Requirements */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-gradient-to-br from-purple-900/30 to-purple-800/30 rounded-lg p-3 border border-purple-500/30">
                    <p className="text-xs text-gray-400 mb-1">Reward</p>
                    <p className="text-lg font-bold text-purple-300 flex items-center gap-1">
                      <Euro size={18} />
                      {quest.prize_min || 0}-{quest.prize_max || 0}
                    </p>
                  </div>
                  <div className="bg-gradient-to-br from-blue-900/30 to-blue-800/30 rounded-lg p-3 border border-blue-500/30">
                    <p className="text-xs text-gray-400 mb-1">Deadline</p>
                    <p className="text-sm font-bold text-blue-300 flex items-center gap-1">
                      <Clock size={16} />
                      {getTimeRemaining(quest.deadline)}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-sm">
                  <Badge variant="outline" className="border-yellow-500/30 text-yellow-300">
                    Level: {quest.required_level || 1}+
                  </Badge>
                  {(quest.mana_cost || 0) > 0 && (
                    <Badge variant="outline" className={`${
                      hasEnoughMana ? 'border-green-500/30 text-green-300' : 'border-red-500/30 text-red-300'
                    }`}>
                      <Zap size={14} className="mr-1" />
                      {quest.mana_cost} mana
                    </Badge>
                  )}
                </div>

                {/* Action Button */}
                {isLocked ? (
                  <div className="space-y-2">
                    <Button disabled className="w-full bg-gray-700 text-gray-400">
                      <Lock className="mr-2" size={16} />
                      {user?.level < quest.required_level ? 
                        `Requires Level ${quest.required_level}` : 
                        'Requires Paid Subscription'
                      }
                    </Button>
                    {user?.subscription_tier === 'free' && (
                      <p className="text-xs text-center text-gray-500">
                        Subscribe to Paid (€4.99/month) to unlock
                      </p>
                    )}
                  </div>
                ) : !hasEnoughMana ? (
                  <Button disabled className="w-full bg-gray-700 text-gray-400">
                    Not Enough Mana
                  </Button>
                ) : (
                  <Link to={createPageUrl("Studio")}>
                    <Button className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600">
                      <Target className="mr-2" size={16} />
                      Start Quest
                    </Button>
                  </Link>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {quests.length === 0 && (
        <div className="text-center py-12">
          <Target className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 text-lg">No quests yet</p>
          <p className="text-gray-500 text-sm mt-2">New sponsored missions coming soon!</p>
        </div>
      )}
    </div>
  );
}