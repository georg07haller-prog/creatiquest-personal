import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, Wand2, Upload, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

// LevelUpNotification Component
const LevelUpNotification = ({ level, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 5000); // Notification disappears after 5 seconds
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 p-6 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg shadow-xl animate-bounce-in max-w-sm text-center">
      <h2 className="text-3xl font-bold mb-2">🎉 Level Up! 🎉</h2>
      <p className="text-xl">You reached Level {level}!</p>
      <p className="text-md mt-2">Bonus: +50 Mana!</p>
      <button
        onClick={onClose}
        className="mt-4 px-4 py-2 bg-white text-purple-600 rounded-md font-semibold hover:bg-gray-100 transition-colors"
      >
        Awesome!
      </button>
    </div>
  );
};


export default function Studio() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    title: '',
    type: 'meme',
    prompt: '',
    theme: '',
    tags: [],
    contest_id: '',
    quest_id: ''
  });
  const [generating, setGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState(null);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [levelUpNotification, setLevelUpNotification] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      
      if (currentUser.mana === undefined || currentUser.mana === null) {
        await base44.auth.updateMe({ mana: 100 });
        currentUser.mana = 100;
      }
      
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const checkAndHandleLevelUp = async (newXP, currentLevel) => {
    const xpNeededForNextLevel = currentLevel * 1000; // e.g., Level 1 needs 1000 XP to reach Level 2
    const totalXP = newXP;
    
    if (totalXP >= xpNeededForNextLevel) {
      const newLevel = currentLevel + 1;
      const updatedUser = await base44.auth.updateMe({
        level: newLevel,
        experience_points: totalXP,
        mana: (user.mana || 0) + 50 // Level up bonus
      });
      
      setLevelUpNotification(newLevel); // Trigger notification locally
      return updatedUser; // Return the fully updated user object
    }
    return null; // No level up
  };

  const { data: activeContests = [] } = useQuery({
    queryKey: ['active-contests'],
    queryFn: () => base44.entities.Contest.filter({ status: 'active' }, '-created_date'),
    initialData: [],
  });

  const { data: activeQuests = [] } = useQuery({
    queryKey: ['active-quests'],
    queryFn: () => base44.entities.Quest.filter({ status: 'active' }, '-created_date'),
    initialData: [],
  });

  const createCreationMutation = useMutation({
    mutationFn: async (data) => {
      const creation = await base44.entities.Creation.create(data);
      
      if (user) {
        // Step 1: Update XP for the user
        const newXP = (user.experience_points || 0) + 50;
        let updatedUser = await base44.auth.updateMe({ experience_points: newXP }); // This should return the user object with updated XP

        // Step 2: Check for Level Up using the most recent user data
        const userAfterLevelUpCheck = await checkAndHandleLevelUp(
          updatedUser.experience_points, 
          updatedUser.level || 1
        );
        
        // If a level up occurred, use that user object, otherwise use the one after XP update
        return { creation, updatedUser: userAfterLevelUpCheck || updatedUser };
      }
      return { creation, updatedUser: null };
    },
    onSuccess: ({ creation, updatedUser }) => {
      queryClient.invalidateQueries({ queryKey: ['creations'] });
      if (updatedUser) {
        setUser(updatedUser); // Set the final user state here
        window.dispatchEvent(new Event('userUpdated')); // Inform other components
      }
      toast.success("Creation published! +50 XP 🎉");
      navigate(createPageUrl("Community"));
    },
  });

  const handleGenerate = async () => {
    if (!formData.prompt) {
      toast.error("Enter a prompt for generation");
      return;
    }

    if (!user) {
      toast.error("Loading user data...");
      return;
    }

    if ((user.mana || 0) < 20) {
      toast.error("Not enough mana! Need 20 mana.");
      return;
    }

    setGenerating(true);
    
    const maxRetries = 3;
    let retryCount = 0;
    
    const attemptGeneration = async () => {
      try {
        toast.info(`Generating text content...${retryCount > 0 ? ` (попытка ${retryCount + 1}/${maxRetries})` : ''}`);
        
        // Step 1: Generate text content with LLM
        const result = await base44.integrations.Core.InvokeLLM({
          prompt: `Create ${formData.type === 'meme' ? 'a funny meme text' : 
                  formData.type === 'song' ? 'song lyrics' : 
                  formData.type === 'video' ? 'a short video script' : 
                  'creative text content'} about: "${formData.prompt}". 
                  Context: Neo-Europe urban landscape, eco-theme, creative youth style.
                  ${formData.theme ? `Contest theme: ${formData.theme}` : ''}`,
          response_json_schema: {
            type: "object",
            properties: {
              title: { type: "string" },
              content: { type: "string" },
              viral_score: { type: "integer" },
              suggestions: { 
                type: "array",
                items: { type: "string" }
              }
            }
          }
        });

        console.log("Generated content:", result);
        setGeneratedContent(result);
        setFormData(prev => ({ ...prev, title: result.title }));
        toast.success("Text generated!");

        // Step 2: Generate image
        toast.info("Generating image...");
        
        const imagePrompt = formData.type === 'meme' 
          ? `Vibrant meme-style image: ${formData.prompt}. Style: Bold colors, humorous, Neo-Europe urban setting with eco-theme elements like bikes, green tech, sustainable fashion. High contrast, eye-catching, social media ready.`
          : formData.type === 'song'
          ? `Album cover art for song about: ${formData.prompt}. Style: Modern, vibrant, music-themed, abstract patterns, Neo-Europe aesthetic with eco elements.`
          : formData.type === 'video'
          ? `Cinematic still frame: ${formData.prompt}. Style: Neo-Europe cityscape (Amsterdam canals, Berlin street art, Prague bridges), eco-friendly urban life, vibrant colors, modern aesthetic.`
          : `Creative artistic image: ${formData.prompt}. Style: Modern, colorful, eco-theme, Neo-Europe urban setting.`;

        const { url: imageUrl } = await base44.integrations.Core.GenerateImage({
          prompt: imagePrompt
        });

        console.log("Generated image:", imageUrl);
        setUploadedFile(imageUrl);
        toast.success("Image generated!");
        
        // Update mana only on success
        await base44.auth.updateMe({ mana: (user.mana || 0) - 20 });
        setUser(prev => ({ ...prev, mana: (prev.mana || 0) - 20 }));
        
        toast.success("Content generated! -20 mana");
        setStep(2);
      } catch (error) {
        console.error("Generation error:", error);
        
        retryCount++;
        if (retryCount < maxRetries) {
          toast.warning(`Ошибка генерации. Повтор через 2 сек... (${retryCount}/${maxRetries})`);
          await new Promise(resolve => setTimeout(resolve, 2000));
          return attemptGeneration();
        } else {
          toast.error("Не удалось сгенерировать контент после 3 попыток. Попробуй позже или напиши в support@creatiquest.app");
        }
      }
    };
    
    try {
      await attemptGeneration();
    } finally {
      setGenerating(false);
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setUploadedFile(file_url);
      toast.success("File uploaded!");
    } catch (error) {
      toast.error("File upload error");
    }
  };

  const handlePublish = async () => {
    if (!formData.title) {
      toast.error("Add a title");
      return;
    }

    const creationData = {
      title: formData.title,
      type: formData.type,
      content: generatedContent?.content || formData.prompt,
      prompt: formData.prompt,
      theme: formData.theme,
      image_url: uploadedFile,
      viral_score: generatedContent?.viral_score || 50,
      tags: formData.tags,
      contest_id: formData.contest_id || undefined,
      quest_id: formData.quest_id || undefined,
      status: 'published'
    };

    createCreationMutation.mutate(creationData);
  };

  const contentTypes = [
    { value: 'meme', label: '🎭 Meme', mana: 20 },
    { value: 'song', label: '🎵 Song', mana: 30 },
    { value: 'video', label: '🎬 Video', mana: 40 },
    { value: 'text', label: '📝 Text', mana: 15 }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      {/* Level Up Notification */}
      {levelUpNotification && (
        <LevelUpNotification 
          level={levelUpNotification} 
          onClose={() => setLevelUpNotification(null)} 
        />
      )}

      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
          Creation Studio
        </h1>
        <p className="text-blue-300">Create unique content with AI</p>
      </div>

      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex items-center justify-center gap-4">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all ${
                step >= s ? 'bg-gradient-to-r from-green-400 to-blue-400 text-white' : 'bg-slate-700 text-gray-400'
              }`}>
                {s}
              </div>
              {s < 3 && <div className={`w-12 h-1 mx-2 ${step > s ? 'bg-blue-400' : 'bg-slate-700'}`} />}
            </div>
          ))}
        </div>
        <div className="flex justify-center gap-8 mt-2">
          <span className="text-xs text-gray-400">Setup</span>
          <span className="text-xs text-gray-400">Generate</span>
          <span className="text-xs text-gray-400">Publish</span>
        </div>
      </div>

      {/* Step 1: Setup */}
      {step === 1 && (
        <Card className="bg-slate-800/60 backdrop-blur border-blue-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Wand2 className="text-blue-400" />
              Step 1: Content Setup
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Content Type</label>
              <Select value={formData.type} onValueChange={(v) => setFormData(prev => ({ ...prev, type: v }))}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {contentTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label} ({type.mana} mana)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {activeContests.length > 0 && (
              <div>
                <label className="text-sm text-gray-300 mb-2 block">Contest (optional)</label>
                <Select value={formData.contest_id} onValueChange={(v) => setFormData(prev => ({ ...prev, contest_id: v === 'none' ? '' : v }))}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="Choose contest or skip" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No contest (just publish)</SelectItem>
                    {activeContests.map(contest => (
                      <SelectItem key={contest.id} value={contest.id}>
                        🏆 {contest.title} - €{contest.prize_pool}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {formData.contest_id && formData.contest_id !== 'none' && (
                  <p className="text-xs text-green-400 mt-1 flex items-center gap-1">
                    ✅ Will participate in contest
                  </p>
                )}
              </div>
            )}

            {activeQuests.length > 0 && (
              <div>
                <label className="text-sm text-gray-300 mb-2 block">Quest (optional)</label>
                <Select value={formData.quest_id} onValueChange={(v) => setFormData(prev => ({ ...prev, quest_id: v === 'none' ? '' : v }))}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="Choose quest or skip" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No quest (just publish)</SelectItem>
                    {activeQuests.map(quest => (
                      <SelectItem key={quest.id} value={quest.id}>
                        🎯 {quest.title} - €{quest.prize_min}-{quest.prize_max}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {formData.quest_id && formData.quest_id !== 'none' && (
                  <p className="text-xs text-blue-400 mt-1 flex items-center gap-1">
                    ✅ Will participate in quest
                  </p>
                )}
              </div>
            )}

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Theme (optional)</label>
              <Input
                placeholder="E.g: Eco-Fashion, Sustainable Transport"
                value={formData.theme}
                onChange={(e) => setFormData(prev => ({ ...prev, theme: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-white"
              />
            </div>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">AI Prompt *</label>
              <Textarea
                placeholder="Describe what you want to create... E.g: 'Create a funny meme about a cyclist in Amsterdam with an eco-bag'"
                value={formData.prompt}
                onChange={(e) => setFormData(prev => ({ ...prev, prompt: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-white min-h-32"
              />
              <p className="text-xs text-gray-400 mt-1">
                Be specific! The more detailed the prompt, the better the result
              </p>
            </div>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Or upload your own file</label>
              <div className="flex items-center gap-4">
                <input
                  type="file"
                  accept="image/*,video/*,audio/*"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload">
                  <Button variant="outline" className="border-dashed border-blue-400 text-blue-300" asChild>
                    <span>
                      <Upload className="mr-2" size={16} />
                      Upload File
                    </span>
                  </Button>
                </label>
                {uploadedFile && (
                  <span className="text-sm text-green-400 flex items-center gap-1">
                    <CheckCircle2 size={16} /> File uploaded
                  </span>
                )}
              </div>
            </div>

            <Button
              onClick={() => uploadedFile ? setStep(3) : handleGenerate()}
              disabled={(!formData.prompt && !uploadedFile) || generating}
              className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 disabled:opacity-50"
            >
              {generating ? (
                <>
                  <Loader2 className="mr-2 animate-spin" />
                  Generating...
                </>
              ) : uploadedFile ? (
                'Go to Publish'
              ) : (
                <>
                  <Sparkles className="mr-2" />
                  Generate with AI
                </>
              )}
            </Button>

            {user && (
              <div className="text-center text-sm text-gray-400">
                You have: <span className="text-green-400 font-semibold">{user.mana || 0} mana</span>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Step 2: Generated Content */}
      {step === 2 && generatedContent && (
        <Card className="bg-slate-800/60 backdrop-blur border-green-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="text-green-400" />
              Step 2: Generated Content
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-gradient-to-br from-green-900/30 to-blue-900/30 rounded-lg p-6 border border-green-500/30">
              <h3 className="text-xl font-bold text-white mb-2">{generatedContent.title}</h3>
              <p className="text-gray-300 whitespace-pre-wrap mb-4">{generatedContent.content}</p>
              
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-400">Viral potential:</span>
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className={i < Math.floor(generatedContent.viral_score / 20) ? 'text-yellow-400' : 'text-gray-600'}>
                        ⭐
                      </span>
                    ))}
                  </div>
                  <span className="text-yellow-400 font-bold">{generatedContent.viral_score}/100</span>
                </div>
              </div>

              {generatedContent.suggestions && (
                <div>
                  <p className="text-sm text-gray-400 mb-2">💡 Improvement tips:</p>
                  <ul className="space-y-1">
                    {generatedContent.suggestions.map((suggestion, i) => (
                      <li key={i} className="text-sm text-blue-300">• {suggestion}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Add image</label>
              <input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
                id="image-upload-step2"
              />
              <label htmlFor="image-upload-step2">
                <Button variant="outline" className="border-dashed border-blue-400 text-blue-300" asChild>
                  <span>
                    <Upload className="mr-2" size={16} />
                    {uploadedFile ? 'Change image' : 'Upload image'}
                  </span>
                </Button>
              </label>
            </div>

            <div className="flex gap-4">
              <Button
                variant="outline"
                onClick={() => setStep(1)}
                className="flex-1 border-gray-600
                text-gray-300"
              >
                Back
              </Button>
              <Button
                onClick={() => setStep(3)}
                className="flex-1 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
              >
                Continue
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Publish */}
      {step === 3 && (
        <Card className="bg-slate-800/60 backdrop-blur border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <CheckCircle2 className="text-purple-400" />
              Step 3: Publish
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Title *</label>
              <Input
                placeholder="Enter creation title"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-white"
              />
            </div>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Tags (comma separated)</label>
              <Input
                placeholder="meme, ecology, amsterdam"
                onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value.split(',').map(t => t.trim()) }))}
                className="bg-slate-700 border-slate-600 text-white"
              />
            </div>

            {uploadedFile && (
              <div className="rounded-lg overflow-hidden border border-purple-500/30">
                <img src={uploadedFile} alt="Preview" className="w-full h-64 object-cover" />
              </div>
            )}

            <div className="bg-purple-900/30 rounded-lg p-4 border border-purple-500/30">
              <p className="text-sm text-purple-200">
                ✨ After publishing your work will appear in the community and can participate in voting!
              </p>
            </div>

            <div className="flex gap-4">
              <Button
                variant="outline"
                onClick={() => setStep(generatedContent ? 2 : 1)}
                className="flex-1 border-gray-600 text-gray-300"
              >
                Back
              </Button>
              <Button
                onClick={handlePublish}
                disabled={createCreationMutation.isPending}
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                {createCreationMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 animate-spin" />
                    Publishing...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="mr-2" />
                    Publish
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading Overlay */}
      {generating && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="text-center">
            <Loader2 className="w-16 h-16 text-blue-400 animate-spin mx-auto mb-4" />
            <p className="text-white text-xl font-semibold">AI is creating content...</p>
            <p className="text-gray-400 mt-2">This may take a few seconds</p>
          </div>
        </div>
      )}
    </div>
  );
}