import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  User, Trophy, Target, Heart, Zap, TrendingUp, Award, 
  Calendar, Star, Share2, Edit, LogOut, Gift, Copy 
} from "lucide-react";
import { toast } from "sonner";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [referralCode, setReferralCode] = useState('');

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      // Generate referral code based on user ID
      if (currentUser.id) {
        const code = btoa(currentUser.id).substring(0, 8).toUpperCase();
        setReferralCode(code);
      }
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: myCreations = [] } = useQuery({
    queryKey: ['my-creations', user?.email],
    queryFn: () => user ? base44.entities.Creation.filter({ created_by: user.email }) : [],
    initialData: [],
    enabled: !!user
  });

  const { data: myRatings = [] } = useQuery({
    queryKey: ['my-ratings', user?.email],
    queryFn: () => user ? base44.entities.Rating.filter({ created_by: user.email }) : [],
    initialData: [],
    enabled: !!user
  });

  const handleLogout = () => {
    base44.auth.logout();
    toast.success("Logged out!");
  };

  const copyReferralLink = async () => {
    const link = `${window.location.origin}?ref=${referralCode}`;
    try {
      await navigator.clipboard.writeText(link);
      toast.success("Referral link copied!");
    } catch (error) {
      toast.error("Failed to copy");
    }
  };

  const getPathIcon = (path) => {
    const icons = {
      meme_path: '🎭',
      reel_rush: '🎬',
      melody_maze: '🎵',
      combo_chaos: '⚡',
      none: ''
    };
    return icons[path] || '';
  };

  const getPathName = (path) => {
    const names = {
      meme_path: 'Meme Path',
      reel_rush: 'Reel Rush',
      melody_maze: 'Melody Maze',
      combo_chaos: 'Combo Chaos',
      none: 'No Path'
    };
    return names[path] || 'No Path';
  };

  const getTierBadge = (tier) => {
    const badges = {
      free: { label: 'Free', color: 'bg-gray-500' },
      paid: { label: 'Paid', color: 'bg-blue-500' },
      elite: { label: 'Elite', color: 'bg-yellow-500' }
    };
    return badges[tier] || badges.free;
  };

  const totalLikes = myCreations.reduce((sum, c) => sum + (c.likes || 0), 0);
  const totalShares = myCreations.reduce((sum, c) => sum + (c.shares || 0), 0);
  const avgRating = myCreations.length > 0 
    ? myCreations.reduce((sum, c) => sum + (c.rating_avg || 0), 0) / myCreations.length 
    : 0;

  const topCreation = myCreations.sort((a, b) => (b.likes || 0) - (a.likes || 0))[0];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              My Profile
            </h1>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-red-500/30 text-red-400 hover:bg-red-500/20"
            >
              <LogOut className="mr-2" size={16} />
              Logout
            </Button>
          </div>
        </div>

        {user && (
          <>
            {/* Main Info Card */}
            <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur border-purple-500/30 mb-8">
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="flex-shrink-0">
                    <div className="w-32 h-32 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                      <User className="text-white" size={64} />
                    </div>
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-3 mb-4">
                      <h2 className="text-3xl font-bold text-white">{user.full_name || user.email}</h2>
                      <Badge className={`${getTierBadge(user.subscription_tier).color} text-white`}>
                        {getTierBadge(user.subscription_tier).label}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                      <div>
                        <p className="text-sm text-gray-400">Level</p>
                        <p className="text-2xl font-bold text-blue-400">{user.level || 1}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Mana</p>
                        <p className="text-2xl font-bold text-green-400">{user.mana || 0}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Karma</p>
                        <p className="text-2xl font-bold text-pink-400">{user.karma || 0}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Tokens</p>
                        <p className="text-2xl font-bold text-yellow-400">{(user.tokens || 0).toFixed(2)}€</p>
                      </div>
                    </div>

                    {user.specialization_path && user.specialization_path !== 'none' && (
                      <div className="bg-purple-900/30 rounded-lg p-4 border border-purple-500/30">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{getPathIcon(user.specialization_path)}</span>
                          <div>
                            <p className="text-sm text-gray-400">Specialization</p>
                            <p className="text-lg font-bold text-purple-300">{getPathName(user.specialization_path)}</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {(!user.specialization_path || user.specialization_path === 'none') && user.subscription_tier !== 'free' && (
                      <Link to={createPageUrl("SpecializationSelect")}>
                        <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                          Choose Specialization Path
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Stats Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <Card className="bg-slate-800/60 backdrop-blur border-purple-500/30">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-gray-400 flex items-center gap-2">
                    <Trophy className="text-purple-400" size={16} />
                    Creations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-white">{myCreations.length}</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/60 backdrop-blur border-pink-500/30">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-gray-400 flex items-center gap-2">
                    <Heart className="text-pink-400" size={16} />
                    Total Likes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-white">{totalLikes}</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/60 backdrop-blur border-yellow-500/30">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-gray-400 flex items-center gap-2">
                    <Star className="text-yellow-400" size={16} />
                    Avg Rating
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-white">{avgRating.toFixed(1)}</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/60 backdrop-blur border-blue-500/30">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-gray-400 flex items-center gap-2">
                    <Share2 className="text-blue-400" size={16} />
                    Total Shares
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-white">{totalShares}</p>
                </CardContent>
              </Card>
            </div>

            {/* Subscription & Payments */}
            <div className="grid md:grid-cols-3 gap-4 mb-8">
              <Link to={createPageUrl("Pricing")}>
                <Card className="bg-slate-800/60 backdrop-blur border-purple-500/30 hover:border-purple-400 transition-all cursor-pointer h-full">
                  <CardContent className="pt-6 text-center">
                    <span className="text-4xl mb-3 block">💎</span>
                    <h3 className="text-white font-bold mb-2">Upgrade Plan</h3>
                    <p className="text-gray-400 text-sm">View pricing & subscribe</p>
                  </CardContent>
                </Card>
              </Link>

              <Link to={createPageUrl("Subscription")}>
                <Card className="bg-slate-800/60 backdrop-blur border-blue-500/30 hover:border-blue-400 transition-all cursor-pointer h-full">
                  <CardContent className="pt-6 text-center">
                    <span className="text-4xl mb-3 block">⚙️</span>
                    <h3 className="text-white font-bold mb-2">Subscription</h3>
                    <p className="text-gray-400 text-sm">Manage your plan</p>
                  </CardContent>
                </Card>
              </Link>

              <Link to={createPageUrl("Payout")}>
                <Card className="bg-slate-800/60 backdrop-blur border-green-500/30 hover:border-green-400 transition-all cursor-pointer h-full">
                  <CardContent className="pt-6 text-center">
                    <span className="text-4xl mb-3 block">💰</span>
                    <h3 className="text-white font-bold mb-2">Withdraw</h3>
                    <p className="text-gray-400 text-sm">€{(user.tokens || 0).toFixed(2)} available</p>
                  </CardContent>
                </Card>
              </Link>
            </div>

            {/* Activity Stats */}
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <Card className="bg-slate-800/60 backdrop-blur border-green-500/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="text-green-400" />
                    Activity
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Published Creations</span>
                    <Badge variant="outline" className="border-green-400/30 text-green-300">
                      {myCreations.filter(c => c.status === 'published').length}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Given Ratings</span>
                    <Badge variant="outline" className="border-yellow-400/30 text-yellow-300">
                      {myRatings.length}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Experience Points</span>
                    <Badge variant="outline" className="border-blue-400/30 text-blue-300">
                      {user.experience_points || 0} XP
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Member Since</span>
                    <span className="text-white text-sm">
                      {new Date(user.created_date).toLocaleDateString()}
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/60 backdrop-blur border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Award className="text-purple-400" />
                    Top Creation
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {topCreation ? (
                    <div className="space-y-3">
                      {topCreation.image_url && (
                        <img 
                          src={topCreation.image_url} 
                          alt={topCreation.title}
                          className="w-full h-32 object-cover rounded-lg"
                        />
                      )}
                      <h3 className="text-white font-bold">{topCreation.title}</h3>
                      <div className="flex items-center gap-4 text-sm">
                        <span className="text-pink-400">❤️ {topCreation.likes || 0}</span>
                        <span className="text-yellow-400">⭐ {(topCreation.rating_avg || 0).toFixed(1)}</span>
                        <span className="text-blue-400">📤 {topCreation.shares || 0}</span>
                      </div>
                      <Link to={createPageUrl("Community")}>
                        <Button size="sm" variant="outline" className="w-full border-purple-400/30 text-purple-300">
                          View in Community
                        </Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-400">No creations yet</p>
                      <Link to={createPageUrl("Studio")}>
                        <Button size="sm" className="mt-4 bg-gradient-to-r from-purple-500 to-pink-500">
                          Create Now
                        </Button>
                      </Link>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Referral Program (Coming Soon) */}
            <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-500/30 mb-8">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Gift className="text-purple-400" />
                  Referral Program
                  <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 ml-auto">
                    Coming Soon
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-300 text-sm">
                  Invite friends and get bonuses! Each invited friend gives +50 mana to you and them.
                </p>
                
                <div className="bg-slate-800/60 rounded-lg p-4 border border-purple-500/30">
                  <label className="text-xs text-gray-400 mb-2 block">Your referral link:</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      readOnly
                      value={`${window.location.origin}?ref=${referralCode}`}
                      className="flex-1 bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
                    />
                    <Button
                      onClick={copyReferralLink}
                      variant="outline"
                      className="border-purple-400 text-purple-300"
                      disabled={!referralCode}
                    >
                      <Copy size={16} />
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-green-900/30 rounded-lg p-3 border border-green-500/30 text-center">
                    <p className="text-2xl font-bold text-green-400">0</p>
                    <p className="text-xs text-gray-400">Invited Friends</p>
                  </div>
                  <div className="bg-purple-900/30 rounded-lg p-3 border border-purple-500/30 text-center">
                    <p className="text-2xl font-bold text-purple-400">0</p>
                    <p className="text-xs text-gray-400">Earned Mana</p>
                  </div>
                </div>

                <p className="text-xs text-gray-500 text-center">
                  Feature launching in the coming weeks. Stay tuned!
                </p>
              </CardContent>
            </Card>

            {/* Recent Creations */}
            <Card className="bg-slate-800/60 backdrop-blur border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Trophy className="text-blue-400" />
                    My Recent Creations
                  </span>
                  <Link to={createPageUrl("Community")}>
                    <Button variant="ghost" size="sm" className="text-blue-400">
                      View All →
                    </Button>
                  </Link>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {myCreations.slice(0, 4).map((creation) => (
                    <div key={creation.id} className="group cursor-pointer">
                      <div className="aspect-square relative overflow-hidden rounded-lg border border-slate-600 group-hover:border-blue-400 transition-colors">
                        {creation.image_url ? (
                          <img 
                            src={creation.image_url} 
                            alt={creation.title}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                          />
                        ) : (
                          <div className="w-full h-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center">
                            <Trophy className="text-white" size={32} />
                          </div>
                        )}
                        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2">
                          <p className="text-white text-xs font-semibold truncate">{creation.title}</p>
                          <div className="flex items-center gap-2 text-xs text-gray-300 mt-1">
                            <span>❤️ {creation.likes || 0}</span>
                            <span>⭐ {(creation.rating_avg || 0).toFixed(1)}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                {myCreations.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-gray-400 mb-4">You haven't created anything yet</p>
                    <Link to={createPageUrl("Studio")}>
                      <Button className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600">
                        Create First Content
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}