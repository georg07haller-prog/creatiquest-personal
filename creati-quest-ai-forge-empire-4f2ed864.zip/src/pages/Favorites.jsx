import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Trash2, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Favorites() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  const { data: favorites = [] } = useQuery({
    queryKey: ['favorites', user?.email],
    queryFn: () => user ? base44.entities.Favorite.filter({ created_by: user.email }) : [],
    initialData: [],
    enabled: !!user
  });

  const { data: allCreations = [] } = useQuery({
    queryKey: ['all-creations'],
    queryFn: () => base44.entities.Creation.list('-created_date'),
    initialData: [],
  });

  const removeFavoriteMutation = useMutation({
    mutationFn: (favoriteId) => base44.entities.Favorite.delete(favoriteId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['favorites'] });
      toast.success("Removed from favorites");
    },
  });

  const favoriteCreations = favorites
    .map(fav => allCreations.find(c => c.id === fav.creation_id))
    .filter(Boolean);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-pink-400 to-red-400 bg-clip-text text-transparent">
          ❤️ Favorites
        </h1>
        <p className="text-blue-300">Your saved creations</p>
      </div>

      {favoriteCreations.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {favoriteCreations.map((creation) => {
            const favorite = favorites.find(f => f.creation_id === creation.id);
            return (
              <Card key={creation.id} className="bg-slate-800/60 backdrop-blur border-pink-500/30 hover:border-pink-400 transition-all overflow-hidden">
                {creation.image_url && (
                  <div className="aspect-video relative overflow-hidden">
                    <img 
                      src={creation.image_url} 
                      alt={creation.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                
                <CardContent className="p-4">
                  <h3 className="text-lg font-bold text-white mb-2">{creation.title}</h3>
                  {creation.content && (
                    <p className="text-sm text-gray-400 mb-4 line-clamp-2">{creation.content}</p>
                  )}
                  
                  {favorite?.notes && (
                    <div className="bg-purple-900/30 rounded-lg p-2 mb-3 border border-purple-500/30">
                      <p className="text-xs text-purple-200">"{favorite.notes}"</p>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Link to={createPageUrl("Community")} className="flex-1">
                      <Button variant="outline" size="sm" className="w-full border-blue-400/30 text-blue-300">
                        <ExternalLink size={16} className="mr-2" />
                        View
                      </Button>
                    </Link>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeFavoriteMutation.mutate(favorite.id)}
                      className="border-red-400/30 text-red-300 hover:bg-red-500/20"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-12">
          <Heart size={48} className="mx-auto mb-4 text-gray-600" />
          <p className="text-gray-400 text-lg mb-2">No favorites yet</p>
          <p className="text-gray-500 text-sm">Save your favorite creations from the community!</p>
          <Link to={createPageUrl("Community")}>
            <Button className="mt-4 bg-gradient-to-r from-pink-500 to-red-500">
              Explore Community
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}