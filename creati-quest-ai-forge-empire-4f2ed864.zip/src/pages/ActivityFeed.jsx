import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Trophy, Target, TrendingUp, Heart, MessageCircle, Users } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ActivityFeed() {
  const { data: activities = [] } = useQuery({
    queryKey: ['my-activities'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.Activity.filter({ created_by: user.email }, '-created_date', 50);
    },
    initialData: [],
  });

  const getIcon = (type) => {
    const icons = {
      creation_published: Trophy,
      contest_won: Trophy,
      quest_completed: Target,
      level_up: TrendingUp,
      achievement_unlocked: Trophy,
      followed: Users,
      comment_received: MessageCircle
    };
    return icons[type] || Trophy;
  };

  const getColor = (type) => {
    const colors = {
      creation_published: 'purple',
      contest_won: 'yellow',
      quest_completed: 'green',
      level_up: 'blue',
      achievement_unlocked: 'orange',
      followed: 'pink',
      comment_received: 'blue'
    };
    return colors[type] || 'gray';
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
          📜 Activity Feed
        </h1>
        <p className="text-blue-300">Your recent achievements and events</p>
      </div>

      <div className="space-y-4">
        {activities.map((activity) => {
          const Icon = getIcon(activity.type);
          const color = getColor(activity.type);
          
          return (
            <Card key={activity.id} className={`bg-slate-800/60 backdrop-blur border-${color}-500/30 hover:border-${color}-400 transition-all`}>
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-full bg-${color}-500/20 flex items-center justify-center flex-shrink-0`}>
                    <span className="text-2xl">{activity.icon}</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-white font-semibold mb-1">{activity.title}</h3>
                    <p className="text-gray-400 text-sm mb-2">{activity.description}</p>
                    <span className="text-xs text-gray-500">
                      {formatDistanceToNow(new Date(activity.created_date), { addSuffix: true })}
                    </span>
                  </div>
                  {activity.link && (
                    <Link to={activity.link}>
                      <button className="text-blue-400 hover:text-blue-300 text-sm">
                        View →
                      </button>
                    </Link>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}

        {activities.length === 0 && (
          <div className="text-center py-12">
            <Trophy size={48} className="mx-auto mb-4 text-gray-600" />
            <p className="text-gray-400 text-lg mb-2">No activities yet</p>
            <p className="text-gray-500 text-sm">Start creating content to see your activities here!</p>
            <Link to={createPageUrl("Studio")}>
              <button className="mt-4 px-6 py-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg text-white font-semibold hover:from-purple-600 hover:to-pink-600">
                Create Now
              </button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}