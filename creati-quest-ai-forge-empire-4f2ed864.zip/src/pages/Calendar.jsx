import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarIcon, Trophy, Target, Vote, Clock } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, parseISO } from "date-fns";

export default function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());

  const { data: contests = [] } = useQuery({
    queryKey: ['calendar-contests'],
    queryFn: () => base44.entities.Contest.list('-end_date', 100),
    initialData: [],
  });

  const { data: quests = [] } = useQuery({
    queryKey: ['calendar-quests'],
    queryFn: () => base44.entities.Quest.list('-deadline', 100),
    initialData: [],
  });

  const { data: polls = [] } = useQuery({
    queryKey: ['calendar-polls'],
    queryFn: () => base44.entities.Poll.list('-deadline', 100),
    initialData: [],
  });

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const getEventsForDay = (day) => {
    const events = [];
    
    contests.forEach(contest => {
      const endDate = parseISO(contest.end_date);
      if (isSameDay(endDate, day)) {
        events.push({ type: 'contest', title: contest.title, icon: Trophy, color: 'yellow' });
      }
    });

    quests.forEach(quest => {
      const deadline = parseISO(quest.deadline);
      if (isSameDay(deadline, day)) {
        events.push({ type: 'quest', title: quest.title, icon: Target, color: 'green' });
      }
    });

    polls.forEach(poll => {
      const deadline = parseISO(poll.deadline);
      if (isSameDay(deadline, day)) {
        events.push({ type: 'poll', title: poll.title, icon: Vote, color: 'purple' });
      }
    });

    return events;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
          📅 Event Calendar
        </h1>
        <p className="text-blue-300">Upcoming contests, quests, and polls</p>
      </div>

      {/* Month Navigation */}
      <Card className="bg-slate-800/60 backdrop-blur border-blue-500/30 mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              onClick={() => setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() - 1)))}
              className="border-blue-400/30 text-blue-300"
            >
              ← Previous
            </Button>
            <CardTitle className="text-white">
              {format(currentDate, 'MMMM yyyy')}
            </CardTitle>
            <Button
              variant="outline"
              onClick={() => setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() + 1)))}
              className="border-blue-400/30 text-blue-300"
            >
              Next →
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-2 mb-4">
        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
          <div key={day} className="text-center text-gray-400 text-sm font-semibold p-2">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-2">
        {daysInMonth.map((day, index) => {
          const events = getEventsForDay(day);
          const isToday = isSameDay(day, new Date());
          
          return (
            <Card
              key={index}
              className={`min-h-24 ${
                isToday 
                  ? 'bg-blue-900/40 border-blue-400' 
                  : 'bg-slate-800/40 border-slate-600'
              } ${events.length > 0 ? 'border-purple-400/50' : ''}`}
            >
              <CardContent className="p-2">
                <div className={`text-right mb-1 ${isToday ? 'text-blue-300 font-bold' : 'text-gray-400'}`}>
                  {format(day, 'd')}
                </div>
                <div className="space-y-1">
                  {events.map((event, idx) => {
                    const Icon = event.icon;
                    return (
                      <div
                        key={idx}
                        className={`text-xs p-1 rounded bg-${event.color}-500/20 border border-${event.color}-500/30 flex items-center gap-1`}
                      >
                        <Icon size={10} />
                        <span className="truncate">{event.title}</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Legend */}
      <div className="mt-6 flex flex-wrap gap-4 justify-center">
        <div className="flex items-center gap-2">
          <Trophy size={16} className="text-yellow-400" />
          <span className="text-sm text-gray-300">Contest Deadline</span>
        </div>
        <div className="flex items-center gap-2">
          <Target size={16} className="text-green-400" />
          <span className="text-sm text-gray-300">Quest Deadline</span>
        </div>
        <div className="flex items-center gap-2">
          <Vote size={16} className="text-purple-400" />
          <span className="text-sm text-gray-300">Poll Ends</span>
        </div>
      </div>
    </div>
  );
}