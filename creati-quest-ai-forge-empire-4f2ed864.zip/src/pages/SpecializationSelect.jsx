import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Image, Video, Music, Zap, ArrowRight, Lock } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function SpecializationSelect() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [selectedPath, setSelectedPath] = useState(null);
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      if (currentUser.specialization_path && currentUser.specialization_path !== 'none') {
        navigate(createPageUrl("Dashboard"));
      }
      
      if (currentUser.subscription_tier === 'free') {
        toast.error("Specialization unlocks with Paid subscription!");
        navigate(createPageUrl("Dashboard"));
      }
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const paths = [
    {
      id: 'meme_path',
      name: 'Meme Path',
      subtitle: 'Pixel Punch',
      icon: Image,
      color: 'from-green-500 to-emerald-500',
      borderColor: 'border-green-500/30',
      description: 'Master the art of viral memes and static graphics',
      perks: [
        'Extra votes in contests',
        '+20% mana on meme generation',
        'Access to Meme Master agent',
        'Priority in graphic contests'
      ],
      starterQuest: 'Berlin Graffiti Glitch',
      rewards: '40-80€ per quest chain'
    },
    {
      id: 'reel_rush',
      name: 'Reel Rush',
      subtitle: 'Video Vortex',
      icon: Video,
      color: 'from-blue-500 to-cyan-500',
      borderColor: 'border-blue-500/30',
      description: 'Create viral short videos and Reels',
      perks: [
        'View boost multipliers',
        '+30% rewards on video quests',
        'Access to Video Visionary agent',
        'Exclusive Reel templates'
      ],
      starterQuest: 'Amsterdam Canal Clip',
      rewards: '60-100€ per quest chain'
    },
    {
      id: 'melody_maze',
      name: 'Melody Maze',
      subtitle: 'Tune Forge',
      icon: Music,
      color: 'from-purple-500 to-pink-500',
      borderColor: 'border-purple-500/30',
      description: 'Compose AI-generated songs and lyrics',
      perks: [
        'Stream multipliers',
        '+25% royalties on songs',
        'Access to Melody Maestro agent',
        'Audio library access'
      ],
      starterQuest: 'Munich Melody March',
      rewards: '50-90€ per quest chain'
    },
    {
      id: 'combo_chaos',
      name: 'Combo Chaos',
      subtitle: 'All-In Alchemy',
      icon: Zap,
      color: 'from-pink-500 to-orange-500',
      borderColor: 'border-pink-500/30',
      description: 'Master all content types with hybrid creations',
      perks: [
        'Cross-platform share bonuses',
        '+50% rewards on hybrid quests',
        'Access to Fusion Forge agent',
        'All path perks combined'
      ],
      starterQuest: 'Prague Fusion Frenzy',
      rewards: '80-150€ per quest chain'
    }
  ];

  const handleSelectPath = async () => {
    if (!selectedPath) {
      toast.error("Select a specialization path!");
      return;
    }

    setConfirming(true);
    try {
      await base44.auth.updateMe({
        specialization_path: selectedPath.id,
        path_unlocked_at: new Date().toISOString()
      });
      
      toast.success(`Welcome to ${selectedPath.name}! 🎉`);
      navigate(createPageUrl("Quests"));
    } catch (error) {
      toast.error("Error selecting path");
      console.error(error);
    }
    setConfirming(false);
  };

  const respecCost = user ? (user.respec_count + 1) * 50 : 50;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4 md:p-8">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-yellow-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
            Choose Your Path
          </h1>
          <p className="text-xl text-blue-200 mb-2">
            Select your specialization to unlock unique quests and agents
          </p>
          <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 px-4 py-2">
            ⚠️ Path locks in - Respec costs {respecCost} mana
          </Badge>
        </div>

        {user && user.subscription_tier === 'free' && (
          <Alert className="mb-6 bg-gradient-to-r from-red-900/30 to-orange-900/30 border-red-500/30">
            <Lock className="h-4 w-4 text-red-400" />
            <AlertDescription className="text-white">
              <strong>Paid Subscription Required</strong>
              <p className="text-sm text-gray-400 mt-1">Upgrade to Paid (€4.99/month) to unlock specialization paths</p>
            </AlertDescription>
          </Alert>
        )}

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {paths.map((path) => {
            const Icon = path.icon;
            const isSelected = selectedPath?.id === path.id;
            
            return (
              <Card 
                key={path.id}
                onClick={() => setSelectedPath(path)}
                className={`cursor-pointer transition-all duration-300 overflow-hidden ${
                  isSelected 
                    ? `bg-slate-800/90 backdrop-blur border-4 ${path.borderColor} ring-4 ring-white/20 scale-105` 
                    : `bg-slate-800/60 backdrop-blur ${path.borderColor} hover:scale-102`
                }`}
              >
                <div className={`h-2 bg-gradient-to-r ${path.color}`} />
                
                <CardHeader>
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${path.color} flex items-center justify-center`}>
                      <Icon size={32} className="text-white" />
                    </div>
                    {isSelected && (
                      <Badge className="bg-green-500 text-white">
                        ✓ Selected
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-white text-2xl mb-2">
                    {path.name}
                  </CardTitle>
                  <p className="text-gray-400 font-semibold">{path.subtitle}</p>
                </CardHeader>

                <CardContent className="space-y-4">
                  <p className="text-gray-300">{path.description}</p>

                  <div>
                    <p className="text-sm text-gray-400 mb-2">🎯 Starter Quest:</p>
                    <Badge variant="outline" className="border-blue-400/30 text-blue-300">
                      {path.starterQuest}
                    </Badge>
                  </div>

                  <div>
                    <p className="text-sm text-gray-400 mb-2">💰 Quest Rewards:</p>
                    <p className="text-yellow-400 font-bold">{path.rewards}</p>
                  </div>

                  <div>
                    <p className="text-sm text-gray-400 mb-2">✨ Path Perks:</p>
                    <ul className="space-y-1">
                      {path.perks.map((perk, idx) => (
                        <li key={idx} className="text-sm text-green-300 flex items-start gap-2">
                          <span className="text-green-400 mt-0.5">•</span>
                          {perk}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button
                    variant={isSelected ? "default" : "outline"}
                    className={`w-full ${
                      isSelected 
                        ? `bg-gradient-to-r ${path.color} hover:opacity-90` 
                        : `border-gray-600 text-gray-300`
                    }`}
                    onClick={() => setSelectedPath(path)}
                  >
                    {isSelected ? 'Selected ✓' : 'Choose This Path'}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {selectedPath && (
          <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 backdrop-blur rounded-xl p-6 border border-purple-500/30">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-2xl font-bold text-white mb-2">
                  Ready to forge your empire?
                </h3>
                <p className="text-gray-300">
                  You've selected <span className="text-purple-400 font-bold">{selectedPath.name}</span>
                </p>
              </div>
              <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${selectedPath.color} flex items-center justify-center`}>
                <selectedPath.icon size={32} className="text-white" />
              </div>
            </div>

            <Alert className="mb-4 bg-yellow-900/30 border-yellow-500/30">
              <Sparkles className="h-4 w-4 text-yellow-400" />
              <AlertDescription className="text-yellow-200">
                <strong>Important:</strong> Once chosen, respecialization costs <strong>{respecCost} mana</strong>. Choose wisely!
              </AlertDescription>
            </Alert>

            <Button
              onClick={handleSelectPath}
              disabled={confirming}
              className={`w-full py-6 text-lg bg-gradient-to-r ${selectedPath.color} hover:opacity-90`}
            >
              {confirming ? (
                "Forging your path..."
              ) : (
                <>
                  Confirm {selectedPath.name}
                  <ArrowRight className="ml-2" />
                </>
              )}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}