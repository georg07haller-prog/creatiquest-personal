import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, Loader2, Calendar, CreditCard } from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Subscription() {
  const [user, setUser] = useState(null);
  const [subscription, setSubscription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [cancelLoading, setCancelLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      if (currentUser.subscription_id) {
        const { data } = await base44.functions.invoke('getSubscriptionStatus', {});
        setSubscription(data);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async () => {
    if (!confirm('Are you sure you want to cancel your subscription? You will keep access until the end of your billing period.')) {
      return;
    }

    setCancelLoading(true);
    try {
      const { data } = await base44.functions.invoke('cancelSubscription', {});
      
      if (data.success) {
        toast.success(`Subscription cancelled. Access until ${new Date(data.accessUntil).toLocaleDateString()}`);
        await loadData();
      }
    } catch (error) {
      toast.error("Failed to cancel subscription");
      console.error(error);
    } finally {
      setCancelLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="animate-spin text-blue-400" size={48} />
      </div>
    );
  }

  const isActive = subscription?.status === 'active';
  const isCancelled = subscription?.cancelAtPeriodEnd;

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
          💎 My Subscription
        </h1>
        <p className="text-blue-300">Manage your Premium membership</p>
      </div>

      {!subscription?.hasSubscription ? (
        <Card className="bg-slate-800/60 backdrop-blur border-blue-500/30">
          <CardContent className="pt-8 pb-8 text-center">
            <div className="w-24 h-24 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-5xl">🎯</span>
            </div>
            <h2 className="text-2xl font-bold text-white mb-4">No Active Subscription</h2>
            <p className="text-gray-300 mb-6">
              You're currently on the free tier. Upgrade to Premium to unlock quests, 
              specialization paths, and higher rewards!
            </p>
            <Link to={createPageUrl("Pricing")}>
              <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                View Pricing Plans
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Subscription Status */}
          <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-500/30 mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white flex items-center gap-2">
                  <CreditCard className="text-purple-400" />
                  Premium Subscription
                </CardTitle>
                {isActive && !isCancelled ? (
                  <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                    <CheckCircle2 size={14} className="mr-1" />
                    Active
                  </Badge>
                ) : isCancelled ? (
                  <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                    <XCircle size={14} className="mr-1" />
                    Cancelling
                  </Badge>
                ) : (
                  <Badge className="bg-red-500/20 text-red-300 border-red-500/30">
                    <XCircle size={14} className="mr-1" />
                    Inactive
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Price</span>
                  <span className="text-white font-semibold">€4.99/month</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Status</span>
                  <span className="text-white font-semibold capitalize">{subscription.status}</span>
                </div>
                {subscription.currentPeriodEnd && (
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400 flex items-center gap-2">
                      <Calendar size={16} />
                      {isCancelled ? 'Access Until' : 'Next Billing'}
                    </span>
                    <span className="text-white font-semibold">
                      {new Date(subscription.currentPeriodEnd).toLocaleDateString()}
                    </span>
                  </div>
                )}
              </div>

              {isCancelled && (
                <div className="mt-6 bg-yellow-900/30 border border-yellow-500/30 rounded-lg p-4">
                  <p className="text-yellow-200 text-sm">
                    Your subscription will end on {new Date(subscription.currentPeriodEnd).toLocaleDateString()}. 
                    You will keep access to Premium features until then.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Premium Features */}
          <Card className="bg-slate-800/60 backdrop-blur border-purple-500/30 mb-6">
            <CardHeader>
              <CardTitle className="text-white">Your Premium Benefits</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-center gap-2 text-green-300">
                  <CheckCircle2 size={16} />
                  <span>Specialization path access</span>
                </li>
                <li className="flex items-center gap-2 text-green-300">
                  <CheckCircle2 size={16} />
                  <span>Sponsored quest chains (€40-150)</span>
                </li>
                <li className="flex items-center gap-2 text-green-300">
                  <CheckCircle2 size={16} />
                  <span>Path-specific perks & bonuses</span>
                </li>
                <li className="flex items-center gap-2 text-green-300">
                  <CheckCircle2 size={16} />
                  <span>Community governance polls</span>
                </li>
                <li className="flex items-center gap-2 text-green-300">
                  <CheckCircle2 size={16} />
                  <span>Exclusive themed content</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          {/* Actions */}
          <Card className="bg-slate-800/60 backdrop-blur border-slate-600">
            <CardHeader>
              <CardTitle className="text-white">Manage Subscription</CardTitle>
            </CardHeader>
            <CardContent>
              {isActive && !isCancelled && (
                <Button
                  onClick={handleCancel}
                  disabled={cancelLoading}
                  variant="outline"
                  className="w-full border-red-400/30 text-red-300 hover:bg-red-500/20"
                >
                  {cancelLoading ? (
                    <>
                      <Loader2 className="mr-2 animate-spin" size={16} />
                      Cancelling...
                    </>
                  ) : (
                    <>
                      <XCircle className="mr-2" size={16} />
                      Cancel Subscription
                    </>
                  )}
                </Button>
              )}

              {isCancelled && (
                <div className="text-center py-4">
                  <p className="text-gray-400 mb-4">
                    Want to continue with Premium?
                  </p>
                  <Link to={createPageUrl("Pricing")}>
                    <Button className="bg-gradient-to-r from-purple-500 to-pink-500">
                      Reactivate Subscription
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}