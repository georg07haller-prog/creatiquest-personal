import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, AlertTriangle } from "lucide-react";

export default function Terms() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent flex items-center gap-3">
          <FileText className="text-green-400" size={40} />
          Terms of Service
        </h1>
        <p className="text-gray-400">Last updated: January 15, 2025</p>
      </div>

      <div className="space-y-6">
        <Card className="bg-slate-800/60 backdrop-blur border-green-500/30">
          <CardHeader>
            <CardTitle className="text-white">1. General Provisions</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <p>
              By using CreatiQuest, you agree to these terms. If you don't agree, please don't use the platform.
            </p>
            <ul className="list-disc ml-6 space-y-2">
              <li>Age: 18+ years</li>
              <li>Region: Available for EU residents</li>
              <li>Account: One account per person</li>
              <li>Responsibility: You are responsible for actions in your account</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-blue-500/30">
          <CardHeader>
            <CardTitle className="text-white">2. Content Rules</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <p><strong>Allowed:</strong></p>
            <ul className="list-disc ml-6 space-y-1">
              <li>Original or AI-generated content</li>
              <li>Memes, videos, songs, texts respecting copyright</li>
              <li>Eco-themed and creative ideas</li>
            </ul>
            <p className="mt-4"><strong>Prohibited:</strong></p>
            <ul className="list-disc ml-6 space-y-1 text-red-300">
              <li>Hate speech, discrimination, harassment</li>
              <li>NSFW content (18+, pornography, violence)</li>
              <li>Plagiarism and copyright infringement</li>
              <li>Spam, vote manipulation, cheats</li>
              <li>Political or religious extremism</li>
            </ul>
            <p className="mt-4 text-yellow-300 text-sm flex items-start gap-2">
              <AlertTriangle size={16} className="mt-0.5 flex-shrink-0" />
              <span>Violations: 1st warning, 2nd - 7 day ban, 3rd - permanent ban</span>
            </p>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-white">3. Subscription and Payments</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <ul className="list-disc ml-6 space-y-2">
              <li><strong>Free tier:</strong> Access to contests, limited mana</li>
              <li><strong>Paid (€4.99/mo):</strong> Quests, specialization paths, higher rewards</li>
              <li><strong>Elite (soon):</strong> Strategies, agents, ROI up to €500+</li>
              <li><strong>Payment:</strong> Stripe, automatic renewal</li>
              <li><strong>Cancellation:</strong> Anytime, access until end of paid period</li>
              <li><strong>Refund:</strong> Possible within 7 days for technical issues</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-yellow-500/30">
          <CardHeader>
            <CardTitle className="text-white">4. Prizes and Payouts</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <p><strong>Prize pool:</strong></p>
            <ul className="list-disc ml-6 space-y-2">
              <li>Contests: €1-10 for top 10 participants</li>
              <li>Quests: €40-150 for completing chain</li>
              <li>Strategies (Elite): €200-500+ from ROI</li>
            </ul>
            <p className="mt-4"><strong>Payout conditions (Coming Soon):</strong></p>
            <ul className="list-disc ml-6 space-y-2">
              <li>Minimum: €5 in tokens</li>
              <li>Method: Stripe → bank account</li>
              <li>Processing: 1-3 business days</li>
              <li>Taxes: Players self-report income</li>
            </ul>
            <p className="mt-4 text-sm text-gray-400">
              <strong>Fallback:</strong> If prize pool is underfunded, prize rolls over to next similar event or donated to eco-charity (WWF).
            </p>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-pink-500/30">
          <CardHeader>
            <CardTitle className="text-white">5. Voting and Fair Play</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <ul className="list-disc ml-6 space-y-2">
              <li>One vote per creation per user</li>
              <li>Prohibited: bots, manipulation, multiple accounts</li>
              <li>AI moderation tracks suspicious activity</li>
              <li>For manipulation: results voided + ban</li>
              <li>Ratings require comment (min 10 characters)</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-red-500/30">
          <CardHeader>
            <CardTitle className="text-white">6. Content Rights</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <ul className="list-disc ml-6 space-y-2">
              <li><strong>Your rights:</strong> You own the created content</li>
              <li><strong>Platform license:</strong> By publishing, you grant CreatiQuest a non-exclusive license to distribute, display and promote</li>
              <li><strong>AI content:</strong> You confirm right to use AI-generated material</li>
              <li><strong>Deletion:</strong> Can delete creation anytime (except in active contests)</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-gray-500/30">
          <CardHeader>
            <CardTitle className="text-white">7. Limitation of Liability</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <ul className="list-disc ml-6 space-y-2">
              <li>Platform provided "as is"</li>
              <li>We don't guarantee uninterrupted AI operation</li>
              <li>Not responsible for user content</li>
              <li>May temporarily suspend service for updates</li>
              <li>Prizes may be cancelled in force majeure cases</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-orange-500/30">
          <CardHeader>
            <CardTitle className="text-white">8. Terms Changes</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <p>
              We reserve the right to change terms. You will be notified by email 30 days before significant changes.
            </p>
            <p className="text-sm text-gray-400 mt-3">
              By continuing to use the service after changes, you automatically agree to new terms.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/60 backdrop-blur border-teal-500/30">
          <CardHeader>
            <CardTitle className="text-white">9. Contacts and Complaints</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 space-y-3">
            <p><strong>Support:</strong></p>
            <ul className="list-disc ml-6 space-y-1">
              <li>Email: <a href="mailto:support@creatiquest.app" className="text-blue-400 underline">support@creatiquest.app</a></li>
              <li>Legal: <a href="mailto:legal@creatiquest.app" className="text-blue-400 underline">legal@creatiquest.app</a></li>
              <li>Content complaints: <a href="mailto:moderation@creatiquest.app" className="text-blue-400 underline">moderation@creatiquest.app</a></li>
            </ul>
            <p className="mt-4 text-sm text-gray-400">
              <strong>Applicable law:</strong> EU, Netherlands jurisdiction
            </p>
          </CardContent>
        </Card>

        <div className="bg-green-900/30 rounded-lg p-6 border border-green-500/30 text-center">
          <p className="text-green-300 font-semibold mb-2">
            By using CreatiQuest, you agree to these terms
          </p>
          <p className="text-gray-400 text-sm">
            Last updated: January 15, 2025
          </p>
        </div>
      </div>
    </div>
  );
}